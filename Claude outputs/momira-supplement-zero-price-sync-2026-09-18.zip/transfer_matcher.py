"""
transfer_matcher.py

Solves the "recognize the correct Transfer for an update" problem the
product owner flagged as the central design challenge for this feature:
unlike ClosedTour (providerCode) or Ticket (code), Travel Compositor's
Transfer schema has NO human-assigned code anywhere - only a TC-generated
id like "TRANSFER-412545" that's only known once a transfer has already
been created/fetched via the API.

CONFIRMED APPROACH (agreed with the product owner):
  1. PRIMARY - app-tracked id: once this app creates (or a human confirms a
     match for) a transfer, it remembers the route -> TC id mapping locally,
     keyed by supplier. Any future update for the "same" route reuses that
     id automatically, no human step needed.
  2. FALLBACK - departure/arrival similarity: for a transfer this app has
     never seen before (e.g. one that already existed in Travel Compositor
     before this tool was used), score every transfer in the supplier's
     full live list (GET /transfer/{supplierId}) by how closely its
     departure/arrival names match the new route, and present the best
     candidates to a human. This function NEVER decides on its own - the
     human always explicitly confirms (or rejects) a match before anything
     gets treated as an update-to-existing rather than a brand-new create.
     Once confirmed, remember_transfer_id() should be called so the same
     route never needs this fallback step again.

Storage: a plain local JSON file (no server-side persistence exists for
this mapping anywhere in Travel Compositor). Safe to lose - worst case the
app just falls back to the departure/arrival matching step again next time,
it is a convenience cache, never a source of truth. Source of truth is
always Travel Compositor itself (confirmed via get_transfer/get_transfers).
"""
# Stamped on every delivery - see platform_store.py's own header for why. This module never
# carried a build stamp before (2026-09-13, while consolidating name-normalization into
# text_normalize.py) - a partial deploy that updated every other file but this one would have
# gone undetected by app.py's own stale-module check.
MODULE_BUILD = "2026-09-18-supplement-zero-price-dropped"

import os
import json
import re
import difflib
from typing import Dict, Any, List, Optional

import platform_store
from text_normalize import normalize_name

# Kept only so an existing local transfer_match_store.json can still be read once and
# migrated into the shared durable store - see _load_store() below. Nothing writes
# here any more.
_LEGACY_STORE_PATH = os.getenv(
    "TRANSFER_MATCH_STORE_PATH",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "transfer_match_store.json"),
)
_NAMESPACE = "transfer_match"


def _load_store() -> Dict[str, Any]:
    """Reads the whole supplier -> {route: tc_id} map from the shared durable store.

    MOVED OFF THE LOCAL FILESYSTEM: this used to be a JSON file next to the app, which
    on Streamlit Cloud is wiped on every redeploy - so every match a human had confirmed
    was silently forgotten and had to be confirmed again. It now lives in platform_store
    (Postgres when DATABASE_URL is set), which survives restarts.

    A legacy transfer_match_store.json is still read ONCE if present and merged in, so an
    existing local install doesn't lose what it already knew when this ships."""
    store = platform_store.get_namespace(_NAMESPACE)
    if not store and os.path.exists(_LEGACY_STORE_PATH):
        try:
            with open(_LEGACY_STORE_PATH, "r") as f:
                legacy = json.load(f)
            if legacy:
                for supplier_key, routes in legacy.items():
                    platform_store.set(_NAMESPACE, str(supplier_key), routes)
                print(f"📦 Migrated {len(legacy)} supplier(s) of transfer match history "
                      f"from {_LEGACY_STORE_PATH} into durable storage.")
                return legacy
        except Exception as e:
            print(f"⚠️ Could not read the legacy transfer match store ({e}) - starting fresh "
                  f"(falls back to name matching, nothing breaks).")
    return store


def _save_supplier(supplier_key: str, routes: Dict[str, Any]) -> None:
    if not platform_store.set(_NAMESPACE, str(supplier_key), routes):
        print("⚠️ Could not save the transfer match store - the id -> route mapping just "
              "learned won't persist to the next session, but nothing about this upload failed.")


def _route_key(departure_name: str, arrival_name: str) -> str:
    """Normalizes a departure/arrival pair into a stable dict key so trivial formatting
    differences don't create duplicate tracked entries for what is really the same route.
    CONFIRMED FIX (2026-09-13, while consolidating name-normalization across the codebase): this
    used to have its own local, weaker normalization (lowercase + whitespace-collapse only) - a
    separate, independently-written copy of the same NFKC-Unicode gap already fixed for
    hotel_matcher.py's room/rate/season matching in the 2026-08-30 audit. Now shares that same
    fix via text_normalize.normalize_name, so a smart quote or full-width character in a
    departure/arrival name from a re-typed or re-extracted contract doesn't silently miss the
    app's own remembered route mapping."""
    return f"{normalize_name(departure_name)}::{normalize_name(arrival_name)}"


def remember_transfer_id(supplier_id: str, departure_name: str, arrival_name: str, transfer_id: str) -> None:
    """
    Call this right after a successful create, OR right after a human
    explicitly confirms a departure/arrival-matched candidate as the
    correct existing transfer - so future updates to this exact route
    auto-match via lookup_tracked_transfer_id() without needing the
    fallback matching step (or a human decision) again.
    """
    if not (supplier_id and departure_name and arrival_name and transfer_id):
        return
    supplier_key = str(supplier_id)
    # Only this supplier's row is written, not the whole store - two people working on
    # different suppliers at the same time can't clobber each other's entry the way a
    # whole-file rewrite could.
    routes = platform_store.get(_NAMESPACE, supplier_key) or {}
    routes[_route_key(departure_name, arrival_name)] = transfer_id
    _save_supplier(supplier_key, routes)
    print(f"📌 Remembered TC id '{transfer_id}' for route '{departure_name}' -> '{arrival_name}' "
          f"(supplier {supplier_id}) - future updates to this route will auto-match.")


def forget_transfer_id(supplier_id: str, departure_name: str, arrival_name: str) -> None:
    """Removes a tracked mapping - e.g. if a human later says a previous auto-match was wrong."""
    supplier_key = str(supplier_id)
    routes = platform_store.get(_NAMESPACE, supplier_key)
    if routes:
        routes.pop(_route_key(departure_name, arrival_name), None)
        _save_supplier(supplier_key, routes)


def lookup_tracked_transfer_id(supplier_id: str, departure_name: str, arrival_name: str) -> Optional[str]:
    """PRIMARY matching step - returns a TC id if this app has already created/confirmed a
    match for this exact route before, or None if it isn't tracked yet (caller should then
    fall back to suggest_existing_transfer_matches)."""
    _load_store()  # triggers a one-time migration of any legacy local file
    routes = platform_store.get(_NAMESPACE, str(supplier_id)) or {}
    return routes.get(_route_key(departure_name, arrival_name))


# CONFIRMED REAL RULE (product owner): "when Transfer or Transport says a three letter code
# from Airport, this must be seen as a City name too" - e.g. "HRG to El Gouna" is the same
# route as "Hurghada to El Gouna". The AI extraction/detection/price-lookup prompts already
# know this (see ai_extractor.py, price_refresh.py's PRICE_LOOKUP_SYSTEM_PROMPT), but this
# module's plain difflib text-similarity fallback had no such awareness at all - "HRG" and
# "Hurghada" barely overlap as strings, so a live route recorded under the full city name
# could score too low to even show up as a candidate. Only the codes already confirmed
# elsewhere in this codebase are covered here; extend as more are confirmed rather than
# guessing at codes nobody has verified.
_AIRPORT_CODE_TO_CITY = {
    "RMF": "Marsa Alam", "HRG": "Hurghada", "SSH": "Sharm El Sheikh", "CAI": "Cairo",
}


def _expand_airport_codes(text: str) -> str:
    result = text or ""
    for code, city in _AIRPORT_CODE_TO_CITY.items():
        result = re.sub(rf"\b{code}\b", city, result, flags=re.IGNORECASE)
    return result


def _name_similarity(a: str, b: str) -> float:
    return difflib.SequenceMatcher(
        None, _expand_airport_codes(a).strip().lower(), _expand_airport_codes(b).strip().lower()
    ).ratio()


def suggest_existing_transfer_matches(departure_name: str, arrival_name: str, existing_transfers: List[dict],
                                       top_n: int = 5) -> List[Dict[str, Any]]:
    """
    FALLBACK matching step - NEVER auto-applied. Scores every transfer in
    `existing_transfers` (the full list from a real GET /transfer/{supplierId}
    response) against the new departure/arrival names using plain text
    similarity on each side's 'name' field, and returns the top N candidates
    ranked best-first so a human can look at them and explicitly confirm or
    reject - this app never overwrites an existing transfer based on this
    fallback alone. Once a human confirms one, call remember_transfer_id()
    so this step isn't needed again for the same route.

    Each candidate: {"transfer_id", "name", "departure_name", "arrival_name",
    "score" (0.0-1.0, higher = more likely the same route)}.
    """
    scored = []
    for t in existing_transfers or []:
        if not isinstance(t, dict):
            continue
        t_departure = (t.get("departure") or {}).get("name", "")
        t_arrival = (t.get("arrival") or {}).get("name", "")
        dep_score = _name_similarity(departure_name, t_departure)
        arr_score = _name_similarity(arrival_name, t_arrival)
        score = (dep_score + arr_score) / 2
        scored.append({
            "transfer_id": t.get("id"),
            "name": t.get("name", ""),
            "departure_name": t_departure,
            "arrival_name": t_arrival,
            "score": round(score, 3),
        })
    scored.sort(key=lambda c: c["score"], reverse=True)
    return scored[:top_n]


def resolve_transfer_match(client, supplier_id: str, departure_name: str, arrival_name: str) -> Dict[str, Any]:
    """
    Convenience wrapper combining both matching steps for a UI to call in
    one shot: tries the app-tracked id first, and only if that comes up
    empty, fetches the supplier's full live transfer list and returns
    ranked fallback candidates for a human to confirm.

    Returns:
      {"tracked_id": str or None,       # CONFIRMED REAL RULE (product owner): even a tracked id
                                         # must NOT be auto-applied silently - the UI must fetch and
                                         # show the existing record's key details and get an explicit
                                         # human confirmation before using it, same safety bar as the
                                         # fallback_candidates path already had.
       "fallback_candidates": [...],    # only populated if tracked_id is None - MUST be human-confirmed
       "fetch_error": dict or None}     # set if get_transfers() itself failed - candidates will be empty, not a hard failure
    """
    tracked_id = lookup_tracked_transfer_id(supplier_id, departure_name, arrival_name)
    if tracked_id:
        return {"tracked_id": tracked_id, "fallback_candidates": [], "fetch_error": None}

    result = client.get_transfers(supplier_id)
    if isinstance(result, dict) and "error" in result:
        return {"tracked_id": None, "fallback_candidates": [], "fetch_error": result}

    existing = result.get("transfer", []) if isinstance(result, dict) else (result or [])
    candidates = suggest_existing_transfer_matches(departure_name, arrival_name, existing)
    return {"tracked_id": None, "fallback_candidates": candidates, "fetch_error": None}
