/**
 * MultiWander — agent admin JS.
 *
 * 1. Photo picker: opens the WordPress media library.
 * 2. Regions repeater: add / remove region rows dynamically.
 *    Each row has TWO inputs: a region name and a short note.
 */
( function () {
	'use strict';

	// ── Photo picker ─────────────────────────────────────────────────

	var field = document.querySelector( '.mwp-agent-photo-field' );
	if ( field && window.wp && window.wp.media ) {

		var input   = field.querySelector( '.mwp-agent-photo-id' );
		var preview = field.querySelector( '.mwp-agent-photo-preview' );
		var pick    = field.querySelector( '.mwp-agent-photo-pick' );
		var clear   = field.querySelector( '.mwp-agent-photo-clear' );
		var frame;

		pick.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			if ( frame ) { frame.open(); return; }
			frame = window.wp.media( {
				title: pick.textContent,
				library: { type: 'image' },
				multiple: false
			} );
			frame.on( 'select', function () {
				var att = frame.state().get( 'selection' ).first().toJSON();
				input.value = att.id;
				var url = ( att.sizes && att.sizes.medium ) ? att.sizes.medium.url : att.url;
				preview.src = url;
				preview.style.display = 'block';
				clear.style.display = '';
			} );
			frame.open();
		} );

		clear.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			input.value = '';
			preview.src = '';
			preview.style.display = 'none';
			clear.style.display = 'none';
		} );
	}

	// ── Regions repeater ─────────────────────────────────────────────
	//
	// Each row contains:
	//   <input name="mwp_agent_regions_name[]">  — the region name
	//   <input name="mwp_agent_regions_note[]">  — the short sentence
	//   <button class="mwpa-region-remove">✕</button>

	function attachRemoveHandler( btn ) {
		btn.addEventListener( 'click', function () {
			var row  = this.closest( '.mwpa-region-row' );
			if ( ! row ) return;
			var list = row.parentElement;
			row.remove();
			// Always keep at least one empty row so the form submits an
			// empty-array value when all entries are removed.
			if ( list && ! list.querySelector( '.mwpa-region-row' ) ) {
				list.appendChild( buildRow() );
			}
		} );
	}

	function makeInput( cls, name, placeholder ) {
		var i = document.createElement( 'input' );
		i.type        = 'text';
		i.className   = cls;
		i.name        = name;
		i.placeholder = placeholder;
		return i;
	}

	/**
	 * Build a rich region row: name, subtitle, flag codes, description, tags.
	 * Mirrors the server-rendered markup in class-mwp-agent.php exactly so
	 * new rows post the same field names.
	 *
	 * @returns {HTMLElement}
	 */
	function buildRow() {
		var row = document.createElement( 'div' );
		row.className = 'mwpa-region-row';

		var fields = document.createElement( 'div' );
		fields.className = 'mwpa-region-fields';

		var nameInp = makeInput( 'mwpa-region-f-name', 'mwp_agent_regions_name[]',
			'Region — e.g. Hiszpania i Portugalia' );

		var twoWrap = document.createElement( 'div' );
		twoWrap.className = 'mwpa-region-f-two';
		var subInp = makeInput( 'mwpa-region-f-subtitle', 'mwp_agent_regions_subtitle[]',
			'Subtitle — e.g. Osobiste Doświadczenie Życia' );
		var ctyInp = makeInput( 'mwpa-region-f-countries', 'mwp_agent_regions_countries[]',
			'Type a country, press Enter…' );
		twoWrap.appendChild( subInp );
		twoWrap.appendChild( ctyInp );

		var noteInp = document.createElement( 'textarea' );
		noteInp.className   = 'mwpa-region-f-note';
		noteInp.rows        = 2;
		noteInp.name        = 'mwp_agent_regions_note[]';
		noteInp.placeholder = 'Short description of your experience there';

		var tagsInp = makeInput( 'mwpa-region-f-tags', 'mwp_agent_regions_tags[]',
			'Tags, comma-separated — e.g. Życie w Lizbonie, Wyspy Kanaryjskie' );

		fields.appendChild( nameInp );
		fields.appendChild( twoWrap );
		fields.appendChild( noteInp );
		fields.appendChild( tagsInp );

		var removeBtn = document.createElement( 'button' );
		removeBtn.type        = 'button';
		removeBtn.className    = 'mwpa-region-remove button-link';
		removeBtn.title        = 'Remove';
		removeBtn.textContent = '✕';
		attachRemoveHandler( removeBtn );

		row.appendChild( fields );
		row.appendChild( removeBtn );
		return row;
	}

	// Wire up existing remove buttons.
	document.querySelectorAll( '.mwpa-region-remove' ).forEach( attachRemoveHandler );

	// Wire up add buttons.
	document.querySelectorAll( '.mwpa-region-add' ).forEach( function ( addBtn ) {
		addBtn.addEventListener( 'click', function () {
			var listId = this.getAttribute( 'data-list' );
			var list   = listId ? document.getElementById( listId ) : null;
			if ( ! list ) return;
			var row = buildRow();
			list.appendChild( row );
			enhanceCountryChipField( row.querySelector( '.mwpa-region-f-countries' ) );
			row.querySelector( 'input' ).focus();
		} );
	} );

	// ── Flags: a plain text input, replaced with one-country-at-a-time
	// chips. The underlying input (name="…regions_countries[]") still
	// carries the real value — a comma-separated list of the country
	// names the agent typed — so nothing on the PHP side has to change;
	// this only changes how it is typed into.
	//
	// Type a country name (in English — e.g. "Thailand"), press Enter or
	// comma to turn it into a chip, then type the next one. No more
	// remembering two-letter codes.

	// English country name → ISO-3166-1 alpha-2 code, for the little flag
	// icon on each chip. Mirrors MWP_Agent::country_name_map_en() in PHP —
	// keep the two in sync if either changes.
	var COUNTRY_CODE_MAP = {
		'spain': 'es', 'portugal': 'pt', 'turkey': 'tr', 'turkiye': 'tr',
		'italy': 'it', 'greece': 'gr', 'france': 'fr', 'germany': 'de',
		'netherlands': 'nl', 'holland': 'nl', 'belgium': 'be', 'austria': 'at',
		'switzerland': 'ch', 'croatia': 'hr', 'slovenia': 'si', 'albania': 'al',
		'montenegro': 'me', 'serbia': 'rs', 'bosnia': 'ba', 'bosnia and herzegovina': 'ba',
		'bulgaria': 'bg', 'romania': 'ro', 'hungary': 'hu', 'czech republic': 'cz',
		'czechia': 'cz', 'slovakia': 'sk', 'poland': 'pl', 'ukraine': 'ua',
		'cyprus': 'cy', 'malta': 'mt', 'china': 'cn', 'vietnam': 'vn',
		'thailand': 'th', 'cambodia': 'kh', 'laos': 'la', 'indonesia': 'id',
		'bali': 'id', 'malaysia': 'my', 'singapore': 'sg', 'philippines': 'ph',
		'japan': 'jp', 'south korea': 'kr', 'korea': 'kr', 'india': 'in',
		'sri lanka': 'lk', 'nepal': 'np', 'georgia': 'ge', 'armenia': 'am',
		'azerbaijan': 'az', 'kazakhstan': 'kz', 'uzbekistan': 'uz', 'morocco': 'ma',
		'tunisia': 'tn', 'egypt': 'eg', 'jordan': 'jo', 'israel': 'il',
		'lebanon': 'lb', 'united arab emirates': 'ae', 'uae': 'ae', 'qatar': 'qa',
		'oman': 'om', 'saudi arabia': 'sa', 'kenya': 'ke', 'tanzania': 'tz',
		'zanzibar': 'tz', 'south africa': 'za', 'mexico': 'mx', 'colombia': 'co',
		'dominican republic': 'do', 'dominicana': 'do', 'costa rica': 'cr', 'panama': 'pa',
		'brazil': 'br', 'argentina': 'ar', 'peru': 'pe', 'chile': 'cl', 'cuba': 'cu',
		'united states': 'us', 'usa': 'us', 'canada': 'ca', 'iceland': 'is',
		'norway': 'no', 'sweden': 'se', 'finland': 'fi', 'denmark': 'dk',
		'ireland': 'ie', 'united kingdom': 'gb', 'uk': 'gb', 'england': 'gb',
		'scotland': 'gb', 'australia': 'au', 'new zealand': 'nz', 'russia': 'ru'
	};

	/**
	 * Resolve a typed country name to an ISO code for the flag icon.
	 * Exact match first, then a loose substring match (so "Dominican Rep."
	 * or an already-saved 2-letter code still gets a flag).
	 *
	 * @param {string} name
	 * @returns {string} lowercase ISO code, or '' if unrecognised.
	 */
	function countryNameToCode( name ) {
		var hay = ( name || '' ).trim().toLowerCase();
		if ( ! hay ) { return ''; }
		if ( /^[a-z]{2}$/.test( hay ) ) { return hay; } // legacy 2-letter code typed directly
		if ( COUNTRY_CODE_MAP.hasOwnProperty( hay ) ) { return COUNTRY_CODE_MAP[ hay ]; }
		for ( var needle in COUNTRY_CODE_MAP ) {
			if ( COUNTRY_CODE_MAP.hasOwnProperty( needle ) && hay.indexOf( needle ) !== -1 ) {
				return COUNTRY_CODE_MAP[ needle ];
			}
		}
		return '';
	}

	function enhanceCountryChipField( input ) {
		if ( ! input || input.dataset.mwpaChipified ) { return; }
		input.dataset.mwpaChipified = '1';

		var wrap = document.createElement( 'div' );
		wrap.className = 'mwpa-chip-field';

		var chipList = document.createElement( 'div' );
		chipList.className = 'mwpa-chip-list';

		var typer = document.createElement( 'input' );
		typer.type = 'text';
		typer.className = 'mwpa-chip-typer';
		typer.placeholder = input.placeholder || 'Type a country, press Enter…';

		input.type = 'hidden';
		input.parentNode.insertBefore( wrap, input );
		wrap.appendChild( chipList );
		wrap.appendChild( typer );
		wrap.appendChild( input );

		function currentNames() {
			return input.value
				? input.value.split( ',' ).map( function ( s ) { return s.trim(); } ).filter( Boolean )
				: [];
		}

		function sync( names ) {
			input.value = names.join( ', ' );
		}

		function renderChips() {
			chipList.innerHTML = '';
			currentNames().forEach( function ( name, idx ) {
				var chip = document.createElement( 'span' );
				chip.className = 'mwpa-chip';

				// A little flag icon per chip — makes each one easy to tell
				// apart at a glance instead of reading plain text labels.
				var code = countryNameToCode( name );
				if ( code ) {
					var flag = document.createElement( 'img' );
					flag.className = 'mwpa-chip-flag';
					flag.src = 'https://flagcdn.com/20x15/' + code + '.png';
					flag.srcset = 'https://flagcdn.com/40x30/' + code + '.png 2x';
					flag.alt = '';
					flag.setAttribute( 'aria-hidden', 'true' );
					flag.loading = 'lazy';
					chip.appendChild( flag );
				}

				var label = document.createElement( 'span' );
				label.textContent = name;
				var x = document.createElement( 'button' );
				x.type = 'button';
				x.className = 'mwpa-chip-remove';
				x.setAttribute( 'aria-label', 'Remove ' + name );
				x.textContent = '×';
				x.addEventListener( 'click', function () {
					var names = currentNames();
					names.splice( idx, 1 );
					sync( names );
					renderChips();
				} );
				chip.appendChild( label );
				chip.appendChild( x );
				chipList.appendChild( chip );
			} );
		}

		function addFromTyper() {
			var val = typer.value.trim().replace( /,+$/, '' ).trim();
			if ( ! val ) { return; }
			var names = currentNames();
			names.push( val );
			sync( names );
			typer.value = '';
			renderChips();
		}

		typer.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key || ',' === e.key ) {
				e.preventDefault();
				addFromTyper();
			} else if ( 'Backspace' === e.key && '' === typer.value ) {
				var names = currentNames();
				if ( names.length ) {
					names.pop();
					sync( names );
					renderChips();
				}
			}
		} );
		typer.addEventListener( 'blur', addFromTyper );

		renderChips();
	}

	document.querySelectorAll( '.mwpa-region-f-countries' ).forEach( enhanceCountryChipField );

	// ── Languages repeater ───────────────────────────────────────────
	//
	// Each row: <input name="mwp_agent_languages_name[]"> + a level
	// <select name="mwp_agent_languages_level[]"> + a remove button.

	var LANG_LEVELS = [ 'Ojczysty', 'Biegły', 'Bardzo dobry', 'Komunikatywny' ];

	function attachLangRemove( btn ) {
		btn.addEventListener( 'click', function () {
			var row = this.closest( '.mwpa-lang-row' );
			if ( ! row ) return;
			var list = row.parentElement;
			row.remove();
			if ( list && ! list.querySelector( '.mwpa-lang-row' ) ) {
				list.appendChild( buildLangRow() );
			}
		} );
	}

	function buildLangRow() {
		var row = document.createElement( 'div' );
		row.className = 'mwpa-lang-row';

		var nameInp = document.createElement( 'input' );
		nameInp.type        = 'text';
		nameInp.className   = 'mwpa-lang-f-name';
		nameInp.name        = 'mwp_agent_languages_name[]';
		nameInp.placeholder = 'e.g. Polski';

		var sel = document.createElement( 'select' );
		sel.className = 'mwpa-lang-f-level';
		sel.name      = 'mwp_agent_languages_level[]';
		var o0 = document.createElement( 'option' );
		o0.value = ''; o0.textContent = '— poziom —';
		sel.appendChild( o0 );
		LANG_LEVELS.forEach( function ( lvl ) {
			var o = document.createElement( 'option' );
			o.value = lvl; o.textContent = lvl;
			sel.appendChild( o );
		} );

		var removeBtn = document.createElement( 'button' );
		removeBtn.type        = 'button';
		removeBtn.className    = 'mwpa-lang-remove button-link';
		removeBtn.title        = 'Remove';
		removeBtn.textContent = '✕';
		attachLangRemove( removeBtn );

		row.appendChild( nameInp );
		row.appendChild( sel );
		row.appendChild( removeBtn );
		return row;
	}

	document.querySelectorAll( '.mwpa-lang-remove' ).forEach( attachLangRemove );

	document.querySelectorAll( '.mwpa-lang-add' ).forEach( function ( addBtn ) {
		addBtn.addEventListener( 'click', function () {
			var listId = this.getAttribute( 'data-list' );
			var list   = listId ? document.getElementById( listId ) : null;
			if ( ! list ) return;
			var row = buildLangRow();
			list.appendChild( row );
			row.querySelector( 'input' ).focus();
		} );
	} );

	// ── Travel style repeater ────────────────────────────────────────
	//
	// One line per travel style, capped at three — the agent picks from
	// the datalist suggestions or types their own. Each row:
	//   <input name="mwp_agent_style[]" list="…">  + a remove button.
	// The "Add" button carries data-list (the row container's id),
	// data-datalist (which <datalist> to attach for suggestions — this
	// differs between the Kit page and the native profile.php box, which
	// each have their own) and data-name (the field's POST name).

	function styleAddButtonFor( list ) {
		return document.querySelector( '.mwpa-style-add[data-list="' + list.id + '"]' );
	}

	function updateStyleAddState( list ) {
		var addBtn = styleAddButtonFor( list );
		if ( ! addBtn ) { return; }
		var max = parseInt( list.getAttribute( 'data-max' ), 10 ) || 3;
		var count = list.querySelectorAll( '.mwpa-style-row' ).length;
		addBtn.disabled = count >= max;
		addBtn.style.display = count >= max ? 'none' : '';
	}

	function attachStyleRemoveHandler( btn ) {
		btn.addEventListener( 'click', function () {
			var row = this.closest( '.mwpa-style-row' );
			if ( ! row ) return;
			var list = row.parentElement;
			row.remove();
			// Always keep at least one (possibly empty) row so the form
			// still posts an array for this field.
			if ( list && ! list.querySelector( '.mwpa-style-row' ) ) {
				var addBtn = styleAddButtonFor( list );
				list.appendChild( buildStyleRow( addBtn ) );
			}
			if ( list ) { updateStyleAddState( list ); }
		} );
	}

	function buildStyleRow( addBtn ) {
		var row = document.createElement( 'div' );
		row.className = 'mwpa-style-row';

		var nameInp = document.createElement( 'input' );
		nameInp.type        = 'text';
		nameInp.className   = 'mwpa-style-f-name';
		nameInp.name        = addBtn ? addBtn.getAttribute( 'data-name' ) : 'mwp_agent_style[]';
		nameInp.maxLength   = 60;
		nameInp.placeholder = 'e.g. Luksusowe podróże';
		var datalistId = addBtn ? addBtn.getAttribute( 'data-datalist' ) : '';
		if ( datalistId ) {
			nameInp.setAttribute( 'list', datalistId );
		}

		var removeBtn = document.createElement( 'button' );
		removeBtn.type        = 'button';
		removeBtn.className    = 'mwpa-style-remove button-link';
		removeBtn.title        = 'Remove';
		removeBtn.textContent = '✕';
		attachStyleRemoveHandler( removeBtn );

		row.appendChild( nameInp );
		row.appendChild( removeBtn );
		return row;
	}

	document.querySelectorAll( '.mwpa-style-remove' ).forEach( attachStyleRemoveHandler );

	document.querySelectorAll( '.mwpa-style-list' ).forEach( updateStyleAddState );

	document.querySelectorAll( '.mwpa-style-add' ).forEach( function ( addBtn ) {
		addBtn.addEventListener( 'click', function () {
			var listId = this.getAttribute( 'data-list' );
			var list   = listId ? document.getElementById( listId ) : null;
			if ( ! list ) return;
			var max = parseInt( list.getAttribute( 'data-max' ), 10 ) || 3;
			if ( list.querySelectorAll( '.mwpa-style-row' ).length >= max ) return;
			var row = buildStyleRow( this );
			list.appendChild( row );
			updateStyleAddState( list );
			row.querySelector( 'input' ).focus();
		} );
	} );

}() );
