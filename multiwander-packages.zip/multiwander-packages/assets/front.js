/**
 * MultiWander Packages — "See more" for long descriptions.
 *
 * Travel Compositor's destination and tour copy runs to several paragraphs.
 * Shown in full it buries the itinerary; so each block is collapsed to a
 * single teaser line with a button to open it.
 *
 * Progressive enhancement on purpose: the clamp is applied BY THIS SCRIPT, not
 * by the stylesheet. With JavaScript off, or if this file fails to load, the
 * text simply shows in full — never truncated with no way to read the rest.
 */
( function () {
	'use strict';

	function collapse( block ) {
		// Nothing to hide: leave short copy alone rather than adding a button
		// that reveals one extra word.
		//
		// The comparison is scrollHeight against clientHeight, and it has to
		// be. A -webkit-box with a line clamp hides the overflow but still
		// reports the FULL text in scrollHeight, so measuring that after
		// clamping says "nothing was hidden" every single time and the clamp
		// gets removed again — which is exactly why these descriptions were
		// still printing in full.
		var full = block.scrollHeight;
		block.classList.add( 'is-clamped' );

		if ( block.clientHeight >= full - 4 ) {
			block.classList.remove( 'is-clamped' );
			return;
		}

		var button = document.createElement( 'button' );
		button.type = 'button';
		button.className = 'mwp-more';
		button.textContent = block.dataset.more || 'See more';
		button.setAttribute( 'aria-expanded', 'false' );

		block.insertAdjacentElement( 'afterend', button );

		button.addEventListener( 'click', function () {
			var open = block.classList.toggle( 'is-clamped' ) === false;

			button.textContent = open
				? ( block.dataset.less || 'Show less' )
				: ( block.dataset.more || 'See more' );

			button.setAttribute( 'aria-expanded', open ? 'true' : 'false' );

			// Closing from far down the page would otherwise leave the reader
			// staring at whatever happens to scroll into view.
			if ( ! open ) {
				var top = block.getBoundingClientRect().top;
				if ( top < 0 ) {
					block.scrollIntoView( { block: 'nearest' } );
				}
			}
		} );
	}

	function init() {
		var blocks = document.querySelectorAll( '[data-mwp-more]' );
		for ( var i = 0; i < blocks.length; i++ ) {
			collapse( blocks[ i ] );
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );

/**
 * MultiWander Packages — date and traveller picker.
 *
 * Mirrors the selector the booking engine shows after you arrive there, so the
 * choice is made once, on our page, rather than the visitor landing on a modal
 * asking the same questions again.
 *
 * Limits match the engine: 9 travellers, 4 rooms, at least one adult, and
 * never more rooms than adults.
 *
 * The chosen values are appended to the booking link as query parameters. If
 * the engine ignores them it simply asks for the dates itself, exactly as it
 * does today — nothing is lost.
 */
( function () {
	'use strict';

	function setup( picker ) {
		var url = picker.dataset.url;
		var maxPax = parseInt( picker.dataset.maxPax, 10 ) || 9;
		var maxRooms = parseInt( picker.dataset.maxRooms, 10 ) || 4;

		var dateField = picker.querySelector( '.mwp-date' );
		var toggle = picker.querySelector( '.mwp-party-toggle' );
		var panel = picker.querySelector( '.mwp-party' );
		var summary = picker.querySelector( '.mwp-party-summary' );
		var done = picker.querySelector( '.mwp-party-done' );
		var list = picker.querySelector( '[data-mwp-rooms]' );
		var addRoom = picker.querySelector( '.mwp-addroom' );
		var ageNote = picker.querySelector( '.mwp-age-note' );

		if ( ! url || ! toggle || ! panel || ! list ) {
			return;
		}

		var s = {};
		try {
			s = JSON.parse( panel.dataset.strings || '{}' );
		} catch ( err ) {
			s = {};
		}

		/** Falls back to English if a string is missing rather than showing a blank. */
		function str( key, fallback ) {
			return s[ key ] || fallback;
		}

		function plural( key, n, one, many ) {
			var pair = s[ key ];
			if ( ! pair || pair.length < 2 ) {
				pair = [ one, many ];
			}
			return 1 === n ? pair[ 0 ] : pair[ 1 ];
		}

		/**
		 * One entry per room: how many adults, and an age for each child.
		 * This is the shape the booking engine works in, so nothing has to be
		 * guessed back apart from it later.
		 */
		var rooms = [ { adults: 2, children: [] } ];

		var seed = parseInt( picker.dataset.adults, 10 );
		if ( seed > 0 ) {
			rooms[ 0 ].adults = Math.min( seed, maxPax );
		}

		function totalPax() {
			var n = 0;
			for ( var i = 0; i < rooms.length; i++ ) {
				n += rooms[ i ].adults + rooms[ i ].children.length;
			}
			return n;
		}

		function totalAdults() {
			var n = 0;
			for ( var i = 0; i < rooms.length; i++ ) {
				n += rooms[ i ].adults;
			}
			return n;
		}

		function totalChildren() {
			return totalPax() - totalAdults();
		}

		function counterRow( kind, labelText, hintText, value, canMinus, canPlus ) {
			var row = document.createElement( 'div' );
			row.className = 'mwp-counter';
			row.dataset.counter = kind;

			var label = document.createElement( 'span' );
			label.className = 'mwp-counter-label';

			var b = document.createElement( 'b' );
			b.textContent = labelText;
			label.appendChild( b );

			if ( hintText ) {
				var small = document.createElement( 'small' );
				small.textContent = hintText;
				label.appendChild( small );
			}

			var controls = document.createElement( 'span' );
			controls.className = 'mwp-counter-controls';

			var minus = document.createElement( 'button' );
			minus.type = 'button';
			minus.className = 'mwp-minus';
			minus.textContent = '−';
			minus.setAttribute( 'aria-label', labelText + ' −' );
			minus.disabled = ! canMinus;

			var out = document.createElement( 'output' );
			out.className = 'mwp-value';
			out.textContent = value;

			var plus = document.createElement( 'button' );
			plus.type = 'button';
			plus.className = 'mwp-plus';
			plus.textContent = '+';
			plus.setAttribute( 'aria-label', labelText + ' +' );
			plus.disabled = ! canPlus;

			controls.appendChild( minus );
			controls.appendChild( out );
			controls.appendChild( plus );

			row.appendChild( label );
			row.appendChild( controls );
			return row;
		}

		/** Ages 0–17, the range the engine accepts for a child. */
		function ageSelect( roomIndex, childIndex, value ) {
			var wrap = document.createElement( 'label' );
			wrap.className = 'mwp-age';

			var caption = document.createElement( 'span' );
			caption.textContent = str( 'childAge', 'Child age' ) + ' ' + ( childIndex + 1 );
			wrap.appendChild( caption );

			var select = document.createElement( 'select' );
			select.dataset.room = roomIndex;
			select.dataset.child = childIndex;

			for ( var age = 0; age <= 17; age++ ) {
				var option = document.createElement( 'option' );
				option.value = age;
				option.textContent = 0 === age
					? str( 'under1', 'under 1' )
					: age + ' ' + str( 'years', 'years' );
				if ( age === value ) {
					option.selected = true;
				}
				select.appendChild( option );
			}

			wrap.appendChild( select );
			return wrap;
		}

		function roomBlock( room, index ) {
			var box = document.createElement( 'div' );
			box.className = 'mwp-room';
			box.dataset.room = index;

			var head = document.createElement( 'div' );
			head.className = 'mwp-room-head';

			var name = document.createElement( 'b' );
			name.textContent = str( 'room', 'Room' ) + ' ' + ( index + 1 );
			head.appendChild( name );

			// The first room cannot go: there is always at least one.
			if ( index > 0 ) {
				var remove = document.createElement( 'button' );
				remove.type = 'button';
				remove.className = 'mwp-room-remove';
				remove.textContent = str( 'remove', 'Remove' );
				remove.dataset.room = index;
				head.appendChild( remove );
			}

			box.appendChild( head );

			var spare = maxPax - totalPax();

			box.appendChild( counterRow(
				'adults',
				str( 'adults', 'Adults' ),
				str( 'adultsHint', '18 and over' ),
				room.adults,
				room.adults > 1,
				spare > 0
			) );

			box.appendChild( counterRow(
				'children',
				str( 'children', 'Children' ),
				str( 'childrenHint', '0 – 17 years' ),
				room.children.length,
				room.children.length > 0,
				spare > 0
			) );

			if ( room.children.length ) {
				var ages = document.createElement( 'div' );
				ages.className = 'mwp-ages';
				for ( var c = 0; c < room.children.length; c++ ) {
					ages.appendChild( ageSelect( index, c, room.children[ c ] ) );
				}
				box.appendChild( ages );
			}

			return box;
		}

		function label() {
			var parts = [];
			parts.push( rooms.length + ' ' + plural( 'roomWord', rooms.length, 'room', 'rooms' ) );
			parts.push( totalAdults() + ' ' + plural( 'adultWord', totalAdults(), 'adult', 'adults' ) );

			var kids = totalChildren();
			if ( kids > 0 ) {
				parts.push( kids + ' ' + plural( 'childWord', kids, 'child', 'children' ) );
			}
			return parts.join( ', ' );
		}

		function paint() {
			list.textContent = '';
			for ( var i = 0; i < rooms.length; i++ ) {
				list.appendChild( roomBlock( rooms[ i ], i ) );
			}

			if ( addRoom ) {
				addRoom.disabled = rooms.length >= maxRooms || totalPax() >= maxPax;
			}
			if ( ageNote ) {
				ageNote.hidden = 0 === totalChildren();
			}
			if ( summary ) {
				summary.textContent = label();
			}

			updateLinks();
		}

		/**
		 * The engine's own parameter names are not published, so the values go
		 * out under the obvious ones and can be corrected in one place — the
		 * mwp_booking_query_args filter — once a real booking URL confirms them.
		 * If they are ignored the engine simply asks again, as it does today.
		 */
		/*
		 * Two destinations, and they are not the same thing.
		 *
		 * .mwp-book keeps the idea page — it is the "look at this trip on the
		 * booking site" link, and query parameters there are decoration.
		 *
		 * .mwp-search goes through our own handover instead, which POSTs the
		 * choice into the engine and lands the visitor on the travel map with
		 * their dates and party already applied. A link cannot do that: the
		 * engine builds the trip from a POST and keeps it in the session.
		 */
		var deeplink = picker.dataset.deeplink || '';

		/**
		 * Search goes to the engine's deep link, which opens this package in
		 * the travel builder already on the chosen date and for the chosen
		 * party — the thing the whole picker exists to achieve.
		 *
		 * The date has to be DD/MM/YYYY with real slashes; encoding them
		 * breaks it. Rooms are not part of it: the engine takes one
		 * distribution for the party and the visitor splits it into rooms on
		 * arrival, which is one step rather than the whole question again.
		 */
		function updateSearch() {
			if ( ! deeplink ) {
				return;
			}

			var href = deeplink;

			if ( dateField && dateField.value ) {
				var iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec( dateField.value );
				if ( iso ) {
					href += '&departureDate=' + iso[ 3 ] + '/' + iso[ 2 ] + '/' + iso[ 1 ];
				}
			}

			href += '&distribution=' + totalAdults() + '-' + totalChildren();

			var buttons = document.querySelectorAll( '.mwp-search' );
			for ( var i = 0; i < buttons.length; i++ ) {
				buttons[ i ].href = href;
			}
		}

		function updateLinks() {
			updateSearch();

			var params = [];
			if ( dateField && dateField.value ) {
				params.push( 'departureDate=' + encodeURIComponent( dateField.value ) );
			}
			params.push( 'adults=' + totalAdults() );
			params.push( 'children=' + totalChildren() );
			params.push( 'rooms=' + rooms.length );

			// Room-by-room breakdown: "2-5.8|2" is two adults with children
			// aged 5 and 8 in room one, two adults in room two.
			var parts = [];
			var ages = [];
			for ( var i = 0; i < rooms.length; i++ ) {
				var piece = String( rooms[ i ].adults );
				if ( rooms[ i ].children.length ) {
					piece += '-' + rooms[ i ].children.join( '.' );
					ages = ages.concat( rooms[ i ].children );
				}
				parts.push( piece );
			}
			params.push( 'distribution=' + encodeURIComponent( parts.join( '|' ) ) );
			if ( ages.length ) {
				params.push( 'childrenAges=' + encodeURIComponent( ages.join( ',' ) ) );
			}

			var joiner = url.indexOf( '?' ) === -1 ? '?' : '&';
			var href = url + joiner + params.join( '&' );

			var links = document.querySelectorAll( '.mwp-book' );
			for ( var j = 0; j < links.length; j++ ) {
				links[ j ].href = href;
			}
		}

		list.addEventListener( 'click', function ( e ) {
			var button = e.target.closest( 'button' );
			if ( ! button ) {
				return;
			}
			e.preventDefault();

			if ( button.classList.contains( 'mwp-room-remove' ) ) {
				rooms.splice( parseInt( button.dataset.room, 10 ), 1 );
				paint();
				return;
			}

			var plus = button.classList.contains( 'mwp-plus' );
			var minus = button.classList.contains( 'mwp-minus' );
			if ( ! plus && ! minus ) {
				return;
			}

			var row = button.closest( '[data-counter]' );
			var box = button.closest( '[data-room]' );
			if ( ! row || ! box ) {
				return;
			}

			var room = rooms[ parseInt( box.dataset.room, 10 ) ];
			if ( ! room ) {
				return;
			}

			if ( 'adults' === row.dataset.counter ) {
				if ( plus && totalPax() < maxPax ) {
					room.adults++;
				} else if ( minus && room.adults > 1 ) {
					room.adults--;
				}
			} else if ( plus && totalPax() < maxPax ) {
				// A new child starts at an age the parent will almost always
				// change; 8 keeps it out of the infant rules by default.
				room.children.push( 8 );
			} else if ( minus && room.children.length ) {
				room.children.pop();
			}

			paint();
		} );

		list.addEventListener( 'change', function ( e ) {
			if ( 'SELECT' !== e.target.tagName ) {
				return;
			}
			var room = rooms[ parseInt( e.target.dataset.room, 10 ) ];
			if ( room ) {
				room.children[ parseInt( e.target.dataset.child, 10 ) ] = parseInt( e.target.value, 10 );
				updateLinks();
			}
		} );

		if ( addRoom ) {
			addRoom.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				if ( rooms.length < maxRooms && totalPax() < maxPax ) {
					rooms.push( { adults: 1, children: [] } );
					paint();
				}
			} );
		}

		toggle.addEventListener( 'click', function () {
			var open = panel.hidden;
			panel.hidden = ! open;
			toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		} );

		if ( done ) {
			done.addEventListener( 'click', function () {
				panel.hidden = true;
				toggle.setAttribute( 'aria-expanded', 'false' );
				toggle.focus();
			} );
		}

		/*
		 * Clicking away closes the panel — but only a click that is genuinely
		 * outside it.
		 *
		 * This listener runs in the CAPTURE phase, and that is the whole
		 * point. Pressing + or − re-renders the rooms, so by the time a
		 * bubbling listener saw the event its target had already been removed
		 * from the document and picker.contains() said "outside" — the panel
		 * shut on every single change. Capture runs before the re-render, so
		 * the target is still where the visitor clicked it, and the panel now
		 * stays open until Akceptuję, Escape, or a click elsewhere.
		 */
		document.addEventListener( 'click', function ( e ) {
			if ( ! panel.hidden && ! picker.contains( e.target ) ) {
				panel.hidden = true;
				toggle.setAttribute( 'aria-expanded', 'false' );
			}
		}, true );

		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && ! panel.hidden ) {
				panel.hidden = true;
				toggle.setAttribute( 'aria-expanded', 'false' );
				toggle.focus();
			}
		} );

		if ( dateField ) {
			dateField.addEventListener( 'change', updateLinks );
			calendar( dateField );
		}

		paint();
	}

	/**
	 * A two-month calendar, in place of the browser's own date control.
	 *
	 * The native control looks different in every browser and on Windows it is
	 * a cramped single month — nothing like the booking engine's picker, which
	 * shows two months side by side. Since the whole point of asking here is
	 * that the visitor should not notice the handover, it is drawn to match.
	 *
	 * The <input type="date"> stays in the page and keeps holding the value:
	 * it is what the rest of this script reads, and with JavaScript off it is
	 * still a working date field rather than a dead button.
	 *
	 * Month and weekday names come from Intl in the page's own language, so
	 * there is no word here to translate.
	 */
	function calendar( input ) {
		var lang = document.documentElement.lang || 'en';
		var wrap = document.createElement( 'div' );
		var field = document.createElement( 'button' );
		var panel = document.createElement( 'div' );

		/*
		 * The departures the operator actually sells, when there are any.
		 *
		 * Packages built dynamically depart any day and send no list, and for
		 * those this stays empty and every future day stays open. A fixed
		 * departure — a Nile cruise sailing once a week, a group tour leaving
		 * on Saturdays — sends its dates, and then they are the only dates
		 * this calendar will accept. Offering the other six days of the week
		 * only moves the refusal to the booking engine, one step further along
		 * and with the visitor's expectations already set.
		 */
		var only = ( input.dataset.departures || '' ).split( ' ' ).filter( Boolean );
		var fixed = only.length > 0;

		function offered( iso ) {
			return ! fixed || only.indexOf( iso ) !== -1;
		}

		var min = parseISO( input.getAttribute( 'min' ) ) || startOfDay( new Date() );
		var value = parseISO( input.value ) || min;

		// A value the operator does not sell — a stale default, a date typed
		// into the native control — moves to the first one they do, so the
		// field never shows a day the next screen will reject.
		if ( fixed && ! offered( toISO( value ) ) ) {
			var first = only.filter( function ( iso ) {
				return iso >= toISO( min );
			} )[ 0 ] || only[ 0 ];

			value = parseISO( first ) || value;
			input.value = toISO( value );
		}

		var view = new Date( value.getFullYear(), value.getMonth(), 1 );

		wrap.className = 'mwp-datewrap';
		input.parentNode.insertBefore( wrap, input );
		wrap.appendChild( input );
		input.hidden = true;

		field.type = 'button';
		field.className = 'mwp-datefield';
		field.setAttribute( 'aria-expanded', 'false' );

		panel.className = 'mwp-cal';
		panel.hidden = true;

		wrap.appendChild( field );
		wrap.appendChild( panel );

		function startOfDay( d ) {
			return new Date( d.getFullYear(), d.getMonth(), d.getDate() );
		}

		function parseISO( s ) {
			var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec( s || '' );
			return m ? new Date( +m[ 1 ], m[ 2 ] - 1, +m[ 3 ] ) : null;
		}

		function toISO( d ) {
			var mm = ( '0' + ( d.getMonth() + 1 ) ).slice( -2 );
			var dd = ( '0' + d.getDate() ).slice( -2 );
			return d.getFullYear() + '-' + mm + '-' + dd;
		}

		/** The engine writes dates as 05.10.2026, so this does too. */
		function pretty( d ) {
			var mm = ( '0' + ( d.getMonth() + 1 ) ).slice( -2 );
			var dd = ( '0' + d.getDate() ).slice( -2 );
			return dd + '.' + mm + '.' + d.getFullYear();
		}

		function monthName( d ) {
			try {
				return new Intl.DateTimeFormat( lang, { month: 'long', year: 'numeric' } ).format( d );
			} catch ( err ) {
				return ( d.getMonth() + 1 ) + '/' + d.getFullYear();
			}
		}

		/** Monday first, as the engine and most of Europe show it. */
		function weekdays() {
			var names = [];
			// 2024-01-01 was a Monday; any known Monday will do.
			var day = new Date( 2024, 0, 1 );
			for ( var i = 0; i < 7; i++ ) {
				try {
					names.push( new Intl.DateTimeFormat( lang, { weekday: 'short' } ).format( day ).slice( 0, 2 ) );
				} catch ( err ) {
					names.push( [ 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su' ][ i ] );
				}
				day.setDate( day.getDate() + 1 );
			}
			return names;
		}

		function month( first ) {
			var box = document.createElement( 'div' );
			box.className = 'mwp-cal-month';

			var head = document.createElement( 'div' );
			head.className = 'mwp-cal-head';
			head.textContent = monthName( first );
			box.appendChild( head );

			var grid = document.createElement( 'div' );
			grid.className = 'mwp-cal-grid';

			weekdays().forEach( function ( name ) {
				var cell = document.createElement( 'span' );
				cell.className = 'mwp-cal-dow';
				cell.textContent = name;
				grid.appendChild( cell );
			} );

			// getDay() is Sunday-based; shift so Monday starts the row.
			var lead = ( first.getDay() + 6 ) % 7;
			for ( var b = 0; b < lead; b++ ) {
				grid.appendChild( document.createElement( 'span' ) );
			}

			var days = new Date( first.getFullYear(), first.getMonth() + 1, 0 ).getDate();
			for ( var d = 1; d <= days; d++ ) {
				var date = new Date( first.getFullYear(), first.getMonth(), d );
				var cell = document.createElement( 'button' );

				cell.type = 'button';
				cell.className = 'mwp-cal-day';
				cell.textContent = d;
				cell.dataset.date = toISO( date );

				if ( date < min || ! offered( toISO( date ) ) ) {
					cell.disabled = true;
				} else if ( fixed ) {
					// Worth marking positively: on a once-a-week departure most
					// of the grid is greyed out, and without this the calendar
					// reads as broken rather than as a schedule.
					cell.classList.add( 'is-offered' );
				}
				if ( 0 === date.getDay() ) {
					cell.classList.add( 'is-sunday' );
				}
				if ( toISO( date ) === toISO( value ) ) {
					cell.classList.add( 'is-selected' );
					cell.setAttribute( 'aria-current', 'date' );
				}

				grid.appendChild( cell );
			}

			box.appendChild( grid );
			return box;
		}

		function render() {
			field.textContent = '';

			var icon = document.createElement( 'span' );
			icon.className = 'mwp-cal-icon';
			icon.setAttribute( 'aria-hidden', 'true' );
			icon.textContent = '📅';

			var text = document.createElement( 'span' );
			text.textContent = pretty( value );

			var caret = document.createElement( 'span' );
			caret.className = 'mwp-caret';
			caret.setAttribute( 'aria-hidden', 'true' );
			caret.textContent = '▾';

			field.appendChild( icon );
			field.appendChild( text );
			field.appendChild( caret );

			panel.textContent = '';

			var nav = document.createElement( 'div' );
			nav.className = 'mwp-cal-nav';

			var prev = document.createElement( 'button' );
			prev.type = 'button';
			prev.className = 'mwp-cal-prev';
			prev.textContent = '‹';
			prev.setAttribute( 'aria-label', 'Previous month' );
			// Never page back past the earliest bookable month.
			prev.disabled = new Date( view.getFullYear(), view.getMonth(), 1 ) <=
				new Date( min.getFullYear(), min.getMonth(), 1 );

			var next = document.createElement( 'button' );
			next.type = 'button';
			next.className = 'mwp-cal-next';
			next.textContent = '›';
			next.setAttribute( 'aria-label', 'Next month' );

			nav.appendChild( prev );
			nav.appendChild( next );
			panel.appendChild( nav );

			var months = document.createElement( 'div' );
			months.className = 'mwp-cal-months';
			months.appendChild( month( new Date( view.getFullYear(), view.getMonth(), 1 ) ) );
			months.appendChild( month( new Date( view.getFullYear(), view.getMonth() + 1, 1 ) ) );
			panel.appendChild( months );

			prev.addEventListener( 'click', function () {
				view = new Date( view.getFullYear(), view.getMonth() - 1, 1 );
				render();
			} );

			next.addEventListener( 'click', function () {
				view = new Date( view.getFullYear(), view.getMonth() + 1, 1 );
				render();
			} );

			if ( ! fixed ) {
				return;
			}

			/*
			 * A fixed-departure package needs the calendar to say so, and to
			 * carry the visitor to where the departures are. The first sailing
			 * can be months out; without this the visitor faces two blank
			 * months and a next arrow, and concludes the trip is sold out.
			 */
			var after = new Date( view.getFullYear(), view.getMonth() + 2, 1 );
			var later = only.filter( function ( iso ) {
				return parseISO( iso ) >= after;
			} )[ 0 ];

			var before = only.filter( function ( iso ) {
				return parseISO( iso ) < new Date( view.getFullYear(), view.getMonth(), 1 );
			} ).pop();

			next.disabled = ! later;
			prev.disabled = prev.disabled || ! before;

			var foot = document.createElement( 'p' );
			foot.className = 'mwp-cal-foot';

			var shown = only.filter( function ( iso ) {
				var d = parseISO( iso );
				return d >= new Date( view.getFullYear(), view.getMonth(), 1 ) && d < after;
			} );

			if ( shown.length ) {
				foot.textContent = ( 'pl' === lang.slice( 0, 2 ) )
					? 'Wyloty tylko w zaznaczone dni.'
					: 'Departures on the highlighted days only.';
				panel.appendChild( foot );
				return;
			}

			// Nothing in view: offer the jump rather than describing it.
			var jump = document.createElement( 'button' );
			jump.type = 'button';
			jump.className = 'mwp-cal-jump';

			var target = later || only[ 0 ];
			jump.textContent = ( ( 'pl' === lang.slice( 0, 2 ) ) ? 'Najbliższy wylot: ' : 'Next departure: ' ) + pretty( parseISO( target ) );

			jump.addEventListener( 'click', function () {
				var d = parseISO( target );
				view = new Date( d.getFullYear(), d.getMonth(), 1 );
				render();
			} );

			foot.appendChild( jump );
			panel.appendChild( foot );
		}

		panel.addEventListener( 'click', function ( e ) {
			var day = e.target.closest( '.mwp-cal-day' );
			if ( ! day || day.disabled ) {
				return;
			}

			value = parseISO( day.dataset.date );
			input.value = day.dataset.date;

			// The rest of the picker listens for this, exactly as it would for
			// a change made in the native control.
			input.dispatchEvent( new Event( 'change', { bubbles: true } ) );

			render();
			close();
			field.focus();
		} );

		function open() {
			view = new Date( value.getFullYear(), value.getMonth(), 1 );
			render();
			panel.hidden = false;
			field.setAttribute( 'aria-expanded', 'true' );
		}

		function close() {
			panel.hidden = true;
			field.setAttribute( 'aria-expanded', 'false' );
		}

		field.addEventListener( 'click', function () {
			if ( panel.hidden ) {
				open();
			} else {
				close();
			}
		} );

		// Capture, for the same reason as the traveller panel: the calendar
		// re-renders on every click inside it.
		document.addEventListener( 'click', function ( e ) {
			if ( ! panel.hidden && ! wrap.contains( e.target ) ) {
				close();
			}
		}, true );

		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && ! panel.hidden ) {
				close();
				field.focus();
			}
		} );

		render();
	}

	/**
	 * Opening and closing the overlay.
	 *
	 * Focus moves into the panel on open and back to the button on close, and
	 * the page behind is locked so the modal is the only thing that scrolls —
	 * the small courtesies that separate a dialog from a floating div.
	 */
	function wireModals() {
		var opener = document.querySelectorAll( '.mwp-open-picker' );
		var lastFocus = null;

		function open( modal, trigger ) {
			lastFocus = trigger || null;
			modal.hidden = false;
			document.body.style.overflow = 'hidden';

			var focusable = modal.querySelector( '.mwp-date, button, a' );
			if ( focusable ) {
				focusable.focus();
			}
		}

		function close( modal ) {
			modal.hidden = true;
			document.body.style.overflow = '';
			if ( lastFocus ) {
				lastFocus.focus();
				lastFocus = null;
			}
		}

		for ( var i = 0; i < opener.length; i++ ) {
			opener[ i ].addEventListener( 'click', function ( e ) {
				var modal = document.getElementById( e.currentTarget.dataset.target );
				if ( modal ) {
					open( modal, e.currentTarget );
				}
			} );
		}

		document.addEventListener( 'click', function ( e ) {
			var closer = e.target.closest( '[data-mwp-close]' );
			if ( ! closer ) {
				return;
			}
			var modal = closer.closest( '.mwp-modal' );
			if ( modal ) {
				close( modal );
			}
		} );

		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' !== e.key ) {
				return;
			}
			var open_modals = document.querySelectorAll( '.mwp-modal:not([hidden])' );
			for ( var j = 0; j < open_modals.length; j++ ) {
				// The traveller panel closes first; a second Escape closes the
				// modal, which is what people expect from nested popovers.
				var party = open_modals[ j ].querySelector( '.mwp-party' );
				var cal = open_modals[ j ].querySelector( '.mwp-cal' );
				if ( ( party && ! party.hidden ) || ( cal && ! cal.hidden ) ) {
					continue;
				}
				close( open_modals[ j ] );
			}
		} );
	}

	function initPickers() {
		var pickers = document.querySelectorAll( '[data-mwp-picker]' );
		for ( var i = 0; i < pickers.length; i++ ) {
			setup( pickers[ i ] );
		}
		wireModals();
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', initPickers );
	} else {
		initPickers();
	}
}() );
