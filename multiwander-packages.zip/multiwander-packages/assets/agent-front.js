/**
 * MultiWander — public-facing agent-page JS.
 *
 * Progressive enhancement only: every button here has a working plain
 * link/text underneath it, so if this script fails to load nothing breaks.
 *
 * Copy-to-clipboard for the "or email: …" fallback shown next to the
 * contact button — for visitors whose browser has no mail app to hand a
 * mailto: link to, so clicking the main button does nothing.
 */
( function () {
	'use strict';

	function copyText( text ) {
		if ( navigator.clipboard && window.isSecureContext ) {
			return navigator.clipboard.writeText( text );
		}
		// Fallback for older browsers / non-HTTPS contexts.
		return new Promise( function ( resolve, reject ) {
			var ta = document.createElement( 'textarea' );
			ta.value = text;
			ta.style.position = 'fixed';
			ta.style.opacity = '0';
			document.body.appendChild( ta );
			ta.focus();
			ta.select();
			try {
				document.execCommand( 'copy' ) ? resolve() : reject();
			} catch ( e ) {
				reject( e );
			}
			document.body.removeChild( ta );
		} );
	}

	document.querySelectorAll( '[data-mwpa-copy]' ).forEach( function ( btn ) {
		var original = btn.textContent;
		btn.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			var email = btn.getAttribute( 'data-mwpa-copy' );
			copyText( email ).then( function () {
				btn.textContent = '✓';
				btn.classList.add( 'is-copied' );
				btn.setAttribute( 'aria-label', 'Copied!' );
				setTimeout( function () {
					btn.textContent = original;
					btn.classList.remove( 'is-copied' );
				}, 1800 );
			} ).catch( function () {
				// Clipboard blocked — the address is still right there as
				// selectable text, so this is a silent no-op.
			} );
		} );
	} );

	// ── Inline "send a quick message" form ───────────────────────────
	//
	// A link toggles a small form open; submitting it posts to
	// admin-ajax.php (handled by MWP_Agent::handle_inquiry()) which emails
	// the agent directly. No page reload, no separate contact-form plugin.

	var i18n = ( window.mwpaInquiry && window.mwpaInquiry.i18n ) || {
		sending: 'Sending…',
		sent: 'Sent! The agent will reply by email shortly.',
		error: 'Something went wrong — please try again, or use the email address above.',
		invalid: 'Please fill in your name, a valid email, how many people are traveling, and the anti-spam answer.'
	};

	document.querySelectorAll( '[data-mwpa-toggle]' ).forEach( function ( toggle ) {
		toggle.addEventListener( 'click', function () {
			var formId = toggle.getAttribute( 'data-mwpa-toggle' );
			var form = formId ? document.getElementById( formId ) : null;
			if ( ! form ) { return; }
			var opening = form.hasAttribute( 'hidden' );
			if ( opening ) {
				form.removeAttribute( 'hidden' );
				var first = form.querySelector( 'input[name="mwpa_name"]' );
				if ( first ) { first.focus(); }
			} else {
				form.setAttribute( 'hidden', 'hidden' );
			}
			toggle.setAttribute( 'aria-expanded', opening ? 'true' : 'false' );
		} );
	} );

	document.querySelectorAll( '.mwpa-inquiry' ).forEach( function ( form ) {
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();

			var status = form.querySelector( '.mwpa-inquiry-status' );
			var submit = form.querySelector( '.mwpa-inquiry-submit' );
			var nameEl = form.querySelector( 'input[name="mwpa_name"]' );
			var emailEl = form.querySelector( 'input[name="mwpa_email"]' );
			var peopleEl = form.querySelector( 'input[name="mwpa_people"]' );
			var mathEl = form.querySelector( 'input[name="mwpa_math"]' );

			var emailOk = emailEl && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( emailEl.value.trim() );
			var peopleOk = peopleEl && parseInt( peopleEl.value, 10 ) >= 1;
			var mathFilled = mathEl && mathEl.value.trim() !== '';
			if ( ! nameEl.value.trim() || ! emailOk || ! peopleOk || ! mathFilled ) {
				if ( status ) {
					status.textContent = i18n.invalid;
					status.className = 'mwpa-inquiry-status is-error';
				}
				return;
			}

			if ( ! window.mwpaInquiry || ! window.mwpaInquiry.ajaxUrl ) {
				if ( status ) {
					status.textContent = i18n.error;
					status.className = 'mwpa-inquiry-status is-error';
				}
				return;
			}

			if ( submit ) { submit.disabled = true; }
			if ( status ) {
				status.textContent = i18n.sending;
				status.className = 'mwpa-inquiry-status';
			}

			var data = new FormData( form );
			// The nonce in each form's hidden field is already correct
			// (rendered server-side per form); no need to override it here.

			fetch( window.mwpaInquiry.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				body: data
			} )
				.then( function ( r ) { return r.json(); } )
				.then( function ( json ) {
					if ( json && json.success ) {
						if ( status ) {
							status.textContent = ( json.data && json.data.message ) || i18n.sent;
							status.className = 'mwpa-inquiry-status is-success';
						}
						form.reset();
						if ( submit ) { submit.disabled = true; } // stays disabled — message already sent
					} else {
						if ( status ) {
							status.textContent = ( json && json.data && json.data.message ) || i18n.error;
							status.className = 'mwpa-inquiry-status is-error';
						}
						if ( submit ) { submit.disabled = false; }
					}
				} )
				.catch( function () {
					if ( status ) {
						status.textContent = i18n.error;
						status.className = 'mwpa-inquiry-status is-error';
					}
					if ( submit ) { submit.disabled = false; }
				} );
		} );
	} );

}() );
