/**
 * MultiWander Packages — catalogue filtering.
 *
 * The whole catalogue is already in the page; these two selects only decide
 * what stays visible. That keeps every filter change instant, lets the page be
 * served from cache, and means there is no endpoint to keep alive.
 *
 * With JavaScript off the selects do nothing and the full list shows, which is
 * a perfectly good page — so nothing here is load-bearing.
 */
( function () {
	'use strict';

	function setup( root ) {
		var items = root.querySelectorAll( '.mwp-cat-item' );
		var selects = root.querySelectorAll( '[data-filter]' );
		var count = root.querySelector( '.mwp-filter-count' );
		var none = root.querySelector( '.mwp-cat-none' );
		var reset = root.querySelector( '.mwp-filter-reset' );

		if ( ! items.length || ! selects.length ) {
			return;
		}

		/** Does this card carry the wanted value in that attribute? */
		function has( item, attribute, wanted ) {
			if ( ! wanted ) {
				return true;
			}
			// Space-delimited list, so a whole-token match — "thailand" must
			// not match "thailand-islands".
			var values = ( item.getAttribute( attribute ) || '' ).split( ' ' );
			return values.indexOf( wanted ) !== -1;
		}

		function value( name ) {
			for ( var s = 0; s < selects.length; s++ ) {
				if ( name === selects[ s ].dataset.filter ) {
					return selects[ s ].value;
				}
			}
			return '';
		}

		function set( name, to ) {
			for ( var s = 0; s < selects.length; s++ ) {
				if ( name === selects[ s ].dataset.filter ) {
					selects[ s ].value = to;
				}
			}
		}

		function apply() {
			var country = value( 'country' );
			var theme = value( 'theme' );

			var shown = 0;

			for ( var i = 0; i < items.length; i++ ) {
				var keep = has( items[ i ], 'data-countries', country )
					&& has( items[ i ], 'data-themes', theme );

				items[ i ].hidden = ! keep;
				if ( keep ) {
					shown++;
				}
			}

			if ( count ) {
				var template = 1 === shown
					? ( count.dataset.one || '%d' )
					: ( count.dataset.many || '%d' );
				count.textContent = template.replace( '%d', shown );
			}

			if ( none ) {
				none.hidden = shown !== 0;
			}

			if ( reset ) {
				reset.hidden = ! country && ! theme;
			}

			paintChips( theme );
		}

		/*
		 * One filter at a time: a country OR a theme, never both.
		 *
		 * The two together answer "Thailand AND Safari", which in a catalogue
		 * this size is usually nothing at all — and a visitor who lands on an
		 * empty page assumes you have nothing rather than that they asked a
		 * narrow question. Choosing one clears the other, so every selection
		 * leads somewhere.
		 */
		for ( var j = 0; j < selects.length; j++ ) {
			selects[ j ].addEventListener( 'change', function ( e ) {
				var which = e.currentTarget.dataset.filter;
				set( 'country' === which ? 'theme' : 'country', '' );
				apply();
			} );
		}

		/*
		 * The theme chips are revealed only now, by the script that makes them
		 * work — rendered hidden, so a visitor without JavaScript never sees a
		 * row of buttons that do nothing. They drive the select rather than
		 * holding state of their own, so there is one source of truth.
		 */
		var chipBox = root.querySelector( '[data-mwp-chips]' );

		if ( chipBox ) {
			chipBox.hidden = false;

			var chipLabel = root.querySelector( '[data-mwp-chips-label]' );
			if ( chipLabel ) {
				chipLabel.hidden = false;
			}

			/*
			 * With the chips on screen the theme dropdown is the same choice
			 * offered twice, so it goes — but only here, in the script, so
			 * that without JavaScript it is still the working control.
			 */
			var themeField = root.querySelector( '[data-mwp-theme-field]' );
			if ( themeField ) {
				themeField.hidden = true;
			}

			chipBox.addEventListener( 'click', function ( e ) {
				var chip = e.target.closest ? e.target.closest( '.mwp-chip' ) : null;
				if ( ! chip ) {
					return;
				}

				if ( chip.hasAttribute( 'data-mwp-chips-toggle' ) ) {
					expand( 'true' !== chip.getAttribute( 'aria-expanded' ) );
					return;
				}

				set( 'theme', chip.dataset.chip || '' );
				set( 'country', '' );
				apply();
			} );
		}

		/*
		 * Travel Compositor puts a lot of themes on a package, and shown all at
		 * once they bury the six MultiWander actually sells — each of which has
		 * its own landing page. The six are rendered first; the rest sit behind
		 * this toggle, which is the whole reason the filter panel now fits on a
		 * phone without pushing the trips off the screen.
		 */
		var more = root.querySelector( '[data-mwp-chips-more]' );
		var toggle = root.querySelector( '[data-mwp-chips-toggle]' );

		function expand( open ) {
			if ( ! more || ! toggle ) {
				return;
			}
			more.hidden = ! open;
			toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			toggle.textContent = open
				? ( toggle.dataset.less || '−' )
				: ( toggle.dataset.more || '+' );
		}

		function paintChips( theme ) {
			if ( ! chipBox ) {
				return;
			}
			var chips = chipBox.querySelectorAll( '.mwp-chip' );
			for ( var c = 0; c < chips.length; c++ ) {
				if ( chips[ c ].hasAttribute( 'data-mwp-chips-toggle' ) ) {
					continue;
				}
				var on = ( chips[ c ].dataset.chip || '' ) === theme;
				chips[ c ].classList.toggle( 'is-on', on );
				chips[ c ].setAttribute( 'aria-pressed', on ? 'true' : 'false' );

				// A theme chosen from the hidden group must not leave the
				// visitor looking at a filtered page with no visible reason
				// for it, so the group opens to show what is selected.
				if ( on && theme && more && more.contains( chips[ c ] ) ) {
					expand( true );
				}
			}
		}

		/*
		 * The panel shrinks once it is stuck to the top.
		 *
		 * Full height it is right at the top of the page, where it is the
		 * thing you came to use. Stuck to the header while you scroll the
		 * trips it is in the way — which is what it was doing. CSS alone
		 * cannot tell a sticky element it has stuck, so a zero-height
		 * sentinel above the panel reports when it leaves the viewport, and
		 * the class does the rest. No scroll handler, so nothing runs on the
		 * main thread while the page moves.
		 */
		var panel = root.querySelector( '.mwp-filters' );

		if ( panel && window.IntersectionObserver ) {
			var mark = document.createElement( 'div' );
			mark.className = 'mwp-filters-mark';
			panel.parentNode.insertBefore( mark, panel );

			new IntersectionObserver(
				function ( entries ) {
					var stuck = ! entries[ 0 ].isIntersecting;
					panel.classList.toggle( 'is-stuck', stuck );

					/*
					 * The chips are what the compact bar gives up, so the
					 * theme dropdown comes back to replace them — otherwise a
					 * visitor scrolling the list could change country but not
					 * theme, which is half a filter.
					 */
					var field = root.querySelector( '[data-mwp-theme-field]' );
					if ( field && chipBox ) {
						field.hidden = ! stuck;
					}
				},
				// The header the panel sticks under, so the switch happens
				// exactly as the panel reaches it and not a scroll later.
				{ rootMargin: '-136px 0px 0px 0px', threshold: 0 }
			).observe( mark );
		}

		if ( reset ) {
			reset.addEventListener( 'click', function () {
				for ( var k = 0; k < selects.length; k++ ) {
					selects[ k ].value = '';
				}
				apply();
			} );
		}

		apply();
	}

	function init() {
		var roots = document.querySelectorAll( '[data-mwp-catalogue]' );
		for ( var i = 0; i < roots.length; i++ ) {
			setup( roots[ i ] );
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
