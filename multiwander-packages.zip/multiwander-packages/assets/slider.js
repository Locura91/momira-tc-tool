/**
 * MultiWander Packages — offer slider.
 *
 * Matches the behaviour of the hand-built slider on the site today: dots,
 * 7-second autoplay, looping, pause on hover, swipe on touch, and 3/2/1 cards
 * across desktop/tablet/mobile.
 *
 * The track is a native scroll-snap row rather than a transformed flex strip.
 * That keeps real touch scrolling, momentum, keyboard support and the browser's
 * own accessibility handling for free — if this script never loads, the slider
 * still scrolls, it just loses the arrows and dots.
 *
 * No library, no jQuery.
 */
( function () {
	'use strict';

	/*
	 * Autoplay is off.
	 *
	 * It kept moving the row while people were reading it, and the offer that
	 * suffered was always the first one: by the time a visitor reached for it,
	 * the track had already crept forward and the arrows were fighting them for
	 * control. A row of offers is something to browse, not a billboard, and a
	 * visitor who wants the next card will press the arrow.
	 *
	 * Set mwpSliderAutoplay to a number of milliseconds before this script runs
	 * to bring it back.
	 */
	var AUTOPLAY_MS = window.mwpSliderAutoplay || 0;

	function reducedMotion() {
		return window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	}

	function setup( slider ) {
		var track = slider.querySelector( '.mwp-grid' );
		var prev = slider.querySelector( '.mwp-prev' );
		var next = slider.querySelector( '.mwp-next' );
		var dotsBox = slider.querySelector( '.mwp-dots' );

		if ( ! track ) {
			return;
		}

		var timer = null;
		var paused = false;

		function cards() {
			return track.querySelectorAll( '.mwp-card' );
		}

		function perView() {
			var w = window.innerWidth;
			if ( w <= 768 ) {
				return 1;
			}
			if ( w <= 1024 ) {
				return 2;
			}
			return 3;
		}

		function step() {
			var first = track.querySelector( '.mwp-card' );
			if ( ! first ) {
				return track.clientWidth;
			}
			var gap = parseFloat( getComputedStyle( track ).columnGap ) || 24;
			return first.getBoundingClientRect().width + gap;
		}

		function maxScroll() {
			return Math.max( 0, track.scrollWidth - track.clientWidth );
		}

		/*
		 * Pages are SCREENFULS, not cards.
		 *
		 * This used to be "one page per card position" — cards minus the number
		 * visible, plus one. With four offers that is two pages and it behaves.
		 * With twenty-five it is twenty-three, each one card wide, and the row
		 * crawls: every arrow click nudges it a third of a screen, so it looks
		 * like the slider gives up a few offers in. Counting screenfuls instead
		 * means one click moves one full view no matter how many offers there
		 * are, and the dots stay a readable handful rather than twenty-three.
		 */
		function pageCount() {
			var width = track.clientWidth;
			if ( ! width ) {
				return 1;
			}
			return Math.max( 1, Math.ceil( ( track.scrollWidth - 2 ) / width ) );
		}

		function currentPage() {
			var width = track.clientWidth;
			if ( ! width ) {
				return 0;
			}

			// The last page is almost never a whole screen wide — four cards
			// three-across overflow by a couple of hundred pixels, not by a
			// full view. Rounding scrollLeft/width therefore reported page 0
			// even when the row was scrolled hard against its end, so "next"
			// kept asking to go where it already was and nothing moved.
			if ( track.scrollLeft >= maxScroll() - 4 ) {
				return pageCount() - 1;
			}

			return Math.min( pageCount() - 1, Math.round( track.scrollLeft / width ) );
		}

		function scrollToPage( index, smooth ) {
			scrollToOffset( Math.min( index * track.clientWidth, maxScroll() ), smooth );
		}

		/**
		 * Move the track, animated, in a way that cannot get stuck.
		 *
		 * Measured on the live site, three things refuse to move this element:
		 *
		 *  1. scroll-snap-type: x mandatory rejects a programmatic scrollLeft
		 *     outright — set it to 200 and it stays where it was.
		 *  2. scrollTo({behavior:'smooth'}) asked for 363 and delivered 0.
		 *  3. A frame-counted requestAnimationFrame tween fared no better: rAF
		 *     was firing about once every 300ms, so the tween never arrived.
		 *
		 * Only one thing moved it every time: snapping off, scroll-behavior
		 * auto, assign scrollLeft, put both back. So that is still exactly what
		 * happens — the animation is a series of those assignments rather than
		 * anything handed to the browser to manage.
		 *
		 * Two rules keep the earlier failure from coming back. Each frame reads
		 * the CLOCK, not a frame counter, so a browser painting at 3fps lands
		 * on the same pixel at the same moment as one painting at 60 — it just
		 * looks choppier. And a timer set for the full duration performs the
		 * final assignment regardless, so even if rAF never fires again the row
		 * still arrives where it was sent. An arrow press always moves the row.
		 *
		 * @param {number}  target Pixel offset to move to.
		 * @param {boolean} smooth False to jump, as the dots and resize do.
		 */
		var animation = null;

		function scrollToOffset( target, smooth ) {
			var snap = track.style.scrollSnapType;
			var behaviour = track.style.scrollBehavior;
			var from = track.scrollLeft;
			var to = Math.max( 0, Math.min( target, maxScroll() ) );

			if ( animation ) {
				window.clearTimeout( animation );
				animation = null;
			}

			track.style.scrollSnapType = 'none';
			track.style.scrollBehavior = 'auto';

			function settle() {
				track.scrollLeft = to;
				// Restored on the next tick: putting them back in the same
				// frame lets the snap logic pull the row straight back again.
				window.setTimeout( function () {
					track.style.scrollSnapType = snap;
					track.style.scrollBehavior = behaviour;
					paint();
				}, 0 );
			}

			if ( false === smooth || reducedMotion() || Math.abs( to - from ) < 2 ) {
				settle();
				return;
			}

			// Long enough to read as movement, short enough that a second
			// click never feels queued behind the first.
			var duration = 420;
			var started = ( window.performance && performance.now ) ? performance.now() : Date.now();
			var done = false;

			function finish() {
				if ( done ) {
					return;
				}
				done = true;
				settle();
			}

			function frame() {
				if ( done ) {
					return;
				}

				var now = ( window.performance && performance.now ) ? performance.now() : Date.now();
				var t = Math.min( 1, ( now - started ) / duration );

				// Ease-out cubic: quick off the mark, gentle into place, which
				// is what makes it read as one card handing over to the next
				// rather than the row being dragged.
				var eased = 1 - Math.pow( 1 - t, 3 );

				track.scrollLeft = from + ( to - from ) * eased;

				if ( t < 1 ) {
					window.requestAnimationFrame( frame );
				} else {
					finish();
				}
			}

			animation = window.setTimeout( finish, duration + 60 );
			window.requestAnimationFrame( frame );
		}

		function buildDots() {
			if ( ! dotsBox ) {
				return;
			}
			var count = pageCount();

			// Nothing to page through — no dots rather than a single dead dot.
			if ( count < 2 ) {
				dotsBox.innerHTML = '';
				return;
			}

			dotsBox.innerHTML = '';
			for ( var i = 0; i < count; i++ ) {
				var dot = document.createElement( 'button' );
				dot.type = 'button';
				dot.className = 'mwp-dot';
				dot.setAttribute( 'aria-label', 'Slide ' + ( i + 1 ) );
				dot.dataset.index = String( i );
				dot.addEventListener( 'click', function ( e ) {
					scrollToPage( parseInt( e.currentTarget.dataset.index, 10 ) );
					restart();
				} );
				dotsBox.appendChild( dot );
			}
			paint();
		}

		function paint() {
			var page = currentPage();

			if ( dotsBox ) {
				var dots = dotsBox.querySelectorAll( '.mwp-dot' );
				for ( var i = 0; i < dots.length; i++ ) {
					dots[ i ].classList.toggle( 'is-active', i === page );
					dots[ i ].setAttribute( 'aria-current', i === page ? 'true' : 'false' );
				}
			}

			// Arrows loop, so they are never disabled — only hidden when the
			// whole set already fits on screen.
			var overflowing = maxScroll() > 4;
			if ( prev ) {
				prev.hidden = ! overflowing;
			}
			if ( next ) {
				next.hidden = ! overflowing;
			}
			if ( dotsBox ) {
				dotsBox.hidden = ! overflowing;
			}
		}

		/**
		 * Where each card starts, as a scroll offset.
		 *
		 * Measured from the rendered boxes rather than calculated from a card
		 * width and a gap, because the last card in a row is often a different
		 * width and a calculated step drifts a few pixels further out of true
		 * with every press until cards are sliced down the middle.
		 *
		 * @return {number[]} Ascending scroll offsets, one per card.
		 */
		function cardOffsets() {
			var list = cards();
			var base = track.getBoundingClientRect().left - track.scrollLeft;
			var out = [];

			for ( var i = 0; i < list.length; i++ ) {
				out.push( Math.round( list[ i ].getBoundingClientRect().left - base ) );
			}

			return out;
		}

		/**
		 * Move one CARD, from wherever the row currently sits.
		 *
		 * It used to move a whole screenful, which on a three-across row threw
		 * away every card you were looking at and replaced it with three
		 * strangers. One card at a time keeps two of the three in place, so
		 * the row reads as continuous — the visitor keeps their bearings, and
		 * a card that caught their eye is still there after the press.
		 *
		 * Deliberately not "work out which card we are on, then go to the next
		 * one": indexes go stale as the row is swiped or resized. Measuring
		 * from the live scroll position and taking the next boundary past it
		 * cannot get stuck; it just runs out of track, and then it loops.
		 *
		 * @param {number} delta 1 forward, -1 back.
		 */
		function go( delta ) {
			var max = maxScroll();
			var at = track.scrollLeft;
			var offsets = cardOffsets();
			var target = null;
			var i;

			if ( delta > 0 && at >= max - 4 ) {
				scrollToOffset( 0 );
				return;
			}

			if ( delta < 0 && at <= 4 ) {
				scrollToOffset( max );
				return;
			}

			if ( delta > 0 ) {
				for ( i = 0; i < offsets.length; i++ ) {
					if ( offsets[ i ] > at + 4 ) {
						target = offsets[ i ];
						break;
					}
				}
			} else {
				for ( i = offsets.length - 1; i >= 0; i-- ) {
					if ( offsets[ i ] < at - 4 ) {
						target = offsets[ i ];
						break;
					}
				}
			}

			// No boundary that way — a single card wider than the track, or a
			// row that has run out. One track-width keeps the arrow honest.
			if ( null === target ) {
				target = at + ( delta * track.clientWidth );
			}

			scrollToOffset( Math.max( 0, Math.min( target, max ) ) );
		}

		function start() {
			if ( ! AUTOPLAY_MS || timer || paused || reducedMotion() || pageCount() < 2 ) {
				return;
			}
			timer = window.setInterval( function () {
				if ( ! document.hidden ) {
					go( 1 );
				}
			}, AUTOPLAY_MS );
		}

		function stop() {
			if ( timer ) {
				window.clearInterval( timer );
				timer = null;
			}
		}

		function restart() {
			stop();
			start();
		}

		/*
		 * One delegated listener in the capture phase rather than one per
		 * button. The arrows sit over the card row, and a click that reaches
		 * a card's link first would otherwise navigate away instead of
		 * paging — capture gets there before anything inside can act on it.
		 */
		slider.addEventListener( 'click', function ( e ) {
			var button = e.target.closest ? e.target.closest( '.mwp-prev, .mwp-next' ) : null;

			if ( ! button || ! slider.contains( button ) ) {
				return;
			}

			e.preventDefault();
			e.stopPropagation();

			go( button.classList.contains( 'mwp-next' ) ? 1 : -1 );
			restart();
		}, true );

		/*
		 * Touch stops the autoplay for good.
		 *
		 * A phone has no hover, so the pause-on-hover below never fires there:
		 * the row kept creeping forward every seven seconds while the visitor
		 * was reading it, and any attempt to swipe back to the first offer was
		 * undone before they arrived. On a touch screen the visitor is driving,
		 * and the slider should stay where they put it.
		 */
		slider.addEventListener( 'touchstart', function () {
			paused = true;
			stop();
		}, { passive: true } );

		// Pause while the visitor is looking at or interacting with it.
		slider.addEventListener( 'mouseenter', function () {
			paused = true;
			stop();
		} );
		slider.addEventListener( 'mouseleave', function () {
			paused = false;
			start();
		} );
		slider.addEventListener( 'focusin', function () {
			paused = true;
			stop();
		} );
		slider.addEventListener( 'focusout', function () {
			paused = false;
			start();
		} );
		track.addEventListener( 'touchstart', stop, { passive: true } );
		track.addEventListener( 'touchend', restart, { passive: true } );

		track.addEventListener( 'scroll', function () {
			window.requestAnimationFrame( paint );
		}, { passive: true } );

		window.addEventListener( 'resize', function () {
			window.requestAnimationFrame( function () {
				buildDots();
				paint();
			} );
		}, { passive: true } );

		// Images finishing loading changes the track width.
		if ( 'ResizeObserver' in window ) {
			new ResizeObserver( function () {
				buildDots();
				paint();
			} ).observe( track );
		}

		buildDots();
		paint();
		start();
	}

	function init() {
		var sliders = document.querySelectorAll( '.mwp-slider' );
		for ( var i = 0; i < sliders.length; i++ ) {
			setup( sliders[ i ] );
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
