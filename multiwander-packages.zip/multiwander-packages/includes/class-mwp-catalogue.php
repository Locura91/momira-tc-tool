<?php
/**
 * [multiwander_catalogue] — every package on the site, filterable.
 *
 * The booking engine has a search page listing its whole inventory. This is
 * the MultiWander equivalent with one deliberate difference: it lists only the
 * packages a human has actually put on this site by entering its ID. The
 * engine's catalogue is everything Momira sells; this one is everything
 * MultiWander has chosen to sell, which is the list the business actually
 * needs to see and the visitor actually benefits from.
 *
 * It follows from that that the page needs no maintenance. Add an ID anywhere
 * on the site and the trip joins the catalogue, with its country and its
 * themes already attached; take the page down and it leaves. There is no
 * second list to keep in step.
 *
 * Filtering happens in the browser rather than on the server. The whole
 * catalogue is a few dozen trips, which is far below the point where paging
 * would help, and in exchange every filter change is instant, the page works
 * from cache, and there is no AJAX endpoint to secure or keep alive. With
 * JavaScript off the visitor simply sees the full list, which is a reasonable
 * page in its own right.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Catalogue {

	public static function init() {
		add_shortcode( 'multiwander_catalogue', array( __CLASS__, 'render' ) );
	}

	/**
	 * Every published package page in one language, newest ID first.
	 *
	 * @param string $lang Language slug.
	 * @return WP_Post[]
	 */
	public static function packages( $lang ) {
		$args = array(
			'post_type'        => 'page',
			'post_status'      => 'publish',
			'posts_per_page'   => -1,
			'orderby'          => 'title',
			'order'            => 'ASC',
			'no_found_rows'    => true,
			'suppress_filters' => false,
			'meta_query'       => array(
				array(
					'key'     => MWP_META_ID,
					'compare' => 'EXISTS',
				),
			),
		);

		if ( function_exists( 'pll_current_language' ) ) {
			$args['lang'] = $lang;
		}

		return get_posts( $args );
	}

	/**
	 * Fold a label into a value safe for an attribute and a select.
	 *
	 * @param string $text Label.
	 * @return string
	 */
	protected static function key( $text ) {
		$text = remove_accents( (string) $text );
		$text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
		$text = preg_replace( '/[^a-z0-9]+/', '-', $text );

		return trim( $text, '-' );
	}

	/**
	 * The countries a package visits.
	 *
	 * Travel Compositor gives a country per destination, already in the right
	 * language, so a Polish page filters on "Tajlandia" and the English one on
	 * "Thailand" without a translation table.
	 *
	 * @param array $data Package payload.
	 * @return array<string,string> key => label
	 */
	public static function countries( array $data ) {
		$out = array();

		foreach ( (array) ( $data['destinations'] ?? array() ) as $destination ) {
			$name = trim( (string) ( $destination['country'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}
			$out[ self::key( $name ) ] = $name;
		}

		return $out;
	}

	/**
	 * The themes a package carries.
	 *
	 * @param array $data Package payload.
	 * @return array<string,string> key => label
	 */
	public static function themes( array $data ) {
		$out = array();

		foreach ( (array) ( $data['themes'] ?? array() ) as $theme ) {
			$name = trim( (string) $theme );
			if ( '' === $name ) {
				continue;
			}
			$out[ self::key( $name ) ] = $name;
		}

		return $out;
	}

	/**
	 * Split the themes into the headline ones and the long tail.
	 *
	 * Travel Compositor attaches a lot of themes to a package — "Historical
	 * and Cultural", "Individually combined", and a dozen more — and shown as
	 * one undifferentiated row they bury the six themes MultiWander actually
	 * merchandises, each of which has its own landing page on the site. So the
	 * six come first, in the order the business ranks them, and everything
	 * else waits behind one tap.
	 *
	 * The six are not a second list to maintain: they are exactly the themes
	 * that have theme pages, read from MWP_Themes, so adding or removing a
	 * theme page changes this row with them.
	 *
	 * @param array<string,string> $themes key => label, as found on the trips.
	 * @return array{0: array<string,string>, 1: array<string,string>} Primary, then the rest.
	 */
	protected static function rank_themes( array $themes ) {
		$order = apply_filters(
			'mwp_catalogue_primary_themes',
			array( 'city_break', 'island_hopping', 'car_rental', 'safari', 'city_beach', 'around_the_world' )
		);

		$primary = array();
		$rest    = $themes;

		foreach ( (array) $order as $wanted ) {
			foreach ( $themes as $key => $label ) {
				if ( MWP_Themes::key_for_label( $label ) === $wanted ) {
					$primary[ $key ] = $label;
					unset( $rest[ $key ] );
					break;
				}
			}
		}

		return array( $primary, $rest );
	}

	/**
	 * Render the catalogue.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'heading' => '',
				'columns' => 3,
			),
			$atts,
			'multiwander_catalogue'
		);

		$lang = mwp_current_lang();
		$en   = ( 'en' === $lang );
		$t    = function ( $pl, $english ) use ( $en ) {
			return $en ? $english : $pl;
		};

		$pages = self::packages( $lang );

		if ( ! $pages ) {
			return current_user_can( 'edit_posts' )
				? '<p class="mwp mwp-empty">' . esc_html__( 'No packages have been added to the site yet.', 'multiwander-packages' ) . '</p>'
				: '';
		}

		// Build the two filter lists from the trips that are actually here, so
		// a country with nothing in it never appears as an option that leads
		// to an empty page.
		$countries = array();
		$themes    = array();
		$rows      = array();

		foreach ( $pages as $page ) {
			$data = MWP_Sync::get_data( $page->ID );
			if ( ! $data ) {
				continue;
			}

			$page_countries = self::countries( $data );
			$page_themes    = self::themes( $data );

			$countries += $page_countries;
			$themes    += $page_themes;

			$rows[] = array(
				'page'      => $page,
				'data'      => $data,
				'countries' => array_keys( $page_countries ),
				'themes'    => array_keys( $page_themes ),
			);
		}

		if ( ! $rows ) {
			return '';
		}

		asort( $countries, SORT_NATURAL | SORT_FLAG_CASE );
		asort( $themes, SORT_NATURAL | SORT_FLAG_CASE );

		$columns = max( 2, min( 4, (int) $atts['columns'] ) );

		ob_start();
		?>
		<section class="mwp mwp-catalogue mwp-cols-<?php echo esc_attr( $columns ); ?>" data-mwp-catalogue>

			<?php if ( $atts['heading'] ) : ?>
				<h2 class="mwp-offers-heading"><?php echo esc_html( $atts['heading'] ); ?></h2>
			<?php endif; ?>

			<form class="mwp-filters" onsubmit="return false;">
				<div class="mwp-filters-row">
					<label class="mwp-filter">
						<span><?php echo esc_html( $t( 'Kierunek', 'Destination' ) ); ?></span>
						<select data-filter="country">
							<option value=""><?php echo esc_html( $t( 'Wszystkie kraje', 'All countries' ) ); ?></option>
							<?php foreach ( $countries as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>

					<label class="mwp-filter" data-mwp-theme-field>
						<span><?php echo esc_html( $t( 'Rodzaj podróży', 'Travel theme' ) ); ?></span>
						<select data-filter="theme">
							<option value=""><?php echo esc_html( $t( 'Wszystkie rodzaje', 'All themes' ) ); ?></option>
							<?php foreach ( $themes as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>

					<p class="mwp-filter-count" aria-live="polite"
						data-one="<?php echo esc_attr( $t( '%d podróż', '%d trip' ) ); ?>"
						data-many="<?php echo esc_attr( $t( '%d podróży', '%d trips' ) ); ?>">
					</p>
				</div>

				<?php
				/*
				 * The themes again, as one-tap chips.
				 *
				 * The select below is what actually holds the value — these
				 * only set it — so the filter still works with the keyboard,
				 * with a screen reader, and with JavaScript off, where the
				 * chips simply are not rendered. A dropdown hides the range of
				 * a catalogue; laid out, the themes ARE the merchandising.
				 */
				?>
				<?php
				list( $primary_themes, $other_themes ) = self::rank_themes( $themes );

				// With no headline themes on the trips in hand there is nothing
				// to rank, so the whole list is shown flat rather than putting
				// an arbitrary six in front.
				if ( ! $primary_themes ) {
					$primary_themes = $themes;
					$other_themes   = array();
				}
				?>
				<?php if ( count( $themes ) > 1 ) : ?>
					<p class="mwp-chips-label" data-mwp-chips-label hidden>
						<?php echo esc_html( $t( 'lub wybierz rodzaj podróży', 'or pick a travel theme' ) ); ?>
					</p>
					<div class="mwp-chips" data-mwp-chips hidden>
						<button type="button" class="mwp-chip is-on" data-chip="">
							<?php echo esc_html( $t( 'Wszystko', 'Everything' ) ); ?>
						</button>
						<?php foreach ( $primary_themes as $key => $label ) : ?>
							<button type="button" class="mwp-chip" data-chip="<?php echo esc_attr( $key ); ?>">
								<?php echo esc_html( $label ); ?>
							</button>
						<?php endforeach; ?>

						<?php if ( $other_themes ) : ?>
							<span class="mwp-chips-more" data-mwp-chips-more hidden>
								<?php foreach ( $other_themes as $key => $label ) : ?>
									<button type="button" class="mwp-chip" data-chip="<?php echo esc_attr( $key ); ?>">
										<?php echo esc_html( $label ); ?>
									</button>
								<?php endforeach; ?>
							</span>

							<button type="button" class="mwp-chip mwp-chip-toggle" data-mwp-chips-toggle
								aria-expanded="false"
								data-more="<?php echo esc_attr( sprintf( $t( '+ %d więcej', '+ %d more' ), count( $other_themes ) ) ); ?>"
								data-less="<?php echo esc_attr( $t( '− mniej', '− less' ) ); ?>">
								<?php echo esc_html( sprintf( $t( '+ %d więcej', '+ %d more' ), count( $other_themes ) ) ); ?>
							</button>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<button type="button" class="mwp-filter-reset" hidden>
					<?php echo esc_html( $t( 'Wyczyść filtry', 'Clear filters' ) ); ?>
				</button>
			</form>

			<div class="mwp-grid">
				<?php foreach ( $rows as $row ) : ?>
					<div class="mwp-cat-item"
						data-countries="<?php echo esc_attr( implode( ' ', $row['countries'] ) ); ?>"
						data-themes="<?php echo esc_attr( implode( ' ', $row['themes'] ) ); ?>">
						<?php MWP_Frontend::render_card( $row['page'], $lang ); ?>
					</div>
				<?php endforeach; ?>
			</div>

			<?php
			/*
			 * What this page is a list OF.
			 *
			 * A catalogue is the one page type where structured data pays for
			 * itself: it tells a search engine that these sixty links are one
			 * ranked list of trips rather than sixty unrelated links in a div,
			 * which is the difference between a listing that can earn a rich
			 * result and one that reads as a page of navigation. Only the
			 * position and the URL are claimed — the trip's own page carries
			 * its price and itinerary, and repeating those here would be two
			 * sources of truth for the same fact.
			 */
			$list = array();
			foreach ( $rows as $i => $row ) {
				$list[] = array(
					'@type'    => 'ListItem',
					'position' => $i + 1,
					'url'      => get_permalink( $row['page'] ),
					'name'     => get_the_title( $row['page'] ),
				);
			}
			?>
			<script type="application/ld+json"><?php
				echo wp_json_encode( // phpcs:ignore WordPress.Security.EscapeOutput
					array(
						'@context'        => 'https://schema.org',
						'@type'           => 'ItemList',
						'name'            => $atts['heading'] ? $atts['heading'] : get_the_title(),
						'numberOfItems'   => count( $list ),
						'itemListOrder'   => 'https://schema.org/ItemListUnordered',
						'itemListElement' => $list,
					),
					JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
				);
			?></script>

			<p class="mwp-cat-none" hidden>
				<?php echo esc_html( $t(
					'Nie mamy jeszcze gotowego pakietu w tej kombinacji — napisz do nas, a ułożymy go dla Ciebie.',
					'We have no ready-made package in that combination yet — write to us and we will build one for you.'
				) ); ?>
			</p>
		</section>
		<?php
		return ob_get_clean();
	}
}
