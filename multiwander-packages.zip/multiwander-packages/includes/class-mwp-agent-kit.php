<?php
/**
 * Travel Agent Kit — dedicated admin page for travel agents.
 *
 * v1.84.0 changes
 * ───────────────
 * • Every agent-editable field — not just the content ones — now goes
 *   through the admin-approval workflow: saved to mwp_agent_pending meta
 *   and not written to the live fields until an admin approves them. Only
 *   the "enabled" visibility switch itself still saves immediately.
 * • The approval email goes straight to info@multiwander.com rather than
 *   whatever the site's admin_email happens to be.
 * • profile.php also locks first name and last name for a restricted user,
 *   both client-side and (since a reverted field only hides, it doesn't
 *   block, a determined edit via devtools) server-side on save.
 *
 * v1.69.9 changes
 * ───────────────
 * • Social-media URLs moved into the Contact card (no separate card).
 * • "View my page" banner shown prominently below the topbar when linked.
 * • Content fields (headline, intro, bio, regions repeater, style, languages)
 *   now go through an admin-approval workflow: saved to mwp_agent_pending meta
 *   and not written to the live fields until an admin approves them.
 * • Regions of expertise replaced with a simple text-input repeater stored as
 *   a JSON array in mwp_agent_regions; the rich-text editor is gone.
 * • Password fields hidden via CSS for restricted users on profile.php.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Agent_Kit {

	const ROLE = 'travel_agent';
	const PAGE = 'mwp-agent-kit';
	const CAP  = 'mwp_agent_kit';

	// Nonce action used on every kit save.
	const NONCE = 'mwp_agent_kit_save';

	// Meta key that holds JSON of pending (unapproved) content changes.
	const PENDING_META = 'mwp_agent_pending';

	/**
	 * Every field that requires admin approval before going live. This is
	 * everything an agent can change on the kit page — only the 'enabled'
	 * visibility switch itself is saved immediately (see handle_save()).
	 */
	const APPROVAL_FIELDS = array(
		'photo_id', 'gender',
		'stat1_num', 'stat1_label', 'stat2_num', 'stat2_label', 'stat3_num', 'stat3_label',
		'email', 'phone', 'whatsapp', 'wap_id', 'cta_label', 'cta_url',
		'facebook_url', 'instagram_url', 'linkedin_url', 'youtube_url',
		'headline', 'intro', 'bio', 'regions', 'style', 'languages',
	);

	// -----------------------------------------------------------------
	// Bootstrap
	// -----------------------------------------------------------------

	public static function init() {
		add_action( 'admin_menu',            array( __CLASS__, 'add_page' ) );
		add_action( 'admin_init',            array( __CLASS__, 'restrict_access' ) );
		add_action( 'admin_init',            array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_init',            array( __CLASS__, 'handle_approve' ) );
		add_action( 'admin_head',            array( __CLASS__, 'kit_chrome' ) );
		add_action( 'admin_head',            array( __CLASS__, 'hide_password_fields' ) );
		add_action( 'admin_footer',          array( __CLASS__, 'lock_profile_fields' ) );
		// The JS above only hides the controls; a determined edit via
		// devtools still posts the form, so this is the actual enforcement.
		add_action( 'profile_update',        array( __CLASS__, 'guard_locked_identity_fields' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'kit_assets' ) );
		add_filter( 'login_redirect',        array( __CLASS__, 'login_redirect' ), 10, 3 );
		add_filter( 'user_has_cap',          array( __CLASS__, 'grant_staff_cap' ), 10, 4 );

		// Clickable agent-page link in the WP admin toolbar.
		add_action( 'admin_bar_menu',        array( __CLASS__, 'toolbar_node' ), 999 );

		// Pending-changes notice on the admin user-edit screen.
		add_action( 'edit_user_profile',     array( __CLASS__, 'render_pending_notice' ) );
	}

	/**
	 * Dynamically grant the mwp_agent_kit capability to wappointment_staff users.
	 *
	 * wappointment_staff is the live-site role for travel agents. The kit page
	 * uses mwp_agent_kit as its required capability. Without this filter those
	 * users can never pass WordPress's own capability check for the page, which
	 * causes a redirect loop: restrict_access() sends them to the kit page,
	 * WordPress denies access and sends them away, repeat.
	 *
	 * @param bool[]   $allcaps All capabilities the user has.
	 * @param string[] $caps    Required primitive capabilities being checked.
	 * @param array    $args    Check context.
	 * @param WP_User  $user    The user whose caps are being checked.
	 * @return bool[]
	 */
	public static function grant_staff_cap( $allcaps, $caps, $args, $user ) {
		if ( ! empty( $allcaps['wappointment_staff'] ) ||
		     in_array( 'wappointment_staff', (array) $user->roles, true ) ) {
			$allcaps[ self::CAP ] = true;
		}
		return $allcaps;
	}

	// -----------------------------------------------------------------
	// Admin toolbar: the "Howdy, {name}" link for agents
	// -----------------------------------------------------------------

	/**
	 * The agent's own public page URL, if one is linked to their account.
	 *
	 * Shared by the toolbar link (toolbar_node()) and the banner on "My
	 * Agent Page" itself — one place that finds it, so both stay in step
	 * rather than each running a slightly different query.
	 *
	 * @param int $user_id WP user ID.
	 * @return string Permalink, or '' when no page is linked.
	 */
	public static function agent_public_url( $user_id ) {
		$pages = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'meta_key'       => MWP_Agent::PAGE_META,  // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => (int) $user_id,         // phpcs:ignore WordPress.DB.SlowDBQuery
			'posts_per_page' => 1,
			'fields'         => 'ids',
		) );
		if ( ! $pages ) {
			return '';
		}
		$url = get_permalink( $pages[0] );
		return $url ? $url : '';
	}

	/**
	 * Re-point the "Howdy, {name}" toolbar dropdown for any logged-in agent
	 * — travel_agent or wappointment_staff — who has a linked public page.
	 *
	 * By default both the name/avatar row ("user-info") and "Edit My
	 * Profile" link to profile.php — which, for an agent, now only has the
	 * identity fields they're not allowed to touch (see
	 * MWP_Agent::profile_fields()); their real editing screen is the Agent
	 * Kit. So instead of a separate, easy-to-miss "View my page" link stuck
	 * on one admin screen (it used to live on the Social Kit page — not a
	 * place anyone would look for it), their own name at the very top now
	 * IS the link straight to the page their clients see, everywhere in
	 * wp-admin; "Edit My Profile" becomes the link to where they actually
	 * edit it.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar
	 */
	public static function toolbar_node( $wp_admin_bar ) {
		if ( ! is_admin_bar_showing() ) {
			return;
		}

		$user  = wp_get_current_user();
		$roles = (array) $user->roles;
		if ( ! in_array( 'wappointment_staff', $roles, true ) && ! in_array( self::ROLE, $roles, true ) && ! $user->has_cap( self::CAP ) ) {
			return;
		}

		$url = self::agent_public_url( $user->ID );
		if ( ! $url ) {
			return;
		}

		$user_info = $wp_admin_bar->get_node( 'user-info' );
		if ( $user_info ) {
			$user_info = (array) $user_info;
			$user_info['href'] = $url;
			$user_info['meta'] = array_merge( (array) ( $user_info['meta'] ?? array() ), array(
				'target' => '_blank',
				'rel'    => 'noopener',
			) );
			$wp_admin_bar->add_node( $user_info );
		}

		$edit_profile = $wp_admin_bar->get_node( 'edit-profile' );
		if ( $edit_profile ) {
			$edit_profile = (array) $edit_profile;
			$edit_profile['title'] = esc_html__( 'My Agent Page', 'multiwander-packages' );
			$edit_profile['href']  = admin_url( 'admin.php?page=' . self::PAGE );
			$wp_admin_bar->add_node( $edit_profile );
		}
	}

	// -----------------------------------------------------------------
	// Role management
	// -----------------------------------------------------------------

	public static function register_role() {
		if ( get_role( self::ROLE ) ) {
			return;
		}
		add_role(
			self::ROLE,
			__( 'Travel Agent', 'multiwander-packages' ),
			array(
				'read'         => true,
				'upload_files' => true,
				self::CAP      => true,
			)
		);
	}

	public static function remove_role() {
		remove_role( self::ROLE );
	}

	// -----------------------------------------------------------------
	// Helper: is the current user a restricted agent?
	// -----------------------------------------------------------------

	protected static function is_restricted() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		$user = wp_get_current_user();

		// wappointment_staff users are managed by Wappointment's own access
		// control — applying our lockdown on top causes a redirect loop between
		// the two plugins. They still get the mwp_agent_kit capability (via
		// grant_staff_cap) so they can reach the kit page, but we leave
		// Wappointment free to handle where they go elsewhere in the admin.
		if ( in_array( 'wappointment_staff', (array) $user->roles, true ) ) {
			return false;
		}

		return $user->has_cap( self::CAP ) && ! $user->has_cap( 'edit_others_posts' );
	}

	// -----------------------------------------------------------------
	// Menu page
	// -----------------------------------------------------------------

	public static function add_page() {
		add_menu_page(
			__( 'Travel Agent Kit', 'multiwander-packages' ),
			__( 'My Agent Page', 'multiwander-packages' ),
			self::CAP,
			self::PAGE,
			array( __CLASS__, 'render_page' ),
			'dashicons-id-alt',
			2
		);
	}

	// -----------------------------------------------------------------
	// Access control
	// -----------------------------------------------------------------

	public static function restrict_access() {
		if ( ! self::is_restricted() ) {
			return;
		}

		global $pagenow;

		$allowed = array( 'admin.php', 'async-upload.php', 'media-upload.php' );
		if ( in_array( $pagenow, $allowed, true ) ) {
			if ( 'admin.php' === $pagenow ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
				if ( $page !== self::PAGE ) {
					wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE ) );
					exit;
				}
			}
			return;
		}

		if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
			return;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE ) );
		exit;
	}

	// -----------------------------------------------------------------
	// Login redirect
	// -----------------------------------------------------------------

	public static function login_redirect( $redirect_to, $requested, $user ) {
		if ( ! ( $user instanceof WP_User ) ) {
			return $redirect_to;
		}
		if ( $user->has_cap( self::CAP ) && ! $user->has_cap( 'edit_others_posts' ) ) {
			return admin_url( 'admin.php?page=' . self::PAGE );
		}
		return $redirect_to;
	}

	// -----------------------------------------------------------------
	// Chrome: hide sidebar + toolbar for restricted agents
	// -----------------------------------------------------------------

	public static function kit_chrome() {
		if ( ! self::is_restricted() ) {
			return;
		}
		?>
		<style id="mwpa-kit-chrome">
			#wpadminbar,
			#adminmenumain,
			#adminmenuback,
			#adminmenuwrap,
			#wpfooter { display: none !important; }
			#wpcontent, #wpbody { margin-left: 0 !important; padding-left: 0 !important; }
			html.wp-toolbar { padding-top: 0 !important; }
			#wpbody-content { padding-bottom: 0 !important; }
		</style>
		<?php
	}

	// -----------------------------------------------------------------
	// Trim profile.php down to what a travel agent actually needs
	// -----------------------------------------------------------------

	/**
	 * Is the current user a travel agent for the purposes of trimming
	 * their own profile.php screen? Shared by hide_password_fields() and
	 * lock_profile_fields().
	 *
	 * @return bool
	 */
	protected static function is_restricted_profile_user() {
		$user = wp_get_current_user();
		return $user->has_cap( self::CAP ) || in_array( 'wappointment_staff', (array) $user->roles, true );
	}

	/**
	 * Hide the password section, plus the "Personal Options" block a travel
	 * agent never needs: admin colour scheme, keyboard shortcuts, the
	 * front-end toolbar toggle. These three all carry stable core WordPress
	 * row classes, so a plain CSS rule is enough and nothing flashes into
	 * view before it applies.
	 *
	 * @return void
	 */
	public static function hide_password_fields() {
		global $pagenow;
		if ( 'profile.php' !== $pagenow || ! self::is_restricted_profile_user() ) {
			return;
		}
		?>
		<style id="mwpa-hide-password">
			#password,
			.user-pass1-wrap,
			.user-pass2-wrap,
			.pw-weak,
			.user-generate-reset-link-wrap,
			.wp-generate-pw,
			#pass-strength-result,
			.application-passwords,
			#application-passwords-section,
			.user-admin-color-wrap,
			.user-comment-shortcuts-wrap,
			.user-admin-bar-front-wrap { display: none !important; }
		</style>
		<?php
	}

	/**
	 * Clean up what CSS classes alone can't reach: a row added by some other
	 * plugin (like "Disable infinite scrolling", which carries no class this
	 * plugin can rely on), and the account email field, which stays visible
	 * but locked — the address is still worth seeing, changing it is not a
	 * travel agent's call. Matched by each row's own label text, which is
	 * why this runs in JS rather than as a CSS rule: it never depends on
	 * guessing a class name that could change with any plugin or theme
	 * update.
	 *
	 * @return void
	 */
	public static function lock_profile_fields() {
		global $pagenow;
		if ( 'profile.php' !== $pagenow || ! self::is_restricted_profile_user() ) {
			return;
		}
		?>
		<script id="mwpa-lock-profile-fields">
		document.addEventListener( 'DOMContentLoaded', function () {
			// Table-row fields (the usual profile.php layout): matched by the
			// row's own <th> label text, so this never depends on guessing a
			// class name added by core, a theme or some other plugin.
			var hideLabels = [
				'infinite scrolling', 'additional capabilities', 'ai features', 'grant consent',
				// The generic social-profile fields WordPress core / Yoast SEO
				// add to every user's profile.php (Website, Facebook, Instagram,
				// LinkedIn, MySpace, Pinterest, SoundCloud, Tumblr, Wikipedia, X,
				// YouTube) are a completely different, unrelated set of fields
				// from this plugin's own Facebook/Instagram/LinkedIn/YouTube
				// cards further down — an agent filling in the wrong one would
				// see nothing change on their page. Hidden so there is only
				// ever one place to put each link.
				'website', 'facebook profile', 'instagram profile', 'linkedin profile',
				'myspace profile', 'pinterest profile', 'soundcloud profile',
				'tumblr profile', 'wikipedia page', 'x username', 'youtube profile'
			];
			document.querySelectorAll( '#your-profile tr' ).forEach( function ( row ) {
				var th = row.querySelector( 'th' );
				if ( ! th ) { return; }
				var text = th.textContent.toLowerCase();
				for ( var i = 0; i < hideLabels.length; i++ ) {
					if ( text.indexOf( hideLabels[ i ] ) !== -1 ) {
						row.style.display = 'none';
						return;
					}
				}
			} );

			// The same fields, but laid out as a heading + block instead of a
			// table row — "Additional Capabilities" and "AI features / Grant
			// consent" render this way on some setups. Hide the heading and
			// everything after it up to the next heading, which is the usual
			// shape of a "section" on this screen.
			var hideSections = [ 'additional capabilities', 'ai features', 'grant consent' ];
			document.querySelectorAll( '#your-profile h2, #your-profile h3, #your-profile legend' ).forEach( function ( h ) {
				var text = h.textContent.toLowerCase();
				for ( var i = 0; i < hideSections.length; i++ ) {
					if ( text.indexOf( hideSections[ i ] ) === -1 ) { continue; }
					h.style.display = 'none';
					// Stop at the next heading, OR at the submit row, OR after a
					// handful of siblings — whichever comes first. The submit
					// row ("Update Profile") must never be swept up by this,
					// even on a page with no heading in between.
					var el    = h.nextElementSibling;
					var guard = 0;
					while ( el && ! /^H[1-6]$/.test( el.tagName ) && guard < 20 ) {
						if ( el.classList.contains( 'submit' ) || el.querySelector( '.submit, input[type="submit"], button[type="submit"]' ) ) {
							break;
						}
						var next = el.nextElementSibling;
						el.style.display = 'none';
						el = next;
						guard++;
					}
					return;
				}
			} );

			// Identity fields — the account email, first name and last name
			// all come from how the agent is set up on this site, so they
			// are an administrator's call, not the agent's own. (The WP
			// username field is already read-only for every user in core,
			// so there is nothing to lock there.) Shown for reference,
			// never editable from here.
			var identityNote = <?php echo wp_json_encode( __( 'Only an administrator can change this.', 'multiwander-packages' ) ); ?>;
			[ 'email', 'first_name', 'last_name' ].forEach( function ( fieldId ) {
				var field = document.getElementById( fieldId );
				if ( ! field ) { return; }
				field.setAttribute( 'readonly', 'readonly' );
				field.style.background = '#f0f0f1';
				field.style.cursor = 'not-allowed';
				var oldNote = field.parentNode.querySelector( '.description' );
				if ( oldNote ) { oldNote.style.display = 'none'; }
				var note = document.createElement( 'p' );
				note.className = 'description';
				note.style.marginTop = '4px';
				note.textContent = identityNote;
				field.parentNode.appendChild( note );
			} );
		} );
		</script>
		<?php
	}

	/**
	 * Server-side backstop for the email/first-name/last-name lock above.
	 * lock_profile_fields() only hides and disables those controls in the
	 * browser — a quick devtools edit can still remove `readonly` and post
	 * a changed value, and WordPress would otherwise save it. This runs
	 * after WP's own save and reverts those three fields back to what they
	 * were before, for a restricted user only; an administrator editing the
	 * same profile from user-edit.php is untouched.
	 *
	 * @param int     $user_id      The user that was just saved.
	 * @param WP_User $old_user_data The user as it was immediately before.
	 * @return void
	 */
	public static function guard_locked_identity_fields( $user_id, $old_user_data ) {
		if ( ! self::is_restricted_profile_user() ) {
			return;
		}

		$new_user = get_userdata( $user_id );
		if ( ! $new_user ) {
			return;
		}

		$changed = false;
		if ( $new_user->first_name !== $old_user_data->first_name ) {
			update_user_meta( $user_id, 'first_name', $old_user_data->first_name );
			$changed = true;
		}
		if ( $new_user->last_name !== $old_user_data->last_name ) {
			update_user_meta( $user_id, 'last_name', $old_user_data->last_name );
			$changed = true;
		}
		if ( $new_user->user_email !== $old_user_data->user_email ) {
			// Avoid re-entering this same hook while we correct the email.
			remove_action( 'profile_update', array( __CLASS__, 'guard_locked_identity_fields' ), 10 );
			wp_update_user( array( 'ID' => $user_id, 'user_email' => $old_user_data->user_email ) );
			add_action( 'profile_update', array( __CLASS__, 'guard_locked_identity_fields' ), 10, 2 );
			$changed = true;
		}

		if ( $changed ) {
			error_log( sprintf( 'MultiWander: reverted a locked profile field edit on user #%d (self-edited).', $user_id ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}

	// -----------------------------------------------------------------
	// Assets
	// -----------------------------------------------------------------

	public static function kit_assets( $hook ) {
		if ( 'toplevel_page_' . self::PAGE !== $hook ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style(
			'mwp-agent-admin',
			MWP_URL . 'assets/agent-admin.css',
			array(),
			MWPP_asset_version( 'assets/agent-admin.css' )
		);
		wp_enqueue_script(
			'mwp-agent-admin',
			MWP_URL . 'assets/agent-admin.js',
			array(),
			MWPP_asset_version( 'assets/agent-admin.js' ),
			true
		);
	}

	// -----------------------------------------------------------------
	// Save handler
	// -----------------------------------------------------------------

	public static function handle_save() {
		if ( ! isset( $_POST['mwp_kit_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mwp_kit_nonce'] ) ), self::NONCE ) ) {
			wp_die( esc_html__( 'Security check failed.', 'multiwander-packages' ) );
		}
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'multiwander-packages' ) );
		}

		$uid = get_current_user_id();
		$meta = MWP_Agent::META;

		// ── Immediate fields ──────────────────────────────────────────
		// Only the visibility switch itself — whether the agent's page and
		// widgets are published at all. That is a kill-switch, not public
		// content, so it is not something an admin needs to review. Every
		// field that actually shows up in front of a visitor — photo,
		// contact details, stats, social links, bio, regions, everything —
		// goes through the approval queue below instead, per the "nothing
		// goes live until I approve it" rule.

		update_user_meta( $uid, $meta . 'enabled', isset( $_POST[ $meta . 'enabled' ] ) ? '1' : '' );

		// ── Pending fields — queue for approval ────────────────────────

		$pending = array();

		// Photo.
		$pending['photo_id'] = isset( $_POST[ $meta . 'photo_id' ] ) ? (int) $_POST[ $meta . 'photo_id' ] : 0;

		// Gender (drives "ekspert"/"ekspertka" wording on country pages).
		$gender_raw = isset( $_POST[ $meta . 'gender' ] ) ? sanitize_key( $_POST[ $meta . 'gender' ] ) : 'm';
		$pending['gender'] = in_array( $gender_raw, array( 'm', 'f' ), true ) ? $gender_raw : 'm';

		// Stats.
		for ( $i = 1; $i <= 3; $i++ ) {
			foreach ( array( 'stat' . $i . '_num', 'stat' . $i . '_label' ) as $sk ) {
				$raw = isset( $_POST[ $meta . $sk ] ) ? wp_unslash( $_POST[ $meta . $sk ] ) : '';
				$pending[ $sk ] = sanitize_text_field( $raw );
			}
		}

		// Contact / CTA / social — plain text and URL fields.
		$pending_fields = array(
			'email'         => 'text',
			'phone'         => 'text',
			'whatsapp'      => 'text',
			'wap_id'        => 'text',
			'cta_label'     => 'text',
			'cta_url'       => 'url',
			'facebook_url'  => 'url',
			'instagram_url' => 'url',
			'linkedin_url'  => 'url',
			'youtube_url'   => 'url',
			'headline'      => 'text',
			'intro'         => 'textarea',
		);
		foreach ( $pending_fields as $key => $type ) {
			$raw = isset( $_POST[ $meta . $key ] ) ? wp_unslash( $_POST[ $meta . $key ] ) : '';
			if ( 'url' === $type ) {
				$pending[ $key ] = esc_url_raw( $raw );
			} elseif ( 'textarea' === $type ) {
				$pending[ $key ] = sanitize_textarea_field( $raw );
			} else {
				$pending[ $key ] = sanitize_text_field( $raw );
			}
		}

		// Regions repeater → JSON array of rich {name, subtitle, countries, note, tags} objects.
		$regions = MWP_Agent::parse_regions_from_post( $meta );
		$pending['regions'] = wp_json_encode( $regions, JSON_UNESCAPED_UNICODE );

		// Languages repeater → JSON array of { name, level } objects.
		$pending['languages'] = wp_json_encode( MWP_Agent::parse_languages_from_post( $meta ), JSON_UNESCAPED_UNICODE );

		// Travel style → JSON array of up to three short, one-line entries.
		$pending['style'] = wp_json_encode( MWP_Agent::parse_travel_styles_from_post( $meta ), JSON_UNESCAPED_UNICODE );

		// Rich-text pending field.
		$raw = isset( $_POST[ $meta . 'bio' ] ) ? wp_unslash( $_POST[ $meta . 'bio' ] ) : '';
		$pending['bio'] = wp_kses_post( $raw );

		// Only queue pending if something actually changed.
		$existing_pending = json_decode( (string) get_user_meta( $uid, self::PENDING_META, true ), true );
		if ( ! is_array( $existing_pending ) ) {
			$existing_pending = array();
		}
		$pending_merged = array_merge( $existing_pending, $pending );
		update_user_meta( $uid, self::PENDING_META, wp_json_encode( $pending_merged ) );

		// Email the site admin.
		self::notify_admin( $uid );

		// Redirect back with a saved flag.
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&saved=1' ) );
		exit;
	}

	// -----------------------------------------------------------------
	// Email notification to admin
	// -----------------------------------------------------------------

	/**
	 * Who gets notified when an agent submits changes.
	 *
	 * Sent straight to info@multiwander.com, per an explicit request — not
	 * get_option('admin_email'), which on a multi-brand install (this
	 * plugin also powers momira.travel) may not be the right inbox for a
	 * MultiWander agent's profile review.
	 *
	 * @return string
	 */
	protected static function approval_notify_email() {
		/**
		 * Filter the inbox that gets the "profile awaiting approval" email.
		 *
		 * @param string $email
		 */
		return apply_filters( 'mwp_agent_approval_email', 'info@multiwander.com' );
	}

	/**
	 * Public so MWP_Agent::save_profile_fields_pending() can send the same
	 * "awaiting approval" email when an agent saves from profile.php
	 * instead of the Kit page.
	 *
	 * @param int $uid Agent user ID.
	 * @return void
	 */
	public static function notify_admin( int $uid ) {
		$agent = get_userdata( $uid );
		if ( ! $agent ) {
			return;
		}
		$admin_email = self::approval_notify_email();
		$site_name   = get_bloginfo( 'name' );
		$review_url  = admin_url( 'user-edit.php?user_id=' . $uid );

		$subject = sprintf(
			/* translators: 1: site name, 2: agent display name */
			__( '[%1$s] Travel agent profile update awaiting approval — %2$s', 'multiwander-packages' ),
			$site_name,
			$agent->display_name
		);

		$body = sprintf(
			/* translators: 1: agent name, 2: review URL */
			__( "Hello,\n\n%1\$s has submitted profile changes that require your approval.\n\nReview and approve or reject the changes here:\n%2\$s\n\n— MultiWander", 'multiwander-packages' ),
			$agent->display_name,
			$review_url
		);

		wp_mail( $admin_email, $subject, $body );
	}

	// -----------------------------------------------------------------
	// Approve pending changes (admin action)
	// -----------------------------------------------------------------

	public static function handle_approve() {
		if ( ! isset( $_POST['mwp_approve_nonce'] ) ) {
			return;
		}
		$uid = isset( $_POST['mwp_approve_uid'] ) ? (int) $_POST['mwp_approve_uid'] : 0;
		if ( ! $uid || ! current_user_can( 'edit_users' ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mwp_approve_nonce'] ) ), 'mwp_approve_' . $uid ) ) {
			wp_die( esc_html__( 'Security check failed.', 'multiwander-packages' ) );
		}

		$action = isset( $_POST['mwp_approve_action'] ) ? sanitize_key( $_POST['mwp_approve_action'] ) : '';

		if ( 'approve' === $action ) {
			$pending_json = (string) get_user_meta( $uid, self::PENDING_META, true );
			$pending      = json_decode( $pending_json, true );

			if ( is_array( $pending ) ) {
				// Generic on purpose: every key queued in handle_save() is
				// applied here the same way, so a field added to the pending
				// set never has to also be added to a second list here (the
				// old per-field lists silently dropped anything new —
				// approved in the admin's eyes but never actually saved).
				$meta = MWP_Agent::META;
				foreach ( $pending as $key => $value ) {
					$clean = ( 'photo_id' === $key ) ? (int) $value : $value;
					update_user_meta( $uid, $meta . $key, $clean );
				}
			}
		}

		// Clear pending regardless of approve or reject.
		delete_user_meta( $uid, self::PENDING_META );

		wp_safe_redirect( admin_url( 'user-edit.php?user_id=' . $uid . '&mwp_reviewed=1' ) );
		exit;
	}

	// -----------------------------------------------------------------
	// Pending-changes notice on admin user-edit screen
	// -----------------------------------------------------------------

	public static function render_pending_notice( WP_User $user ) {
		if ( ! current_user_can( 'edit_users' ) ) {
			return;
		}

		$pending_json = (string) get_user_meta( $user->ID, self::PENDING_META, true );
		if ( ! $pending_json ) {
			return;
		}
		$pending = json_decode( $pending_json, true );
		if ( ! is_array( $pending ) || empty( $pending ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$reviewed = isset( $_GET['mwp_reviewed'] );

		$labels = array(
			'photo_id'      => __( 'Photo', 'multiwander-packages' ),
			'gender'        => __( 'Gender (ekspert/ekspertka wording)', 'multiwander-packages' ),
			'stat1_num'     => __( 'Stat 1 — number', 'multiwander-packages' ),
			'stat1_label'   => __( 'Stat 1 — label', 'multiwander-packages' ),
			'stat2_num'     => __( 'Stat 2 — number', 'multiwander-packages' ),
			'stat2_label'   => __( 'Stat 2 — label', 'multiwander-packages' ),
			'stat3_num'     => __( 'Stat 3 — number', 'multiwander-packages' ),
			'stat3_label'   => __( 'Stat 3 — label', 'multiwander-packages' ),
			'email'         => __( 'Public contact email', 'multiwander-packages' ),
			'phone'         => __( 'Phone', 'multiwander-packages' ),
			'whatsapp'      => __( 'WhatsApp', 'multiwander-packages' ),
			'wap_id'        => __( 'Wappointment staff ID', 'multiwander-packages' ),
			'cta_label'     => __( 'Contact button label', 'multiwander-packages' ),
			'cta_url'       => __( 'Contact button link', 'multiwander-packages' ),
			'facebook_url'  => __( 'Facebook', 'multiwander-packages' ),
			'instagram_url' => __( 'Instagram', 'multiwander-packages' ),
			'linkedin_url'  => __( 'LinkedIn', 'multiwander-packages' ),
			'youtube_url'   => __( 'YouTube', 'multiwander-packages' ),
			'headline'      => __( 'Headline', 'multiwander-packages' ),
			'intro'         => __( 'Short intro', 'multiwander-packages' ),
			'languages'     => __( 'Languages', 'multiwander-packages' ),
			'bio'           => __( 'About me', 'multiwander-packages' ),
			'regions'       => __( 'Regions of expertise', 'multiwander-packages' ),
			'style'         => __( 'Travel style', 'multiwander-packages' ),
		);
		?>
		<div class="mwpa-admin-wrap">
			<div class="mwpa-admin-card mwpa-pending-card">
				<div class="mwpa-admin-card-title">⏳ <?php esc_html_e( 'Pending profile changes — awaiting approval', 'multiwander-packages' ); ?></div>
				<?php if ( $reviewed ) : ?>
					<div class="mwpa-pending-done"><?php esc_html_e( 'Changes reviewed. Pending queue cleared.', 'multiwander-packages' ); ?></div>
				<?php else : ?>
					<table class="mwpa-pending-table">
						<?php foreach ( $pending as $key => $value ) :
							// A field queued by handle_save() without an entry
							// here still shows up — with its raw key as the
							// label — rather than silently vanishing from what
							// the admin reviews before approving.
							$label = isset( $labels[ $key ] ) ? $labels[ $key ] : ucfirst( str_replace( '_', ' ', $key ) );
							if ( 'photo_id' === $key ) {
								$img_url = $value ? wp_get_attachment_image_url( (int) $value, 'thumbnail' ) : '';
								$display = $img_url
									? '<img src="' . esc_url( $img_url ) . '" alt="" style="max-width:80px;height:auto;border-radius:6px">'
									: esc_html__( '(removed)', 'multiwander-packages' );
							} elseif ( 'gender' === $key ) {
								$display = ( 'f' === $value )
									? esc_html__( 'Female (ekspertka)', 'multiwander-packages' )
									: esc_html__( 'Male (ekspert)', 'multiwander-packages' );
							} elseif ( 'regions' === $key ) {
								$arr = json_decode( $value, true );
								if ( is_array( $arr ) ) {
									$labels_arr = array();
									foreach ( $arr as $entry ) {
										if ( is_string( $entry ) ) {
											$labels_arr[] = esc_html( $entry );
										} elseif ( isset( $entry['name'] ) && $entry['name'] !== '' ) {
											$label_str = esc_html( $entry['name'] );
											if ( ! empty( $entry['note'] ) ) {
												$label_str .= ' — ' . esc_html( $entry['note'] );
											}
											$labels_arr[] = $label_str;
										}
									}
									$display = implode( '<br>', $labels_arr );
								} else {
									$display = esc_html( $value );
								}
							} elseif ( 'languages' === $key ) {
								$langs = MWP_Agent::parse_languages( (string) $value );
								$labels_arr = array();
								foreach ( $langs as $lang ) {
									$ltxt = esc_html( $lang['name'] );
									if ( ! empty( $lang['level'] ) ) {
										$ltxt .= ' (' . esc_html( $lang['level'] ) . ')';
									}
									$labels_arr[] = $ltxt;
								}
								$display = implode( ', ', $labels_arr );
							} elseif ( 'style' === $key ) {
								$styles = json_decode( (string) $value, true );
								$display = is_array( $styles )
									? implode( ', ', array_map( 'esc_html', array_filter( $styles ) ) )
									: esc_html( $value );
							} else {
								$display = wp_kses_post( $value );
							}
							?>
							<tr>
								<th><?php echo esc_html( $label ); ?></th>
								<td><?php echo $display; // already escaped above ?></td>
							</tr>
						<?php endforeach; ?>
					</table>

					<form method="post" style="margin-top:16px;display:flex;gap:10px;flex-wrap:wrap;">
						<?php wp_nonce_field( 'mwp_approve_' . $user->ID, 'mwp_approve_nonce' ); ?>
						<input type="hidden" name="mwp_approve_uid" value="<?php echo esc_attr( $user->ID ); ?>">
						<button type="submit" name="mwp_approve_action" value="approve" class="button button-primary">
							✓ <?php esc_html_e( 'Approve & publish', 'multiwander-packages' ); ?>
						</button>
						<button type="submit" name="mwp_approve_action" value="reject" class="button">
							✕ <?php esc_html_e( 'Reject changes', 'multiwander-packages' ); ?>
						</button>
					</form>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// -----------------------------------------------------------------
	// Kit page render
	// -----------------------------------------------------------------

	public static function render_page() {
		$uid  = get_current_user_id();
		$user = wp_get_current_user();
		$meta = MWP_Agent::META;

		$get = function ( $key, $default = '' ) use ( $uid, $meta ) {
			$v = get_user_meta( $uid, $meta . $key, true );
			return '' !== $v ? $v : $default;
		};

		/** Render a single labelled field. */
		$f = function ( $key, $label, $type = 'text', $help = '', $default = '', $placeholder = '' ) use ( $get, $meta ) {
			$val  = $get( $key, $default );
			$name = $meta . $key;
			$id   = 'mwp_kit_' . $key;
			?>
			<div class="mwpa-f">
				<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
				<?php if ( 'textarea' === $type ) : ?>
					<textarea id="<?php echo esc_attr( $id ); ?>"
						name="<?php echo esc_attr( $name ); ?>"
						rows="3"
						placeholder="<?php echo esc_attr( $placeholder ); ?>"><?php echo esc_textarea( $val ); ?></textarea>
				<?php else : ?>
					<input type="<?php echo esc_attr( 'url' === $type ? 'url' : 'text' ); ?>"
						id="<?php echo esc_attr( $id ); ?>"
						name="<?php echo esc_attr( $name ); ?>"
						value="<?php echo esc_attr( $val ); ?>"
						placeholder="<?php echo esc_attr( $placeholder ); ?>">
				<?php endif; ?>
				<?php if ( $help ) : ?>
					<p class="mwpa-help"><?php echo esc_html( $help ); ?></p>
				<?php endif; ?>
			</div>
			<?php
		};

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$saved    = isset( $_GET['saved'] );
		$photo_id = (int) $get( 'photo_id' );
		$photo_src = $photo_id ? wp_get_attachment_image_url( $photo_id, 'medium' ) : '';

		$has_pending = (bool) get_user_meta( $uid, self::PENDING_META, true );

		// Find the agent's public page URL (if any).
		$agent_page_url = '';
		$agent_pages = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'meta_key'       => MWP_Agent::PAGE_META,  // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => $uid,                   // phpcs:ignore WordPress.DB.SlowDBQuery
			'posts_per_page' => 1,
			'fields'         => 'ids',
		) );
		if ( $agent_pages ) {
			$agent_page_url = get_permalink( $agent_pages[0] );
		}

		// Regions: decode JSON array (or fall back to empty array).
		$regions_json = $get( 'regions' );
		$regions_list = array();
		if ( $regions_json ) {
			$decoded = json_decode( $regions_json, true );
			if ( is_array( $decoded ) ) {
				$regions_list = $decoded;
			}
		}
		?>
		<div class="mwpa-kit-wrap">

			<!-- ── Top bar ──────────────────────────────────────────────── -->
			<div class="mwpa-kit-topbar">
				<div class="mwpa-kit-topbar-left">
					<span class="mwpa-kit-topbar-icon">✈</span>
					<span class="mwpa-kit-topbar-title">
						<?php
						printf(
							/* translators: %s: agent display name */
							esc_html__( 'Travel Agent Kit — %s', 'multiwander-packages' ),
							esc_html( $user->display_name )
						);
						?>
					</span>
					<?php if ( $saved ) : ?>
						<span class="mwpa-kit-saved"><?php esc_html_e( '✓ Saved!', 'multiwander-packages' ); ?></span>
					<?php endif; ?>
				</div>
				<div class="mwpa-kit-topbar-right">
					<?php if ( $agent_page_url ) : ?>
						<a class="mwpa-kit-view-btn" href="<?php echo esc_url( $agent_page_url ); ?>" target="_blank" rel="noopener">
							<?php esc_html_e( 'View my page', 'multiwander-packages' ); ?> ↗
						</a>
					<?php endif; ?>
					<a class="mwpa-kit-logout-btn" href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>">
						<?php esc_html_e( 'Log out', 'multiwander-packages' ); ?>
					</a>
				</div>
			</div>

			<?php if ( $agent_page_url ) : ?>
			<!-- ── Page preview banner ──────────────────────────────────── -->
			<div class="mwpa-kit-page-banner">
				<span class="mwpa-kit-page-banner-text">🌐 <?php esc_html_e( 'Your live page:', 'multiwander-packages' ); ?></span>
				<a class="mwpa-kit-page-banner-link" href="<?php echo esc_url( $agent_page_url ); ?>" target="_blank" rel="noopener">
					<?php echo esc_html( $agent_page_url ); ?> ↗
				</a>
			</div>
			<?php endif; ?>

			<?php if ( $has_pending ) : ?>
			<!-- ── Pending-approval notice ──────────────────────────────── -->
			<div class="mwpa-kit-pending-notice">
				⏳ <?php esc_html_e( 'Some of your recent changes are awaiting admin approval before they go live.', 'multiwander-packages' ); ?>
			</div>
			<?php endif; ?>

			<!-- ── Form ─────────────────────────────────────────────────── -->
			<div class="mwpa-kit-content">
				<form method="post" action="">
					<?php wp_nonce_field( self::NONCE, 'mwp_kit_nonce' ); ?>

					<p class="mwpa-kit-intro">
						<?php esc_html_e( 'This is your personal travel agent page on MultiWander. Fill in what you like — anything left empty is simply hidden from visitors.', 'multiwander-packages' ); ?>
					</p>

					<div class="mwpa-admin-wrap">

					<!-- ── Enable toggle ────────────────────────────────── -->
					<div class="mwpa-admin-header">
						<div class="mwpa-admin-header-icon">✈</div>
						<div>
							<h2><?php esc_html_e( 'Your agent page', 'multiwander-packages' ); ?></h2>
							<p><?php esc_html_e( 'Toggle to show or hide your page on the website.', 'multiwander-packages' ); ?></p>
						</div>
						<label class="mwpa-admin-live-toggle">
							<input type="checkbox" name="<?php echo esc_attr( $meta ); ?>enabled" value="1" <?php checked( $get( 'enabled' ), '1' ); ?>>
							<?php esc_html_e( 'Page live', 'multiwander-packages' ); ?>
						</label>
					</div>

					<!-- ── Photo & Basics ───────────────────────────────── -->
					<div class="mwpa-admin-card">
						<div class="mwpa-admin-card-title">👤 <?php esc_html_e( 'Photo & Basics', 'multiwander-packages' ); ?> <span class="mwpa-approval-badge">⏳ <?php esc_html_e( 'Requires approval', 'multiwander-packages' ); ?></span></div>
						<div class="mwpa-admin-photo-row">
							<div class="mwpa-admin-photo-col">
								<div class="mwp-agent-photo-field">
									<img src="<?php echo esc_url( $photo_src ); ?>"
										class="mwp-agent-photo-preview" alt=""
										style="<?php echo $photo_src ? '' : 'display:none;'; ?>">
									<input type="hidden"
										name="<?php echo esc_attr( $meta ); ?>photo_id"
										value="<?php echo esc_attr( $photo_id ); ?>"
										class="mwp-agent-photo-id">
									<button type="button" class="button mwp-agent-photo-pick">
										<?php esc_html_e( 'Choose / upload photo', 'multiwander-packages' ); ?>
									</button>
									<button type="button" class="button-link mwp-agent-photo-clear"
										style="margin-left:8px;color:#b32d2e;<?php echo $photo_id ? '' : 'display:none;'; ?>">
										<?php esc_html_e( 'Remove', 'multiwander-packages' ); ?>
									</button>
								</div>
							</div>
							<div class="mwpa-admin-photo-fields">
								<?php $f( 'headline', __( 'Headline', 'multiwander-packages' ), 'text',
									/* translators: note about approval */
									__( 'The blue line under your name. ⏳ Requires approval.', 'multiwander-packages' ), '',
									__( 'e.g. Travel expert specialising in Spain and Turkey', 'multiwander-packages' ) ); ?>
								<?php $f( 'intro', __( 'Short intro', 'multiwander-packages' ), 'textarea',
									__( 'One or two sentences shown beside your photo. ⏳ Requires approval.', 'multiwander-packages' ) ); ?>

								<!-- Gender -->
								<div class="mwpa-f">
									<label><?php esc_html_e( 'Grammatical gender', 'multiwander-packages' ); ?></label>
									<div style="display:flex;gap:24px;margin-top:4px;">
										<label style="font-weight:normal;cursor:pointer">
											<input type="radio" name="<?php echo esc_attr( $meta ); ?>gender" value="m" <?php checked( $get( 'gender', 'm' ), 'm' ); ?>>
											<?php esc_html_e( 'Male (ekspert)', 'multiwander-packages' ); ?>
										</label>
										<label style="font-weight:normal;cursor:pointer">
											<input type="radio" name="<?php echo esc_attr( $meta ); ?>gender" value="f" <?php checked( $get( 'gender', 'm' ), 'f' ); ?>>
											<?php esc_html_e( 'Female (ekspertka)', 'multiwander-packages' ); ?>
										</label>
									</div>
									<p class="mwpa-help"><?php esc_html_e( 'Used on country pages in "Meet our expert on …"', 'multiwander-packages' ); ?></p>
								</div>

								<?php
								// Languages repeater: name + proficiency level.
								$lang_rows = MWP_Agent::parse_languages( (string) $get( 'languages' ) );
								if ( empty( $lang_rows ) ) { $lang_rows = array( array( 'name' => '', 'level' => '' ) ); }
								?>
								<div class="mwpa-f">
									<label><?php esc_html_e( 'Languages', 'multiwander-packages' ); ?> <span class="mwpa-approval-badge">⏳ <?php esc_html_e( 'Requires approval', 'multiwander-packages' ); ?></span></label>
									<p class="mwpa-help" style="margin:2px 0 8px"><?php esc_html_e( 'One language per row, with a proficiency level.', 'multiwander-packages' ); ?></p>
									<div class="mwpa-langs-list" id="mwpa-kit-langs-list">
										<?php foreach ( $lang_rows as $lrow ) :
											$lname  = isset( $lrow['name'] ) ? $lrow['name'] : '';
											$llevel = isset( $lrow['level'] ) ? $lrow['level'] : '';
										?>
										<div class="mwpa-lang-row">
											<input type="text" class="mwpa-lang-f-name"
												name="<?php echo esc_attr( $meta ); ?>languages_name[]"
												value="<?php echo esc_attr( $lname ); ?>"
												placeholder="<?php esc_attr_e( 'e.g. Polski', 'multiwander-packages' ); ?>">
											<select class="mwpa-lang-f-level" name="<?php echo esc_attr( $meta ); ?>languages_level[]">
												<option value=""><?php esc_html_e( '— poziom —', 'multiwander-packages' ); ?></option>
												<?php if ( $llevel && ! in_array( $llevel, MWP_Agent::language_levels(), true ) ) : ?>
													<option value="<?php echo esc_attr( $llevel ); ?>" selected><?php echo esc_html( $llevel ); ?></option>
												<?php endif; ?>
												<?php foreach ( MWP_Agent::language_levels() as $lvl ) : ?>
													<option value="<?php echo esc_attr( $lvl ); ?>" <?php selected( $llevel, $lvl ); ?>><?php echo esc_html( $lvl ); ?></option>
												<?php endforeach; ?>
											</select>
											<button type="button" class="mwpa-lang-remove button-link" title="<?php esc_attr_e( 'Remove', 'multiwander-packages' ); ?>">✕</button>
										</div>
										<?php endforeach; ?>
									</div>
									<button type="button" class="mwpa-lang-add button" data-list="mwpa-kit-langs-list">
										➕ <?php esc_html_e( 'Add language', 'multiwander-packages' ); ?>
									</button>
								</div>
							</div>
						</div>
					</div>

					<!-- ── Stats ────────────────────────────────────────── -->
					<div class="mwpa-admin-card">
						<div class="mwpa-admin-card-title">📊 <?php esc_html_e( 'Stats', 'multiwander-packages' ); ?> <span class="mwpa-approval-badge">⏳ <?php esc_html_e( 'Requires approval', 'multiwander-packages' ); ?></span></div>
						<div class="mwpa-admin-stats-grid">
							<?php for ( $i = 1; $i <= 3; $i++ ) : ?>
								<div class="mwpa-admin-stat-pair">
									<?php $f( 'stat' . $i . '_num',   __( 'Number', 'multiwander-packages' ), 'text', '', '', '12+' ); ?>
									<?php $f( 'stat' . $i . '_label', __( 'Label', 'multiwander-packages' ),  'text', '', '', __( 'Years of experience', 'multiwander-packages' ) ); ?>
								</div>
							<?php endfor; ?>
						</div>
					</div>

					<!-- ── Contact & Booking (incl. social links) ───────── -->
					<div class="mwpa-admin-card">
						<div class="mwpa-admin-card-title">📬 <?php esc_html_e( 'Contact, Booking & Social Media', 'multiwander-packages' ); ?> <span class="mwpa-approval-badge">⏳ <?php esc_html_e( 'Requires approval', 'multiwander-packages' ); ?></span></div>

						<p class="mwpa-admin-card-subtitle"><?php esc_html_e( 'Contact & Booking', 'multiwander-packages' ); ?></p>
						<div class="mwpa-admin-two-col" style="margin-bottom:18px">
							<?php $f( 'email',    __( 'E-mail', 'multiwander-packages' ),    'text', '', '', 'name@example.com' ); ?>
							<?php $f( 'phone',    __( 'Phone', 'multiwander-packages' ),     'text', '', '', '+48 000 000 000' ); ?>
							<?php $f( 'whatsapp', __( 'WhatsApp', 'multiwander-packages' ),  'text',
								__( 'Number or wa.me link.', 'multiwander-packages' ) ); ?>
							<?php $f( 'wap_id',   __( 'Wappointment staff ID', 'multiwander-packages' ), 'text',
								__( 'Your staff ID number in Wappointment — shows the live booking widget.', 'multiwander-packages' ) ); ?>
							<?php $f( 'cta_label', __( 'Button text', 'multiwander-packages' ), 'text', '',
								__( 'Book a free consultation!', 'multiwander-packages' ) ); ?>
							<?php $f( 'cta_url', __( 'Button link', 'multiwander-packages' ), 'url',
								__( 'Where the button goes — usually a mailto: link or booking page.', 'multiwander-packages' ), '',
								'mailto:you@example.com' ); ?>
						</div>

						<p class="mwpa-admin-card-subtitle">📱 <?php esc_html_e( 'Social Media', 'multiwander-packages' ); ?></p>
						<p class="mwpa-help" style="margin:-6px 0 12px">
							<?php esc_html_e( 'Leave any field empty and that icon will not appear on your page.', 'multiwander-packages' ); ?>
						</p>
						<div class="mwpa-admin-two-col">
							<?php $f( 'facebook_url',  'Facebook',  'url', '', '', 'https://facebook.com/yourpage' ); ?>
							<?php $f( 'instagram_url', 'Instagram', 'url', '', '', 'https://instagram.com/yourprofile' ); ?>
							<?php $f( 'linkedin_url',  'LinkedIn',  'url', '', '', 'https://linkedin.com/in/yourname' ); ?>
							<?php $f( 'youtube_url',   'YouTube',   'url', '', '', 'https://youtube.com/@yourchannel' ); ?>
						</div>
					</div>

					<!-- ── About me ─────────────────────────────────────── -->
					<div class="mwpa-admin-card">
						<div class="mwpa-admin-card-title">📖 <?php esc_html_e( 'About me', 'multiwander-packages' ); ?> <span class="mwpa-approval-badge">⏳ <?php esc_html_e( 'Requires approval', 'multiwander-packages' ); ?></span></div>
						<?php
						wp_editor(
							(string) $get( 'bio' ),
							'mwp_kit_bio',
							array(
								'textarea_name' => $meta . 'bio',
								'textarea_rows' => 10,
								'media_buttons' => false,
								'teeny'         => false,
								'quicktags'     => false,
							)
						);
						?>
					</div>

					<!-- ── Regions of expertise (repeater) ──────────────── -->
					<div class="mwpa-admin-card">
						<div class="mwpa-admin-card-title">🌍 <?php esc_html_e( 'Regions of expertise', 'multiwander-packages' ); ?> <span class="mwpa-approval-badge">⏳ <?php esc_html_e( 'Requires approval', 'multiwander-packages' ); ?></span></div>
						<p class="mwpa-help" style="margin-bottom:12px">
							<?php esc_html_e( 'One country or region per card. Type a country name under Flags and press Enter to add it — add as many as you like, one at a time. Flags also appear automatically from the region name if you leave that field empty. Add a subtitle, a short description and comma-separated tags to match the full card style.', 'multiwander-packages' ); ?>
						</p>
						<div class="mwpa-regions-list" id="mwpa-kit-regions-list">
							<?php
							$region_rows = ! empty( $regions_list ) ? $regions_list : array( array() );
							foreach ( $region_rows as $entry ) :
								if ( is_string( $entry ) ) {
									$rname = $entry; $rnote = ''; $rsub = ''; $rcountries = ''; $rtags = '';
								} else {
									$rname      = isset( $entry['name'] ) ? $entry['name'] : '';
									$rnote      = isset( $entry['note'] ) ? $entry['note'] : '';
									$rsub       = isset( $entry['subtitle'] ) ? $entry['subtitle'] : '';
									$rcountries = isset( $entry['countries'] ) ? $entry['countries'] : '';
									$rtags_raw  = isset( $entry['tags'] ) ? $entry['tags'] : '';
									$rtags      = is_array( $rtags_raw ) ? implode( ', ', $rtags_raw ) : (string) $rtags_raw;
								}
							?>
								<div class="mwpa-region-row">
									<div class="mwpa-region-fields">
										<input type="text" class="mwpa-region-f-name"
											name="<?php echo esc_attr( $meta ); ?>regions_name[]"
											value="<?php echo esc_attr( $rname ); ?>"
											placeholder="<?php esc_attr_e( 'Region — e.g. Hiszpania i Portugalia', 'multiwander-packages' ); ?>">
										<div class="mwpa-region-f-two">
											<input type="text" class="mwpa-region-f-subtitle"
												name="<?php echo esc_attr( $meta ); ?>regions_subtitle[]"
												value="<?php echo esc_attr( $rsub ); ?>"
												placeholder="<?php esc_attr_e( 'Subtitle — e.g. Osobiste Doświadczenie Życia', 'multiwander-packages' ); ?>">
											<input type="text" class="mwpa-region-f-countries"
												name="<?php echo esc_attr( $meta ); ?>regions_countries[]"
												value="<?php echo esc_attr( $rcountries ); ?>"
												placeholder="<?php esc_attr_e( 'Type a country, press Enter…', 'multiwander-packages' ); ?>">
										</div>
										<textarea class="mwpa-region-f-note" rows="2"
											name="<?php echo esc_attr( $meta ); ?>regions_note[]"
											placeholder="<?php esc_attr_e( 'Short description of your experience there', 'multiwander-packages' ); ?>"><?php echo esc_textarea( $rnote ); ?></textarea>
										<input type="text" class="mwpa-region-f-tags"
											name="<?php echo esc_attr( $meta ); ?>regions_tags[]"
											value="<?php echo esc_attr( $rtags ); ?>"
											placeholder="<?php esc_attr_e( 'Tags, comma-separated — e.g. Życie w Lizbonie, Wyspy Kanaryjskie', 'multiwander-packages' ); ?>">
									</div>
									<button type="button" class="mwpa-region-remove button-link" title="<?php esc_attr_e( 'Remove', 'multiwander-packages' ); ?>">✕</button>
								</div>
							<?php endforeach; ?>
						</div>
						<button type="button" class="mwpa-region-add button" data-list="mwpa-kit-regions-list">
							➕ <?php esc_html_e( 'Add region', 'multiwander-packages' ); ?>
						</button>
					</div>

					<!-- ── Travel style ─────────────────────────────────── -->
					<div class="mwpa-admin-card">
						<div class="mwpa-admin-card-title">🧭 <?php esc_html_e( 'My travel style', 'multiwander-packages' ); ?> <span class="mwpa-approval-badge">⏳ <?php esc_html_e( 'Requires approval', 'multiwander-packages' ); ?></span></div>
						<p class="mwpa-help" style="margin-bottom:12px">
							<?php esc_html_e( 'Up to three, one short line each — these show as tags on your profile, not a paragraph. Start typing for some ideas.', 'multiwander-packages' ); ?>
						</p>
						<?php
						$style_raw   = (string) $get( 'style' );
						$style_list  = json_decode( $style_raw, true );
						if ( ! is_array( $style_list ) ) {
							// Pre-existing rich-text value from before this was a
							// repeater — show it as a single starting entry rather
							// than losing it outright.
							$legacy = trim( wp_strip_all_tags( $style_raw ) );
							$style_list = ( '' !== $legacy ) ? array( $legacy ) : array();
						}
						if ( empty( $style_list ) ) {
							$style_list = array( '' );
						}
						?>
						<datalist id="mwpa-style-options">
							<?php foreach ( MWP_Agent::travel_style_options() as $opt ) : ?>
								<option value="<?php echo esc_attr( $opt ); ?>"></option>
							<?php endforeach; ?>
						</datalist>
						<div class="mwpa-style-list" id="mwpa-kit-style-list" data-max="3">
							<?php foreach ( $style_list as $one ) : ?>
								<div class="mwpa-style-row">
									<input type="text" class="mwpa-style-f-name" list="mwpa-style-options"
										name="<?php echo esc_attr( $meta ); ?>style[]"
										value="<?php echo esc_attr( $one ); ?>"
										maxlength="60"
										placeholder="<?php esc_attr_e( 'e.g. Luksusowe podróże', 'multiwander-packages' ); ?>">
									<button type="button" class="mwpa-style-remove button-link" title="<?php esc_attr_e( 'Remove', 'multiwander-packages' ); ?>">✕</button>
								</div>
							<?php endforeach; ?>
						</div>
						<button type="button" class="mwpa-style-add button" data-list="mwpa-kit-style-list" data-datalist="mwpa-style-options" data-name="<?php echo esc_attr( $meta ); ?>style[]">
							➕ <?php esc_html_e( 'Add travel style', 'multiwander-packages' ); ?>
						</button>
					</div>

					</div><!-- .mwpa-admin-wrap -->

					<!-- ── Sticky save bar ──────────────────────────────── -->
					<div class="mwpa-kit-save-bar">
						<?php if ( $agent_page_url ) : ?>
							<a class="mwpa-kit-view-btn" href="<?php echo esc_url( $agent_page_url ); ?>" target="_blank" rel="noopener">
								<?php esc_html_e( 'View my page', 'multiwander-packages' ); ?> ↗
							</a>
						<?php endif; ?>
						<button type="submit" class="mwpa-kit-save-btn">
							<?php esc_html_e( 'Save changes', 'multiwander-packages' ); ?>
						</button>
					</div>

				</form>
			</div><!-- .mwpa-kit-content -->

		</div><!-- .mwpa-kit-wrap -->
		<?php
	}
}
