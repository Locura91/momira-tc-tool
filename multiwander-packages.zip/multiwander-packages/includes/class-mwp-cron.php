<?php
/**
 * Keeping the pages in step with Travel Compositor.
 *
 * Packages change on the Travel Compositor side — prices move, hotels get
 * swapped, descriptions are rewritten — and nobody edits the WordPress page
 * when that happens. Without a scheduled refresh the site slowly drifts out of
 * date and starts advertising prices that no longer exist.
 *
 * Work is done in small batches. A site with thirty country pages, each with
 * several packages, each needing six API calls in two languages, is far more
 * than one PHP request should attempt: it would hit the execution time limit
 * and leave the run half finished. So each pass takes a few country pages,
 * remembers where it stopped, and continues on the next.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Cron {

	const HOOK        = 'mwp_scheduled_sync';
	const OPT_ENABLED = 'mwp_cron_enabled';
	const OPT_CURSOR  = 'mwp_cron_cursor';
	const OPT_LAST    = 'mwp_cron_last_run';
	const OPT_REPORT  = 'mwp_cron_last_report';

	const HOOK_ONE = 'mwp_refresh_package';

	public static function init() {
		add_action( self::HOOK_ONE, array( __CLASS__, 'refresh_one' ), 10, 1 );
		add_action( 'template_redirect', array( __CLASS__, 'freshen_on_view' ) );

		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'ensure_schedule' ) );
		add_action( 'admin_post_mwp_sync_all', array( __CLASS__, 'handle_sync_all' ) );
	}

	/**
	 * Keep the scheduled event in line with the setting.
	 *
	 * @return void
	 */
	public static function ensure_schedule() {
		$enabled  = self::enabled();
		$next     = wp_next_scheduled( self::HOOK );

		if ( $enabled && ! $next ) {
			// Start a few minutes out so activating the plugin doesn't fire a
			// full sync on the very next page load.
			wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, self::interval(), self::HOOK );
			return;
		}

		if ( ! $enabled && $next ) {
			wp_unschedule_event( $next, self::HOOK );
		}
	}

	/**
	 * @return bool
	 */
	public static function enabled() {
		// Default on: a travel site showing last month's prices is worse than
		// a little background API traffic.
		return (bool) get_option( self::OPT_ENABLED, 1 );
	}

	/**
	 * @return string A WP-Cron schedule name.
	 */
	public static function interval() {
		return (string) apply_filters( 'mwp_cron_interval', 'daily' );
	}

	/**
	 * How many country pages one pass handles.
	 *
	 * @return int
	 */
	public static function batch_size() {
		// Packages per run, not country pages — the unit changed when the
		// refresh started walking package pages directly. Fifteen is about
		// ninety API calls, comfortably inside a PHP timeout, and gets a
		// catalogue of a few hundred trips fully refreshed within a day or two
		// of rotation rather than a week.
		return max( 1, (int) apply_filters( 'mwp_cron_batch', 15 ) );
	}

	/**
	 * Every country page that has package IDs on it.
	 *
	 * @return int[] Post IDs.
	 */
	public static function country_pages() {
		$found = get_posts( array(
			'post_type'        => 'page',
			'post_status'      => array( 'publish', 'draft', 'private' ),
			'posts_per_page'   => -1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'suppress_filters' => false,
			'lang'             => '',   // all languages; the sync itself resolves to Polish
			'meta_query'       => array(
				array(
					'key'     => MWP_META_IDS,
					'compare' => 'EXISTS',
				),
			),
		) );

		// A package page also carries IDs meta in some edge cases; never treat
		// one as a country page or the sync would recurse into itself.
		return array_values( array_filter( $found, function ( $id ) {
			return ! get_post_meta( $id, MWP_META_ID, true )
				&& MWP_Sync::get_package_ids( $id );
		} ) );
	}

	/**
	 * How old a package may be before a visit triggers a refresh.
	 *
	 * @return int Seconds.
	 */
	public static function max_age() {
		return max( 60, (int) apply_filters( 'mwp_max_age', 2 * HOUR_IN_SECONDS ) );
	}

	/**
	 * Someone opened a package page — check whether it is stale.
	 *
	 * The daily rotation keeps the catalogue broadly current, but a package
	 * whose photographs or price changed this morning would otherwise wait its
	 * turn, and the pages that matter most are precisely the ones people are
	 * looking at.
	 *
	 * The refresh is SCHEDULED, not performed. Calling Travel Compositor
	 * during a page load would put three API calls in front of a visitor and
	 * hand the site's speed to someone else's server — the one thing this
	 * plugin was built to avoid. Instead the work is queued and runs straight
	 * afterwards, so the page in front of this visitor is the stored one and
	 * the next view is fresh.
	 *
	 * @return void
	 */
	public static function freshen_on_view() {
		if ( is_admin() || ! is_singular( 'page' ) || is_feed() ) {
			return;
		}

		$post_id = (int) get_queried_object_id();
		if ( ! $post_id ) {
			return;
		}

		$package_id = (string) get_post_meta( $post_id, MWP_META_ID, true );
		if ( '' === $package_id || ! MWP_Client::is_configured() ) {
			return;
		}

		if ( ! apply_filters( 'mwp_refresh_on_view', true, $post_id ) ) {
			return;
		}

		// Stored as a MySQL datetime in site time, not a timestamp — casting
		// it to an int would read "2026-09-23 10:00:00" as the year 2026 and
		// declare every page fresh forever.
		$synced = (string) get_post_meta( $post_id, MWP_META_SYNCED, true );
		$age    = $synced ? ( time() - (int) get_date_from_gmt( $synced, 'U' ) ) : PHP_INT_MAX;

		if ( $age < self::max_age() ) {
			return;
		}

		// One queued refresh per package at a time, however many people are
		// reading it — otherwise a popular trip would queue a job per view.
		if ( wp_next_scheduled( self::HOOK_ONE, array( $package_id ) ) ) {
			return;
		}

		wp_schedule_single_event( time() + 5, self::HOOK_ONE, array( $package_id ) );
	}

	/**
	 * Refresh exactly one package, in the background.
	 *
	 * @param string $package_id Travel Compositor ID.
	 * @return void
	 */
	public static function refresh_one( $package_id ) {
		if ( ! MWP_Client::is_configured() ) {
			return;
		}

		MWP_Client::flush_cache();

		$sync   = new MWP_Sync();
		$result = $sync->sync_package( $package_id, 0 );

		if ( is_wp_error( $result ) ) {
			mwp_log( 'On-view refresh failed', array(
				'package' => $package_id,
				'error'   => $result->get_error_message(),
			) );
		}
	}

	/**
	 * Every package page this site has, by its Travel Compositor ID.
	 *
	 * The refresh used to be driven entirely by country pages: walk the pages
	 * that carry IDs, sync whatever is listed on them. That leaves a hole big
	 * enough to matter — a trip whose ID has since been taken off every
	 * country page still has a live, indexed page of its own, and nothing ever
	 * visits it again. Its price, itinerary and photographs freeze on the day
	 * the ID was removed, and no one finds out until a customer books against
	 * a price that no longer exists.
	 *
	 * Driving the refresh from the package pages themselves closes it: if the
	 * page exists, it gets refreshed, however it came to be there.
	 *
	 * Polish only — sync_package writes both languages from one call.
	 *
	 * @return string[] Package IDs, oldest sync first.
	 */
	public static function package_ids() {
		$pages = get_posts( array(
			'post_type'        => 'page',
			'post_status'      => array( 'publish', 'draft', 'private', 'pending' ),
			'posts_per_page'   => -1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'suppress_filters' => false,
			'lang'             => 'pl',
			'meta_query'       => array(
				array(
					'key'     => MWP_META_ID,
					'compare' => 'EXISTS',
				),
			),
		) );

		$ids = array();

		foreach ( $pages as $page_id ) {
			$package_id = (string) get_post_meta( $page_id, MWP_META_ID, true );
			if ( '' !== $package_id && ! in_array( $package_id, $ids, true ) ) {
				$ids[] = $package_id;
			}
		}

		// A country page can also list an ID that has no page yet — a trip
		// added since the last run. Those are picked up here too, so a new ID
		// does not have to wait for someone to press save again.
		foreach ( self::country_pages() as $country_id ) {
			foreach ( MWP_Sync::get_package_ids( $country_id ) as $package_id ) {
				if ( ! in_array( (string) $package_id, $ids, true ) ) {
					$ids[] = (string) $package_id;
				}
			}
		}

		return $ids;
	}

	/**
	 * One scheduled pass.
	 *
	 * @return array{done:int,packages:int,errors:array}
	 */
	public static function run() {
		if ( ! MWP_Client::is_configured() ) {
			return array(
				'done'     => 0,
				'packages' => 0,
				'errors'   => array( __( 'Credentials are not configured.', 'multiwander-packages' ) ),
			);
		}

		$pages = self::package_ids();
		if ( ! $pages ) {
			update_option( self::OPT_LAST, current_time( 'mysql' ), false );
			return array(
				'done'     => 0,
				'packages' => 0,
				'errors'   => array(),
			);
		}

		$cursor = (int) get_option( self::OPT_CURSOR, 0 );
		if ( $cursor >= count( $pages ) ) {
			$cursor = 0;
		}

		$slice = array_slice( $pages, $cursor, self::batch_size() );

		// Fresh data is the whole point of the run, so drop the response cache
		// first — otherwise an hour-old cached price would just be rewritten.
		MWP_Client::flush_cache();

		$sync     = new MWP_Sync();
		$packages = 0;
		$errors   = array();

		foreach ( $slice as $package_id ) {
			// Each package is fetched fresh and written over its own pages:
			// title, description, price, day-by-day itinerary and gallery all
			// come from this one call, so a change made in Travel Compositor
			// reaches the site without anyone touching WordPress.
			$result = $sync->sync_package( $package_id, 0 );

			if ( is_wp_error( $result ) ) {
				$errors[] = sprintf( '%s: %s', $package_id, $result->get_error_message() );
				continue;
			}

			++$packages;

			foreach ( (array) $result['warnings'] as $warning ) {
				$errors[] = sprintf( '%s: %s', $package_id, $warning );
			}
		}

		$next = $cursor + count( $slice );
		update_option( self::OPT_CURSOR, $next >= count( $pages ) ? 0 : $next, false );
		update_option( self::OPT_LAST, current_time( 'mysql' ), false );
		update_option( self::OPT_REPORT, array(
			'pages'    => count( $slice ),
			'packages' => $packages,
			'errors'   => array_slice( $errors, 0, 10 ),
			'total'    => count( $pages ),
		), false );

		if ( $errors ) {
			mwp_log( 'Scheduled sync finished with errors', $errors );
		}

		return array(
			'done'     => count( $slice ),
			'packages' => $packages,
			'errors'   => $errors,
		);
	}

	/**
	 * "Sync everything now" from the settings screen.
	 *
	 * @return void
	 */
	public static function handle_sync_all() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'multiwander-packages' ) );
		}
		check_admin_referer( 'mwp_sync_all' );

		// Start from the beginning rather than wherever the cron happens to be.
		update_option( self::OPT_CURSOR, 0, false );
		self::run();

		wp_safe_redirect( admin_url( 'options-general.php?page=mwp-settings&mwp_synced=1' ) );
		exit;
	}

	/**
	 * Remove the scheduled event (called on deactivation).
	 *
	 * @return void
	 */
	public static function clear() {
		$next = wp_next_scheduled( self::HOOK );
		if ( $next ) {
			wp_unschedule_event( $next, self::HOOK );
		}
	}
}
