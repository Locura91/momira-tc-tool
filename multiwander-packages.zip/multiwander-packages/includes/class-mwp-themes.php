<?php
/**
 * Travel themes → theme landing pages.
 *
 * Travel Compositor tags every package with themes ("Beach", "Cities",
 * "Southeast Asia", "Asia", "City & Beach"). MultiWander runs a landing page
 * for a handful of themes that actually sell — Island Hopping, Car Rental,
 * City & Beach, City Break, Safari, Around the World — and those pages were
 * being filled by hand, which means they were only ever as current as the last
 * person who remembered to update them.
 *
 * This maps one to the other: when a package carries a mapped theme, its ID is
 * added to that landing page's own list, so the page starts showing it on the
 * next load. Nothing else about the page changes.
 *
 * Deliberately additive. A theme disappearing from a package does NOT strip the
 * ID from the landing page — a merchandiser may have added it on purpose, and
 * silently removing someone's work because a tag moved in another system is the
 * kind of surprise that destroys trust in automation. Removals stay manual.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Themes {

	const OPTION = 'mwp_theme_pages';

	/**
	 * The themes MultiWander has a landing page for.
	 *
	 * The key is internal and never changes; the label is what an editor sees;
	 * `match` lists the wordings Travel Compositor might use for it, because
	 * the two systems were named by different people at different times. All
	 * matching is case- and accent-insensitive, so "City & Beach", "city and
	 * beach" and "CITY&BEACH" are one thing.
	 *
	 * @return array<string,array{label:string,match:string[]}>
	 */
	public static function catalogue() {
		return apply_filters( 'mwp_theme_catalogue', array(
			'island_hopping' => array(
				'page'  => '/en/travel-highlights/island-hopping-holiday/',
				'label' => __( 'Island Hopping', 'multiwander-packages' ),
				'match' => array( 'island hopping', 'island-hopping', 'islands', 'wyspy', 'island hopping tour' ),
			),
			'car_rental' => array(
				'page'  => '/en/travel-highlights/car-rental-round-trip/',
				'label' => __( 'Car Rental', 'multiwander-packages' ),
				// "Wynająć samochód" is what Travel Compositor actually calls
				// this theme in Polish — measured on a live package, not
				// guessed. The plausible-looking "wynajem samochodu" that used
				// to be here matched nothing, which is why the Car Rental page
				// stayed empty while its packages carried the right theme.
				'match' => array(
					'car rental', 'self drive', 'self-drive', 'fly and drive', 'fly & drive', 'rent a car',
					'wynajac samochod', 'wynająć samochód', 'wynajem samochodu', 'samochod na wynajem',
				),
			),
			'city_beach' => array(
				'page'  => '/en/travel-highlights/city-beach/',
				'label' => __( 'City & Beach', 'multiwander-packages' ),
				'match' => array( 'city & beach', 'city and beach', 'city beach', 'miasto i plaza', 'miasto i plaża' ),
			),
			'city_break' => array(
				'page'  => '/en/travel-highlights/city-break-travel/',
				'label' => __( 'City Break', 'multiwander-packages' ),
				// "City Breaks" is a theme created in Travel Compositor for
				// exactly this page, so it is the only wording that should
				// route here. The earlier list also matched "Cities" and
				// "City" — tags that sit on most urban trips — which would
				// have filled the City Break page with everything that
				// happens to visit a city.
				'match' => array( 'city breaks', 'city break' ),
			),
			'safari' => array(
				'page'  => '/en/travel-highlights/safari-holiday/',
				'label' => __( 'Safari', 'multiwander-packages' ),
				'match' => array( 'safari', 'wildlife', 'big five', 'safari tour' ),
			),
			'around_the_world' => array(
				'page'  => '/en/travel-highlights/around-the-world-travel/',
				'label' => __( 'Around the World', 'multiwander-packages' ),
				'match' => array( 'around the world', 'round the world', 'world tour', 'dookola swiata', 'dookoła świata' ),
			),
		) );
	}

	/**
	 * Which page each theme fills. Set on the settings screen.
	 *
	 * @return array<string,int>
	 */
	public static function pages() {
		static $resolved = null;

		if ( null !== $resolved ) {
			return $resolved;
		}

		$saved = get_option( self::OPTION, array() );
		$saved = is_array( $saved ) ? $saved : array();

		/*
		 * The six landing pages already exist and their addresses are known, so
		 * the mapping ships configured rather than waiting for someone to fill
		 * a form before any of it does anything. A path saved on the settings
		 * screen always wins; these are only the fallback, and they resolve at
		 * runtime rather than being baked in as IDs — an ID from one install
		 * means nothing on another.
		 */
		foreach ( self::catalogue() as $key => $theme ) {
			if ( ! empty( $saved[ $key ] ) ) {
				continue;
			}

			if ( empty( $theme['page'] ) ) {
				continue;
			}

			$page_id = self::resolve_page( $theme['page'] );
			if ( $page_id ) {
				$saved[ $key ] = $page_id;
			}
		}

		$resolved = $saved;

		return $resolved;
	}

	/**
	 * Turn a pasted page address into the page it points at.
	 *
	 * Accepts a full URL, a path, or a bare ID. An English address resolves to
	 * its Polish original, because that is where the ID list lives for every
	 * page on this site — paste either one and the right thing happens.
	 *
	 * @param string $value What was typed into the settings box.
	 * @return int Page ID, or 0 if it does not resolve to a page on this site.
	 */
	public static function resolve_page( $value ) {
		$value = trim( (string) $value );

		if ( '' === $value ) {
			return 0;
		}

		// A bare number is a page ID.
		if ( ctype_digit( $value ) ) {
			$page_id = (int) $value;
			return 'page' === get_post_type( $page_id ) ? MWP_Sync::source_country_id( $page_id ) : 0;
		}

		if ( 0 === strpos( $value, '/' ) ) {
			$value = home_url( $value );
		}

		$page_id = (int) url_to_postid( $value );

		/*
		 * url_to_postid gives up on a Polylang URL whose language prefix it
		 * does not expect, and on a URL carrying a query string or a trailing
		 * anchor. Falling back to the path itself catches both: the last
		 * meaningful segment IS the page slug, and get_page_by_path walks the
		 * hierarchy from there.
		 */
		if ( ! $page_id ) {
			$path = (string) wp_parse_url( $value, PHP_URL_PATH );
			$path = trim( $path, '/' );

			if ( '' !== $path ) {
				$segments = explode( '/', $path );

				// Drop a leading language prefix ("en", "pl") if there is one.
				if ( isset( $segments[0] ) && preg_match( '/^[a-z]{2}$/', $segments[0] ) ) {
					array_shift( $segments );
				}

				$found = get_page_by_path( implode( '/', $segments ) );
				if ( ! $found && $segments ) {
					$found = get_page_by_path( end( $segments ) );
				}
				if ( $found instanceof WP_Post ) {
					$page_id = (int) $found->ID;
				}
			}
		}

		if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
			return 0;
		}

		return MWP_Sync::source_country_id( $page_id );
	}

	/**
	 * Fold a theme name down to something comparable.
	 *
	 * Lower case, accents stripped, "&" spelled out, punctuation dropped: the
	 * two systems disagree about all four, and none of it is meaningful.
	 *
	 * @param string $text Theme name.
	 * @return string
	 */
	protected static function fold( $text ) {
		$text = (string) $text;
		$text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
		$text = remove_accents( $text );
		$text = str_replace( '&', ' and ', $text );
		$text = preg_replace( '/[^a-z0-9]+/', ' ', $text );

		return trim( preg_replace( '/\s+/', ' ', $text ) );
	}

	/**
	 * Re-check every package already on the site against the theme pages.
	 *
	 * Routing normally happens during a sync, which means a change to the
	 * matching rules only reaches a package the next time that package is
	 * synced — days away on the daily rotation. This walks the package pages
	 * instead and routes from the themes already stored on each one, so no
	 * Travel Compositor call is made and the whole site is brought up to date
	 * in one pass.
	 *
	 * Both languages are walked, which is how a package whose theme is only
	 * recognisable in English still lands on its page: the two stored payloads
	 * together say everything the live sync would have said.
	 *
	 * @return array{checked:int, added:int} What it found and what it changed.
	 */
	public static function route_all() {
		$pages = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => 'any',
				'posts_per_page'   => -1,
				'no_found_rows'    => true,
				'fields'           => 'ids',
				'suppress_filters' => true,
				'lang'             => '',
				'meta_query'       => array(
					array(
						'key'     => MWP_META_ID,
						'compare' => 'EXISTS',
					),
				),
			)
		);

		$added = 0;

		foreach ( $pages as $page_id ) {
			$package_id = (string) get_post_meta( $page_id, MWP_META_ID, true );
			$data       = MWP_Sync::get_data( $page_id );

			if ( '' === $package_id || ! $data ) {
				continue;
			}

			$added += count( self::route( $package_id, $data ) );
		}

		return array(
			'checked' => count( $pages ),
			'added'   => $added,
		);
	}

	/**
	 * One payload carrying the themes of every language fetched.
	 *
	 * Travel Compositor translates its theme names, and the two versions do
	 * not correspond word for word: "Rent a Car" is "Wynająć samochód", not a
	 * phrase any list of guesses would have contained. Routing read only the
	 * Polish payload, so an English name the plugin knew perfectly well was
	 * never consulted, and packages sat on the site with the right theme
	 * attached and no theme page to show for it.
	 *
	 * Matching the union removes the guesswork: a theme only has to be
	 * recognisable in ONE of the languages for the package to land on the
	 * right page, and a wording Travel Compositor changes in Polish no longer
	 * silently empties a landing page.
	 *
	 * @param array<string,array> $payloads Language slug => normalised payload.
	 * @return array Payload shape carrying every theme name seen.
	 */
	public static function both( array $payloads ) {
		$themes = array();

		foreach ( $payloads as $payload ) {
			if ( ! is_array( $payload ) || empty( $payload['themes'] ) ) {
				continue;
			}
			foreach ( (array) $payload['themes'] as $theme ) {
				$themes[] = $theme;
			}
		}

		$base           = isset( $payloads['pl'] ) && is_array( $payloads['pl'] ) ? $payloads['pl'] : array();
		$base['themes'] = array_values( array_unique( $themes ) );

		return $base;
	}

	/**
	 * Which configured theme, if any, a single Travel Compositor label is.
	 *
	 * The catalogue needs this to tell a headline theme from a long-tail one.
	 * It is the same comparison match() makes, applied to one name instead of
	 * a package's whole list, so the two can never drift apart: if a label
	 * routes a package to the Safari page, it is "Safari" in the catalogue too.
	 *
	 * @param string $label Theme name as Travel Compositor spells it.
	 * @return string Theme key, or '' when it is not one of ours.
	 */
	public static function key_for_label( $label ) {
		$folded = self::fold( $label );

		if ( '' === $folded ) {
			return '';
		}

		foreach ( self::catalogue() as $key => $theme ) {
			foreach ( $theme['match'] as $candidate ) {
				if ( self::fold( $candidate ) === $folded ) {
					return $key;
				}
			}
		}

		return '';
	}

	/**
	 * The configured theme keys a package matches.
	 *
	 * @param array $data Normalised package payload.
	 * @return string[] Theme keys.
	 */
	public static function match( array $data ) {
		$themes = isset( $data['themes'] ) ? (array) $data['themes'] : array();
		if ( ! $themes ) {
			return array();
		}

		$have = array();
		foreach ( $themes as $theme ) {
			$folded = self::fold( $theme );
			if ( '' !== $folded ) {
				$have[] = $folded;
			}
		}

		if ( ! $have ) {
			return array();
		}

		$hit = array();

		foreach ( self::catalogue() as $key => $theme ) {
			foreach ( $theme['match'] as $candidate ) {
				if ( in_array( self::fold( $candidate ), $have, true ) ) {
					$hit[] = $key;
					break;
				}
			}
		}

		return $hit;
	}

	/**
	 * Add a package to every theme page its themes call for.
	 *
	 * @param string $package_id Travel Compositor ID.
	 * @param array  $data       Normalised payload (Polish).
	 * @return string[] Labels of the pages it was added to, for the sync report.
	 */
	public static function route( $package_id, array $data ) {
		$package_id = mwp_extract_id( $package_id );
		if ( '' === $package_id ) {
			return array();
		}

		$pages     = self::pages();
		$catalogue = self::catalogue();
		$added     = array();

		foreach ( self::match( $data ) as $key ) {
			$page_id = isset( $pages[ $key ] ) ? (int) $pages[ $key ] : 0;

			if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
				continue;
			}

			// Themes are configured against Polish pages, same as everywhere
			// else; the English page reads the list from its translation.
			$page_id = MWP_Sync::source_country_id( $page_id );

			$ids = MWP_Sync::get_package_ids( $page_id );
			if ( in_array( $package_id, $ids, true ) ) {
				continue;
			}

			$ids[] = $package_id;
			update_post_meta( $page_id, MWP_META_IDS, implode( "\n", $ids ) );
			MWP_Sync::mirror_settings( $page_id );

			$added[] = isset( $catalogue[ $key ]['label'] ) ? $catalogue[ $key ]['label'] : $key;
		}

		return $added;
	}
}
