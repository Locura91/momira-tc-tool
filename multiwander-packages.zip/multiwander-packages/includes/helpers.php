<?php
/**
 * Small shared helpers.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Unwrap a Travel Compositor money object.
 *
 * TC never returns a bare number for money. Every price is
 * {"amount": 2477.75, "currency": "EUR"}. Handing that dict to a generic
 * number parser silently produces garbage, so always come through here.
 *
 * @param mixed $value Raw value from the API.
 * @return array{amount: float|null, currency: string}
 */
function mwp_money( $value ) {
	$out = array(
		'amount'   => null,
		'currency' => 'EUR',
	);

	if ( is_array( $value ) ) {
		if ( isset( $value['amount'] ) && is_numeric( $value['amount'] ) ) {
			$out['amount'] = (float) $value['amount'];
		}
		if ( ! empty( $value['currency'] ) && is_string( $value['currency'] ) ) {
			$out['currency'] = strtoupper( $value['currency'] );
		}
		return $out;
	}

	// A bare number would be unexpected, but don't throw away a usable value.
	if ( is_numeric( $value ) ) {
		$out['amount'] = (float) $value;
	}

	return $out;
}

/**
 * Read a key from an array case-insensitively, trying several likely names.
 *
 * TC's field naming is inconsistent enough that hard-coding one guess is
 * risky. This scans the response's own keys and — importantly — records
 * which key actually matched, so a wrong guess surfaces in the debug view
 * instead of silently reading a nonsense field forever.
 *
 * @param array  $haystack Source array.
 * @param array  $names    Candidate key names, best first.
 * @param mixed  $default  Returned when nothing matches.
 * @param string $matched  Receives the key that matched.
 * @return mixed
 */
function mwp_pick( $haystack, array $names, $default = null, &$matched = '' ) {
	$matched = '';
	if ( ! is_array( $haystack ) ) {
		return $default;
	}

	$lower = array();
	foreach ( $haystack as $key => $value ) {
		$lower[ strtolower( (string) $key ) ] = $key;
	}

	foreach ( $names as $name ) {
		$needle = strtolower( $name );
		if ( isset( $lower[ $needle ] ) ) {
			$real = $lower[ $needle ];
			if ( null !== $haystack[ $real ] && '' !== $haystack[ $real ] ) {
				$matched = $real;
				return $haystack[ $real ];
			}
		}
	}

	return $default;
}

/**
 * Turn a Travel Compositor title into a URL slug.
 *
 * TC titles arrive with trailing whitespace ("… Angkor Wat    ") and Polish
 * diacritics. Left alone that produces slugs with stray trailing dashes,
 * which is exactly what the old offer IDs suffered from.
 *
 * @param string $title Raw title.
 * @return string
 */
function mwp_slug( $title ) {
	$title = trim( (string) $title );
	$title = str_replace( array( '&', '+' ), ' ', $title );
	$title = remove_accents( $title );          // Kambodża -> Kambodza
	$slug  = sanitize_title( $title );
	$slug  = trim( $slug, '-' );

	if ( '' === $slug ) {
		$slug = 'pakiet-' . wp_generate_password( 6, false, false );
	}

	// Keep permalinks readable; TC titles can run very long.
	if ( strlen( $slug ) > 90 ) {
		$slug = substr( $slug, 0, 90 );
		$slug = preg_replace( '/-[^-]*$/', '', $slug ); // don't cut mid-word
		$slug = trim( $slug, '-' );
	}

	return $slug;
}

/**
 * Extract a numeric package ID from whatever the editor pasted.
 *
 * Accepts a bare ID, or a full momira.travel / Travel Compositor URL such as
 * https://momira.travel/en/idea/59875907/vietnam-cambodia-from-hanoi-to-angkor-wat-
 *
 * @param string $input Raw input.
 * @return string Numeric id, or '' when nothing usable was found.
 */
function mwp_extract_id( $input ) {
	$input = trim( (string) $input );
	if ( '' === $input ) {
		return '';
	}

	if ( preg_match( '/^\d{4,}$/', $input ) ) {
		return $input;
	}

	// .../idea/59875907/slug  or  ?id=59875907
	if ( preg_match( '#/idea/(\d{4,})#i', $input, $m ) ) {
		return $m[1];
	}
	if ( preg_match( '#[?&]id=(\d{4,})#i', $input, $m ) ) {
		return $m[1];
	}

	// Last resort: the longest run of digits in the string.
	if ( preg_match_all( '/\d{4,}/', $input, $m ) ) {
		usort( $m[0], function ( $a, $b ) {
			return strlen( $b ) <=> strlen( $a );
		} );
		return $m[0][0];
	}

	return '';
}

/**
 * Coerce a value that TC returns inconsistently as either a string or a list.
 *
 * Confirmed real variance: `roomTypes` and `mealPlan` come back as a plain
 * string on some packages ("SUPERIOR Flexi") and as an array on others.
 * Casting an array to string raises a PHP warning and yields "Array", so
 * always come through here.
 *
 * @param mixed  $value Raw value.
 * @param string $glue  Separator used when joining a list.
 * @return string
 */
function mwp_text( $value, $glue = ', ' ) {
	if ( is_string( $value ) ) {
		return trim( $value );
	}
	if ( is_numeric( $value ) ) {
		return (string) $value;
	}
	if ( is_array( $value ) ) {
		$parts = array();
		foreach ( $value as $item ) {
			if ( is_string( $item ) || is_numeric( $item ) ) {
				$parts[] = trim( (string) $item );
			} elseif ( is_array( $item ) ) {
				// e.g. [{"name": "SUPERIOR Flexi"}]
				$inner = mwp_pick( $item, array( 'name', 'description', 'text', 'value' ), '' );
				if ( is_string( $inner ) && '' !== $inner ) {
					$parts[] = trim( $inner );
				}
			}
		}
		return implode( $glue, array_filter( array_unique( $parts ) ) );
	}
	return '';
}

/**
 * Convert a TC hotel category code to a star count.
 *
 * Real values seen: "S4" (superior 4), "4", "4EST", "H4". Anything we can't
 * read returns 0 and the template simply shows no stars.
 *
 * @param string $category Raw category.
 * @return int 0-5
 */
function mwp_stars( $category ) {
	if ( ! is_string( $category ) || '' === $category ) {
		return 0;
	}
	if ( preg_match( '/(\d)/', $category, $m ) ) {
		$n = (int) $m[1];
		return ( $n >= 1 && $n <= 5 ) ? $n : 0;
	}
	return 0;
}

/**
 * Format a price for display, converting EUR to PLN where appropriate.
 *
 * Travel Compositor returns EUR for this microsite, so Polish pages need a
 * conversion. The child theme already owns that logic in
 * inc/exchange-rate.php; reuse it rather than adding a second rate source.
 *
 * @param array       $money    Result of mwp_money().
 * @param string      $lang     Language slug ('pl' or 'en'). Used only when
 *                              $currency is left to decide on its own.
 * @param string|null $currency_pref Explicit override: 'eur' shows the
 *                              amount in euros with no conversion, 'pln'
 *                              always converts to złoty. Null (the default)
 *                              keeps the old behaviour of following $lang —
 *                              Polish pages convert to PLN, everything else
 *                              stays in its original currency.
 * @return array{value: string, symbol: string, converted: bool}
 */
function mwp_format_price( $money, $lang = 'pl', $currency_pref = null ) {
	$amount = isset( $money['amount'] ) ? $money['amount'] : null;
	if ( null === $amount ) {
		return array(
			'value'     => '',
			'symbol'    => '',
			'converted' => false,
		);
	}

	$currency = isset( $money['currency'] ) ? $money['currency'] : 'EUR';

	$currency_pref = ( 'eur' === $currency_pref || 'pln' === $currency_pref ) ? $currency_pref : null;

	// An explicit agent choice wins outright: 'eur' never converts, 'pln'
	// always does (when there is a rate to do it with). Leaving it unset
	// falls back to the old rule — Polish pages convert, others don't.
	$want_pln = ( 'pln' === $currency_pref ) || ( null === $currency_pref && 'pl' === $lang );

	if ( $want_pln && 'EUR' === $currency && function_exists( 'get_eur_to_pln_exchange_rate' ) ) {
		$rate = (float) get_eur_to_pln_exchange_rate();
		if ( $rate > 0 ) {
			return array(
				'value'     => number_format( round( $amount * $rate ), 0, ',', ' ' ),
				'symbol'    => 'zł',
				'converted' => true,
			);
		}
	}

	$symbols = array(
		'EUR' => '€',
		'PLN' => 'zł',
		'USD' => '$',
		'GBP' => '£',
	);

	return array(
		'value'     => number_format( round( $amount ), 0, ',', ' ' ),
		'symbol'    => isset( $symbols[ $currency ] ) ? $symbols[ $currency ] : $currency,
		'converted' => false,
	);
}

/**
 * The deep link that opens a package in the travel builder, already filled in.
 *
 * CONFIRMED against the live microsite (2026-09-08):
 *
 *     /idea-deeplink.xhtml?idea={id}&departureDate=DD/MM/YYYY&distribution={adults}-{children}
 *
 * redirects to travel-map.xhtml with that package loaded, on that date, for
 * that party. This is the whole handover, and it is an ordinary link.
 *
 * It took a while to find because the obvious routes all fail: the idea page
 * ignores query parameters, travel-map.xhtml builds an EMPTY trip whatever you
 * pass it, and the search form on the idea page is JSF with a per-view state
 * token that cannot be produced from another site. The deep link was visible
 * only in the redirect chain of another Travel Compositor white-label.
 *
 * Multiple rooms are not expressible here — "2-0|2-1", "2-0,2-1" and "2-0!2-1"
 * were all rejected. The whole party therefore travels as one distribution and
 * the visitor splits it into rooms in the builder, which is one step rather
 * than the whole question being asked again.
 *
 * @param string $package_id Travel Compositor package ID.
 * @param string $date       Start date, ISO (YYYY-MM-DD) or already DD/MM/YYYY.
 * @param int    $adults     Adults.
 * @param int    $children   Children.
 * @return string
 */
function mwp_deeplink_url( $package_id, $date = '', $adults = 0, $children = 0 ) {
	$id = preg_replace( '/\D/', '', (string) $package_id );

	if ( '' === $id ) {
		return '';
	}

	$base = untrailingslashit( (string) apply_filters( 'mwp_booking_base', MWP_BOOKING_BASE ) );
	$args = array( 'idea' => $id );

	// The engine wants DD/MM/YYYY; the date field speaks ISO.
	$date = trim( (string) $date );
	if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m ) ) {
		$date = $m[3] . '/' . $m[2] . '/' . $m[1];
	}
	if ( preg_match( '#^\d{2}/\d{2}/\d{4}$#', $date ) ) {
		$args['departureDate'] = $date;
	}

	$adults = (int) $adults;
	if ( $adults > 0 ) {
		$args['distribution'] = $adults . '-' . max( 0, (int) $children );
	}

	// Built by hand rather than with add_query_arg: the engine wants the
	// slashes in the date literally, and encoding them breaks the link.
	$query = array();
	foreach ( $args as $key => $value ) {
		$query[] = $key . '=' . $value;
	}

	return apply_filters(
		'mwp_deeplink_url',
		$base . '/idea-deeplink.xhtml?' . implode( '&', $query ),
		$id,
		$args
	);
}

/**
 * Swap any Travel Compositor host in a URL for MultiWander's own.
 *
 * The API hands back addresses on online.travelcompositor.com, and older data
 * carries momira.travel ones. Both are the same platform seen through a
 * different front door; ours is book.multiwander.com, which is also the only
 * one that keeps the visitor inside the MultiWander domain — the reason the
 * date and party choices survive the handover at all.
 *
 * Path and query are left exactly as they were.
 *
 * @param string $url URL.
 * @return string
 */
function mwp_brand_platform_url( $url ) {
	$url = trim( (string) $url );

	if ( '' === $url ) {
		return '';
	}

	$host = wp_parse_url( $url, PHP_URL_HOST );
	if ( ! $host ) {
		return $url;
	}

	$hosts = apply_filters(
		'mwp_platform_hosts',
		array( 'momira.travel', 'www.momira.travel', 'online.travelcompositor.com' )
	);

	if ( ! in_array( strtolower( $host ), array_map( 'strtolower', $hosts ), true ) ) {
		return $url;
	}

	$base = wp_parse_url( untrailingslashit( (string) apply_filters( 'mwp_booking_base', MWP_BOOKING_BASE ) ) );
	if ( empty( $base['host'] ) ) {
		return $url;
	}

	$scheme = isset( $base['scheme'] ) ? $base['scheme'] : 'https';

	return preg_replace(
		'#^[a-z]+://' . preg_quote( $host, '#' ) . '#i',
		$scheme . '://' . $base['host'],
		$url,
		1
	);
}

/**
 * The booking URL a visitor should be sent to.
 *
 * The API's own `ideaUrl` points at online.travelcompositor.com, which is the
 * raw platform. Visitors go to the branded front-end instead:
 *
 *     https://book.multiwander.com/{lang}/idea/{id}/{slug}
 *
 * The slug comes from the `title` parameter inside ideaUrl, which is already
 * the correct per-language slug that site uses — so the Polish page links to
 * the Polish trip page and the English page to the English one.
 *
 * @param array  $data Normalised package payload.
 * @param string $lang Site language slug ('pl', 'en').
 * @return string
 */
function mwp_booking_url( array $data, $lang = 'pl' ) {
	$stored = (string) get_option( 'mwp_booking_base', '' );

	// A base saved before the MultiWander subdomain existed still points at
	// momira.travel. Rather than leave those installs on the old host, an
	// untouched or legacy value falls through to the current default; only a
	// base someone has deliberately set to something else is honoured.
	if ( '' === $stored || false !== strpos( $stored, 'momira.travel' ) ) {
		$stored = MWP_BOOKING_BASE;
	}

	$base = untrailingslashit( (string) apply_filters( 'mwp_booking_base', $stored ) );

	$id = isset( $data['id'] ) ? preg_replace( '/\D/', '', (string) $data['id'] ) : '';

	if ( '' === $base || '' === $id ) {
		// Nothing better to offer than whatever the API gave us — with the
		// platform's own host swapped for the branded one, so even the
		// fallback never sends a visitor to travelcompositor.com.
		return isset( $data['booking_url'] ) ? mwp_brand_platform_url( (string) $data['booking_url'] ) : '';
	}

	$slug = '';

	if ( ! empty( $data['booking_url'] ) ) {
		$query = wp_parse_url( $data['booking_url'], PHP_URL_QUERY );
		if ( $query ) {
			$args = array();
			parse_str( $query, $args );
			if ( ! empty( $args['title'] ) ) {
				// Keep it byte-for-byte as the platform wrote it (including any
				// trailing dash) minus anything unsafe for a path segment.
				$slug = preg_replace( '/[^a-z0-9\-]/', '', strtolower( $args['title'] ) );
			}
		}
	}

	if ( '' === $slug ) {
		$slug = mwp_slug( isset( $data['title'] ) ? $data['title'] : '' );
	}

	return $base . '/' . rawurlencode( $lang ) . '/idea/' . $id . '/' . $slug;
}

/**
 * Traveller limits, matching what Travel Compositor itself accepts.
 *
 * @return array{max_pax:int,max_rooms:int,max_adults:int,max_children:int}
 */
function mwp_booking_limits() {
	return apply_filters( 'mwp_booking_limits', array(
		'max_pax'      => 9,
		'max_rooms'    => 4,
		'max_adults'   => 9,
		'max_children' => 8,   // at least one adult must travel
	) );
}

/**
 * Append a chosen date and party size to a booking URL.
 *
 * IMPORTANT — the parameter NAMES here are the one unverified thing in this
 * plugin. momira.travel and online.travelcompositor.com both refuse automated
 * requests, so they could not be read from a real booking link. They follow
 * Travel Compositor's usual naming and are wired through a filter so they can
 * be corrected in one place once a real link has been inspected:
 *
 *     add_filter( 'mwp_booking_query_args', function ( $args, $selection ) {
 *         return array( 'fecha' => $selection['date'] );   // e.g.
 *     }, 10, 2 );
 *
 * If the names turn out to be wrong the booking engine simply ignores them and
 * asks for the dates itself, exactly as it does today — nothing breaks, the
 * pre-selection just does not carry across.
 *
 * @param string $url       Base booking URL.
 * @param array  $selection date, adults, children, rooms.
 * @return string
 */
function mwp_booking_url_with_selection( $url, array $selection ) {
	if ( '' === $url ) {
		return '';
	}

	$limits = mwp_booking_limits();

	$date     = isset( $selection['date'] ) ? preg_replace( '/[^0-9-]/', '', $selection['date'] ) : '';
	$adults   = isset( $selection['adults'] ) ? (int) $selection['adults'] : 2;
	$children = isset( $selection['children'] ) ? (int) $selection['children'] : 0;
	$rooms    = isset( $selection['rooms'] ) ? (int) $selection['rooms'] : 1;

	$adults   = max( 1, min( $limits['max_adults'], $adults ) );
	$children = max( 0, min( $limits['max_children'], $children ) );
	$rooms    = max( 1, min( $limits['max_rooms'], $rooms ) );

	// Never send a party the engine cannot accept.
	if ( $adults + $children > $limits['max_pax'] ) {
		$children = max( 0, $limits['max_pax'] - $adults );
	}
	$rooms = min( $rooms, $adults );

	$args = array(
		'departureDate' => $date,
		'adults'        => $adults,
		'children'      => $children,
		'rooms'         => $rooms,
	);

	if ( '' === $date ) {
		unset( $args['departureDate'] );
	}

	$args = (array) apply_filters( 'mwp_booking_query_args', $args, $selection );

	return $args ? add_query_arg( array_map( 'rawurlencode', $args ), $url ) : $url;
}

/**
 * The Contact Form 7 form for a language.
 *
 * The Polish page must show the Polish form and the English page the English
 * one — a Polish enquiry arriving through the English form is worse than no
 * form at all, because nobody notices.
 *
 * The theme's own hidden `your-referrer` field records which page the enquiry
 * came from, so no extra tracking is needed here.
 *
 * @param string $lang Language slug.
 * @return string Form ID, or '' when none is configured for that language.
 */
function mwp_contact_form_id( $lang = 'pl' ) {
	$defaults = array(
		'pl' => '24390f0',   // "Polish Travel Inquiery"
		'en' => '4033794',   // "ENG Travel Inquiery"
	);

	$stored = get_option( 'mwp_cf7_' . $lang, '' );
	$id     = $stored ? $stored : ( isset( $defaults[ $lang ] ) ? $defaults[ $lang ] : '' );

	return (string) apply_filters( 'mwp_contact_form_id', $id, $lang );
}

/**
 * Where the "request advice" button goes.
 *
 * Defaults to the site's own contact page in the current language so the
 * enquiry stays on multiwander.com. Returns '' when nothing is configured,
 * and the button is then simply not rendered.
 *
 * @param string $lang Language slug.
 * @return string
 */
function mwp_enquiry_url( $lang = 'pl' ) {
	$url = (string) get_option( 'mwp_enquiry_url', '' );

	if ( '' === $url ) {
		$url = ( 'en' === $lang ) ? home_url( '/en/contact/' ) : home_url( '/kontakt/' );
	}

	return (string) apply_filters( 'mwp_enquiry_url', $url, $lang );
}

/**
 * Current Polylang language slug, with a sane default.
 *
 * @return string
 */
function mwp_current_lang() {
	if ( function_exists( 'pll_current_language' ) ) {
		$lang = pll_current_language( 'slug' );
		if ( $lang ) {
			return $lang;
		}
	}
	return 'pl';
}

/**
 * Languages this plugin syncs. Polish is the source, English the translation.
 * The site's Austrian/German language is deliberately out of scope: Travel
 * Compositor only carries PL and EN copy for these packages.
 *
 * @return array<string,string> site language slug => TC lang parameter
 */
function mwp_languages() {
	return apply_filters( 'mwp_languages', array(
		'pl' => 'PL',
		'en' => 'EN',
	) );
}

/**
 * Encryption key derived from this site's own salts.
 *
 * Those salts live in wp-config.php, never in the database, so a stolen
 * database export on its own cannot decrypt anything stored with this.
 *
 * @return string
 */
function mwp_crypt_key() {
	$material = '';
	foreach ( array( 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY' ) as $constant ) {
		if ( defined( $constant ) ) {
			$material .= constant( $constant );
		}
	}
	if ( '' === $material ) {
		// A WordPress install without salts is unusual; fall back to something
		// site-specific rather than a fixed string.
		$material = get_site_url() . ABSPATH;
	}
	return hash( 'sha256', 'mwp|' . $material, true );
}

/**
 * Encrypt a secret for storage in the options table.
 *
 * @param string $plaintext Value to protect.
 * @return string Base64 payload, or '' for empty input.
 */
function mwp_encrypt( $plaintext ) {
	$plaintext = (string) $plaintext;
	if ( '' === $plaintext ) {
		return '';
	}
	if ( ! function_exists( 'openssl_encrypt' ) ) {
		// Better to store readable than to lose the value silently; the
		// settings screen warns when this happens.
		return 'plain:' . base64_encode( $plaintext ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}

	$iv     = openssl_random_pseudo_bytes( 16 );
	$cipher = openssl_encrypt( $plaintext, 'aes-256-cbc', mwp_crypt_key(), OPENSSL_RAW_DATA, $iv );
	if ( false === $cipher ) {
		return '';
	}

	return 'enc:' . base64_encode( $iv . $cipher ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
}

/**
 * Decrypt a value written by mwp_encrypt().
 *
 * @param string $stored Stored payload.
 * @return string
 */
function mwp_decrypt( $stored ) {
	$stored = (string) $stored;
	if ( '' === $stored ) {
		return '';
	}

	if ( 0 === strpos( $stored, 'plain:' ) ) {
		return (string) base64_decode( substr( $stored, 6 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}

	if ( 0 !== strpos( $stored, 'enc:' ) || ! function_exists( 'openssl_decrypt' ) ) {
		return '';
	}

	$raw = base64_decode( substr( $stored, 4 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	if ( false === $raw || strlen( $raw ) <= 16 ) {
		return '';
	}

	$plain = openssl_decrypt(
		substr( $raw, 16 ),
		'aes-256-cbc',
		mwp_crypt_key(),
		OPENSSL_RAW_DATA,
		substr( $raw, 0, 16 )
	);

	return false === $plain ? '' : $plain;
}

/**
 * Write a line to the plugin log (only when WP_DEBUG is on).
 *
 * @param string $message Message.
 * @param mixed  $context Optional context.
 * @return void
 */
function mwp_log( $message, $context = null ) {
	if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
		return;
	}
	$line = '[MultiWander Packages] ' . $message;
	if ( null !== $context ) {
		$line .= ' ' . wp_json_encode( $context );
	}
	error_log( $line ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
}

/**
 * One <img> tag for every picture this plugin prints.
 *
 * Measured on the live site before this existed: a package page shipped
 * 1.9 MB, of which 1.3 MB was ONE photograph — the hero, a 908×726 PNG served
 * at its full weight into a 535×427 box, with no srcset for the browser to
 * choose from. Every other measurement came back healthy (the server renders a
 * 63-trip catalogue in 140 ms more than a blank page; layout shift is already
 * pinned by aspect-ratio in the CSS), so images were not one problem among
 * many. They were the problem.
 *
 * WordPress solves this for any picture in the media library — it keeps
 * several sizes and writes a srcset — but only through wp_get_attachment_image,
 * and the plugin was printing raw <img src> tags, which throws all of that
 * away. So: where the picture is an attachment, hand it to WordPress. Where it
 * is still hosted by Travel Compositor there is nothing to choose between, and
 * a plain tag is honest about that.
 *
 * @param string $url  Image URL.
 * @param string $alt  Alt text.
 * @param array  $args attachment_id, size, sizes, loading, fetchpriority, class.
 * @return string HTML, or '' when there is no picture.
 */
function mwp_image_tag( $url, $alt, array $args = array() ) {
	$args = array_merge(
		array(
			'attachment_id' => 0,
			'size'          => 'large',
			'sizes'         => '',
			'loading'       => 'lazy',
			'fetchpriority' => '',
			'class'         => '',
		),
		$args
	);

	$id = (int) $args['attachment_id'];

	// A URL on this site is very likely something we sideloaded, so it is
	// worth one lookup to find its attachment — cached per request, because a
	// catalogue page asks about sixty of them.
	if ( ! $id && $url ) {
		$id = mwp_attachment_id_for_url( $url );
	}

	$attrs = array(
		'alt'      => $alt,
		'decoding' => 'async',
	);

	if ( $args['class'] ) {
		$attrs['class'] = $args['class'];
	}

	/*
	 * fetchpriority and loading are opposites: the hero is the Largest
	 * Contentful Paint and must never be deferred, everything else must never
	 * compete with it.
	 */
	if ( $args['fetchpriority'] ) {
		$attrs['fetchpriority'] = $args['fetchpriority'];
	} else {
		$attrs['loading'] = $args['loading'];
	}

	if ( $args['sizes'] ) {
		$attrs['sizes'] = $args['sizes'];
	}

	if ( $id && 'attachment' === get_post_type( $id ) ) {
		return wp_get_attachment_image( $id, $args['size'], false, $attrs );
	}

	if ( ! $url ) {
		return '';
	}

	$out = '<img src="' . esc_url( $url ) . '"';
	foreach ( $attrs as $key => $value ) {
		$out .= ' ' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
	}

	return $out . '>';
}

/**
 * The attachment behind a URL, looked up at most once per request.
 *
 * attachment_url_to_postid runs a database query and does not cache, which on
 * a catalogue page is sixty queries for sixty cards. A static map costs
 * nothing and answers the repeats.
 *
 * @param string $url Image URL.
 * @return int Attachment ID, or 0.
 */
function mwp_attachment_id_for_url( $url ) {
	static $seen = array();

	$url = (string) $url;

	if ( isset( $seen[ $url ] ) ) {
		return $seen[ $url ];
	}

	// Only URLs on this site can be attachments; anything else is a wasted
	// query against a table with a row per image on the site.
	if ( 0 !== strpos( $url, content_url() ) && 0 !== strpos( $url, home_url() ) ) {
		$seen[ $url ] = 0;
		return 0;
	}

	// A sized file (…-768x512.jpg) does not match the stored original, so the
	// size suffix comes off before asking.
	$full = preg_replace( '/-\d+x\d+(?=\.[a-z]{3,4}$)/i', '', $url );

	$seen[ $url ] = (int) attachment_url_to_postid( $full );

	return $seen[ $url ];
}
