<?php
/**
 * Making the imported photographs weigh what they should.
 *
 * Measured on the live site: one package page shipped 1.9 MB, and 1.3 MB of
 * that was a single photograph — the hero, a 908×726 PNG, displayed in a
 * 535×427 box. A photograph stored as PNG is the expensive mistake here;
 * Travel Compositor serves what it serves, and the plugin was saving it
 * untouched.
 *
 * Two things are done on the way in, and both are reversible by turning the
 * filters off:
 *
 *  - an image wider than needed is resized once, on import, rather than being
 *    shipped whole to every visitor for the browser to shrink;
 *  - a PNG is re-encoded as WebP where the server can do it. WebP keeps
 *    transparency, so nothing can come out with a black box behind it, and it
 *    is the one conversion that is safe to make without looking at the
 *    picture. Where WebP is not available the file is left in its own format —
 *    a silent JPEG conversion would wreck any image with transparency.
 *
 * Nothing here touches a picture a person uploaded themselves: only
 * attachments carrying _mwp_source_url, which this plugin imported.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Images {

	/** Marks an attachment this class has already been through. */
	const DONE = '_mwp_optimised';

	/**
	 * The widest any imported photograph needs to be.
	 *
	 * The collage hero is the largest slot on the site and is never shown
	 * wider than about 900 CSS pixels; doubling that covers retina screens
	 * with room to spare.
	 *
	 * @return int
	 */
	public static function max_width() {
		return max( 600, (int) apply_filters( 'mwp_image_max_width', 1800 ) );
	}

	/**
	 * Resize and re-encode one imported attachment.
	 *
	 * @param int $attachment_id Attachment.
	 * @return array{changed:bool, before:int, after:int, note:string}
	 */
	public static function optimise( $attachment_id ) {
		$attachment_id = (int) $attachment_id;
		$none          = array( 'changed' => false, 'before' => 0, 'after' => 0, 'note' => '' );

		if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) {
			return $none;
		}

		if ( ! apply_filters( 'mwp_optimise_images', true, $attachment_id ) ) {
			return $none;
		}

		$file = get_attached_file( $attachment_id );

		if ( ! $file || ! file_exists( $file ) ) {
			return $none;
		}

		$before = (int) filesize( $file );

		require_once ABSPATH . 'wp-admin/includes/image.php';

		$editor = wp_get_image_editor( $file );

		if ( is_wp_error( $editor ) ) {
			return array_merge( $none, array( 'note' => $editor->get_error_message() ) );
		}

		$size = $editor->get_size();
		$mime = (string) get_post_mime_type( $attachment_id );
		$max  = self::max_width();

		$resize  = ! empty( $size['width'] ) && $size['width'] > $max;
		$convert = ( 'image/png' === $mime ) && $editor->supports_mime_type( 'image/webp' );

		if ( ! $resize && ! $convert ) {
			update_post_meta( $attachment_id, self::DONE, time() );
			return array_merge( $none, array( 'before' => $before, 'after' => $before ) );
		}

		if ( $resize ) {
			$editor->resize( $max, null, false );
		}

		$editor->set_quality( (int) apply_filters( 'mwp_image_quality', 82 ) );

		$saved = $editor->save( null, $convert ? 'image/webp' : $mime );

		if ( is_wp_error( $saved ) || empty( $saved['path'] ) ) {
			return array_merge(
				$none,
				array( 'before' => $before, 'note' => is_wp_error( $saved ) ? $saved->get_error_message() : 'save failed' )
			);
		}

		$after = file_exists( $saved['path'] ) ? (int) filesize( $saved['path'] ) : 0;

		/*
		 * A bigger file is a worse file. It happens — a small PNG of flat
		 * colour can grow as WebP — and when it does the new file is thrown
		 * away rather than kept out of momentum.
		 */
		if ( $after >= $before && $saved['path'] !== $file ) {
			wp_delete_file( $saved['path'] );
			update_post_meta( $attachment_id, self::DONE, time() );
			return array_merge( $none, array( 'before' => $before, 'after' => $before ) );
		}

		self::retire_old_files( $attachment_id, $file, $saved['path'] );

		update_attached_file( $attachment_id, $saved['path'] );

		if ( $convert ) {
			wp_update_post(
				array(
					'ID'             => $attachment_id,
					'post_mime_type' => $saved['mime-type'],
				)
			);
		}

		// Rebuild the thumbnails from the new original, which is what puts a
		// real srcset back in front of the browser.
		$meta = wp_generate_attachment_metadata( $attachment_id, $saved['path'] );
		if ( is_array( $meta ) ) {
			wp_update_attachment_metadata( $attachment_id, $meta );
		}

		update_post_meta( $attachment_id, self::DONE, time() );

		return array(
			'changed' => true,
			'before'  => $before,
			'after'   => $after,
			'note'    => '',
		);
	}

	/**
	 * Delete the files the new original replaces.
	 *
	 * The old intermediate sizes are the important part: left behind they are
	 * dead weight in the uploads folder, and a stale srcset entry can point at
	 * one. The old original goes too, but only when the new file genuinely is
	 * a different file — an in-place re-save must not delete its own output.
	 *
	 * @param int    $attachment_id Attachment.
	 * @param string $old_file      Previous original path.
	 * @param string $new_file      New original path.
	 * @return void
	 */
	protected static function retire_old_files( $attachment_id, $old_file, $new_file ) {
		$meta = wp_get_attachment_metadata( $attachment_id );
		$dir  = trailingslashit( dirname( $old_file ) );

		if ( is_array( $meta ) && ! empty( $meta['sizes'] ) ) {
			foreach ( $meta['sizes'] as $size ) {
				if ( empty( $size['file'] ) ) {
					continue;
				}
				$path = $dir . $size['file'];
				if ( $path !== $new_file && file_exists( $path ) ) {
					wp_delete_file( $path );
				}
			}
		}

		if ( $old_file !== $new_file && file_exists( $old_file ) ) {
			wp_delete_file( $old_file );
		}
	}

	/**
	 * Work through the images this plugin has imported, a batch at a time.
	 *
	 * Batched because re-encoding is the one genuinely slow thing here — a
	 * second or so per photograph — and a request that tries to do four
	 * hundred of them in one go meets the PHP time limit and reports nothing.
	 *
	 * @param int $limit How many to process.
	 * @return array{done:int, changed:int, saved:int, left:int}
	 */
	public static function optimise_batch( $limit = 25 ) {
		$ids = get_posts(
			array(
				'post_type'        => 'attachment',
				'post_status'      => 'inherit',
				'posts_per_page'   => (int) $limit,
				'fields'           => 'ids',
				'no_found_rows'    => false,
				'suppress_filters' => true,
				'lang'             => '',
				'meta_query'       => array(
					array(
						'key'     => '_mwp_source_url',
						'compare' => 'EXISTS',
					),
					array(
						'key'     => self::DONE,
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);

		$changed = 0;
		$saved   = 0;

		foreach ( $ids as $id ) {
			$result = self::optimise( $id );
			if ( ! empty( $result['changed'] ) ) {
				$changed++;
				$saved += max( 0, $result['before'] - $result['after'] );
			}
		}

		return array(
			'done'    => count( $ids ),
			'changed' => $changed,
			'saved'   => $saved,
			'left'    => self::remaining(),
		);
	}

	/**
	 * How many imported images have not been through this yet.
	 *
	 * @return int
	 */
	public static function remaining() {
		$q = new WP_Query(
			array(
				'post_type'        => 'attachment',
				'post_status'      => 'inherit',
				'posts_per_page'   => 1,
				'fields'           => 'ids',
				'suppress_filters' => true,
				'lang'             => '',
				'meta_query'       => array(
					array(
						'key'     => '_mwp_source_url',
						'compare' => 'EXISTS',
					),
					array(
						'key'     => self::DONE,
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);

		return (int) $q->found_posts;
	}
}
