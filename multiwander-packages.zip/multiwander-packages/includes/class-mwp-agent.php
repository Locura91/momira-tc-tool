<?php
/**
 * Travel-agent profile pages.
 *
 * Each travel agent is an ordinary WordPress user. Everything shown on their
 * public page — photo, headline, stats, bio, regions, contact — is stored on
 * that user account as simple fields they edit themselves on their own profile
 * screen. A page then carries the shortcode [multiwander_agent], is linked to
 * one agent, and the plugin renders the styled page from that agent's fields.
 *
 * Why the user account and not the page: a non-admin can only ever edit their
 * OWN profile in WordPress, so an agent can change their own page and no one
 * else's, and cannot touch the rest of the site. The design lives here in the
 * plugin, so agents never see or break any HTML, and a design change applies to
 * every agent at once.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Agent {

	/** User-meta prefix for every agent field. */
	const META = 'mwp_agent_';

	/** Page meta: which agent (user ID) a page shows. */
	const PAGE_META = '_mwp_agent_user';

	public static function init() {
		add_shortcode( 'multiwander_agent',      array( __CLASS__, 'render' ) );
		add_shortcode( 'multiwander_agent_card', array( __CLASS__, 'render_card' ) );
		add_shortcode( 'multiwander_agent_cta',  array( __CLASS__, 'render_cta' ) );

		// Fields on the user's own profile screen (and the admin's user-edit).
		add_action( 'show_user_profile', array( __CLASS__, 'profile_fields' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'profile_fields' ) );
		add_action( 'personal_options_update', array( __CLASS__, 'save_profile' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'save_profile' ) );

		// Admin picks which agent a page shows.
		add_action( 'add_meta_boxes_page', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_page', array( __CLASS__, 'save_page_link' ), 20 );

		// Hide password section on profile.php for travel agents / wappointment staff.
		add_action( 'admin_head', array( __CLASS__, 'hide_password_on_profile' ) );

		// Assets.
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'front_assets' ) );

		// The inline "send a quick message" form on the card / CTA — works
		// for logged-out visitors too (that's the _nopriv_ variant).
		add_action( 'wp_ajax_mwpa_send_inquiry', array( __CLASS__, 'handle_inquiry' ) );
		add_action( 'wp_ajax_nopriv_mwpa_send_inquiry', array( __CLASS__, 'handle_inquiry' ) );
	}

	// -----------------------------------------------------------------
	// Hide password fields on profile.php for agent roles
	// -----------------------------------------------------------------

	public static function hide_password_on_profile() {
		global $pagenow;
		if ( 'profile.php' !== $pagenow ) {
			return;
		}
		$user = wp_get_current_user();
		$is_agent = $user->has_cap( MWP_Agent_Kit::CAP )
			|| in_array( 'wappointment_staff', (array) $user->roles, true );
		if ( ! $is_agent ) {
			return;
		}
		// MWP_Agent_Kit::hide_password_fields() also fires — this is a fallback.
	}

	// -----------------------------------------------------------------
	// Field definitions
	// -----------------------------------------------------------------

	/**
	 * Plain text / textarea fields, in the order they appear on the form.
	 *
	 * @return array<string,array{label:string,type:string,help:string,default:string}>
	 */
	public static function fields() {
		return array(
			'headline'    => array(
				'label' => __( 'Headline', 'multiwander-packages' ),
				'type'  => 'text',
				'help'  => __( 'The blue line under your name, e.g. “Travel expert with years living in Spain, Portugal and Turkey”.', 'multiwander-packages' ),
			),
			'intro'       => array(
				'label' => __( 'Short intro', 'multiwander-packages' ),
				'type'  => 'textarea',
				'help'  => __( 'One or two sentences shown at the top, beside your photo.', 'multiwander-packages' ),
			),
			'stat1_num'   => array( 'label' => __( 'Stat 1 — number', 'multiwander-packages' ), 'type' => 'text', 'help' => __( 'e.g. 12+', 'multiwander-packages' ) ),
			'stat1_label' => array( 'label' => __( 'Stat 1 — label', 'multiwander-packages' ), 'type' => 'text', 'help' => __( 'e.g. Years of experience', 'multiwander-packages' ) ),
			'stat2_num'   => array( 'label' => __( 'Stat 2 — number', 'multiwander-packages' ), 'type' => 'text', 'help' => '' ),
			'stat2_label' => array( 'label' => __( 'Stat 2 — label', 'multiwander-packages' ), 'type' => 'text', 'help' => '' ),
			'stat3_num'   => array( 'label' => __( 'Stat 3 — number', 'multiwander-packages' ), 'type' => 'text', 'help' => '' ),
			'stat3_label' => array( 'label' => __( 'Stat 3 — label', 'multiwander-packages' ), 'type' => 'text', 'help' => '' ),
			'wap_id'      => array(
				'label' => __( 'Wappointment staff ID', 'multiwander-packages' ),
				'type'  => 'text',
				'help'  => __( 'Your staff ID number in Wappointment (a number, e.g. 1). Shows the live booking widget on your page.', 'multiwander-packages' ),
			),
			'cta_label'   => array(
				'label'   => __( 'Button text', 'multiwander-packages' ),
				'type'    => 'text',
				'help'    => __( 'The call-to-action button at the bottom of the page, e.g. “Contact Test Agent”.', 'multiwander-packages' ),
				'default' => __( 'Book a free consultation!', 'multiwander-packages' ),
			),
			'cta_url'     => array(
				'label' => __( 'Button link', 'multiwander-packages' ),
				'type'  => 'url',
				'help'  => __( 'Where the button goes — usually a mailto: link or booking page.', 'multiwander-packages' ),
			),
			'email'       => array( 'label' => __( 'Contact e-mail', 'multiwander-packages' ), 'type' => 'text', 'help' => '' ),
			'phone'       => array( 'label' => __( 'Phone', 'multiwander-packages' ), 'type' => 'text', 'help' => '' ),
			'whatsapp'    => array( 'label' => __( 'WhatsApp', 'multiwander-packages' ), 'type' => 'text', 'help' => __( 'Number or wa.me link.', 'multiwander-packages' ) ),
			'languages'   => array(
				'label' => __( 'Languages', 'multiwander-packages' ),
				'type'  => 'text',
				'help'  => __( 'Comma-separated, e.g. Polish, English, Spanish — shown as tags.', 'multiwander-packages' ),
			),
			// badge is admin-only — saved separately in save_profile()
			'facebook_url'  => array(
				'label' => __( 'Facebook URL', 'multiwander-packages' ),
				'type'  => 'url',
				'help'  => __( 'Your personal or agency Facebook page URL. Leave empty to hide the icon.', 'multiwander-packages' ),
			),
			'instagram_url' => array(
				'label' => __( 'Instagram URL', 'multiwander-packages' ),
				'type'  => 'url',
				'help'  => __( 'Your Instagram profile URL. Leave empty to hide the icon.', 'multiwander-packages' ),
			),
			'linkedin_url'  => array(
				'label' => __( 'LinkedIn URL', 'multiwander-packages' ),
				'type'  => 'url',
				'help'  => __( 'Your LinkedIn profile URL. Leave empty to hide the icon.', 'multiwander-packages' ),
			),
			'youtube_url'   => array(
				'label' => __( 'YouTube URL', 'multiwander-packages' ),
				'type'  => 'url',
				'help'  => __( 'Your YouTube channel URL. Leave empty to hide the icon.', 'multiwander-packages' ),
			),
		);
	}

	/**
	 * Rich-text (visual editor) fields — the agent formats these freely.
	 * Note: 'regions' was removed from here in v1.69.9 — regions are now stored
	 * as a JSON array (repeater) and rendered as tags. See render_regions_repeater().
	 *
	 * @return array<string,string> key => label
	 */
	public static function rich_fields() {
		return array(
			'bio' => __( 'About me', 'multiwander-packages' ),
		);
	}

	// -----------------------------------------------------------------
	// Front-end language (Polish by default, English on /en/ URLs)
	// -----------------------------------------------------------------

	/**
	 * Is the current front-end request an English page? True when the URL
	 * path has an "/en/" segment (e.g. multiwander.com/en/dominikana/).
	 * Polish is the default for every other URL.
	 *
	 * @return bool
	 */
	public static function is_en_request() {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = '/' . trim( (string) strtok( $uri, '?' ), '/' ) . '/';
		return false !== strpos( $path, '/en/' );
	}

	/**
	 * Pick the Polish or English wording for a front-end string, based on the
	 * current URL. Used for the visitor-facing chrome the plugin renders
	 * itself (buttons, form labels, helper text) so the Polish site reads in
	 * Polish and the /en/ site reads in English, without depending on a
	 * translation file being present.
	 *
	 * @param string $pl Polish text (the default).
	 * @param string $en English text (shown only on /en/ URLs).
	 * @return string
	 */
	public static function t( $pl, $en ) {
		return self::is_en_request() ? $en : $pl;
	}

	// -----------------------------------------------------------------
	// Profile screen
	// -----------------------------------------------------------------

	/**
	 * A plain, reassuring "your changes are being reviewed" banner, shown
	 * to the AGENT themselves (not the admin — that's MWP_Agent_Kit's own
	 * render_pending_notice()) whenever they have unapproved edits sitting
	 * in the queue. Deliberately doesn't itemise every field — someone with
	 * no coding background mainly wants to know "did my save work?", and a
	 * long technical list would just be noise.
	 *
	 * @param int $uid Agent user ID.
	 * @return void
	 */
	protected static function render_pending_notice_for_self( $uid ) {
		if ( ! class_exists( 'MWP_Agent_Kit' ) ) {
			return;
		}
		$pending_json = (string) get_user_meta( $uid, MWP_Agent_Kit::PENDING_META, true );
		if ( ! $pending_json ) {
			return;
		}
		$pending = json_decode( $pending_json, true );
		if ( ! is_array( $pending ) || empty( $pending ) ) {
			return;
		}
		?>
		<div class="mwpa-self-pending">
			⏳ <?php esc_html_e( "You have changes waiting for admin approval. They'll appear on your public page as soon as they're reviewed.", 'multiwander-packages' ); ?>
		</div>
		<?php
	}

	/**
	 * Render the agent fields on a user profile screen.
	 *
	 * Layout: modern cards grouped by topic so non-developers feel at home.
	 * The HTML tab is removed from rich-text editors (quicktags:false) so
	 * agents never see raw code. The badge field — and anything else an
	 * agent should not touch — stays inside the `$is_admin` block further
	 * down; everything outside it is fair game for the agent themselves.
	 *
	 * Shown to: an admin editing anyone (from user-edit.php), and an agent
	 * viewing their OWN profile.php — their one guaranteed-reachable admin
	 * screen (a separate Role Guard plugin on this site restricts which
	 * admin pages some roles — Wappointment Staff among them — can open at
	 * all, and profile.php is always exempt from that). An agent's save
	 * here does NOT go live immediately — see save_profile() — it queues
	 * for admin approval exactly like the Agent Kit page does, so having
	 * two places to edit from never reopens the approval-bypass this whole
	 * workflow exists to close.
	 *
	 * @param WP_User $user The user being edited.
	 * @return void
	 */
	public static function profile_fields( $user ) {
		$is_admin = current_user_can( 'edit_users' );
		$is_self_agent = ! $is_admin
			&& get_current_user_id() === $user->ID
			&& class_exists( 'MWP_Agent_Kit' )
			&& ( $user->has_cap( MWP_Agent_Kit::CAP ) || in_array( 'wappointment_staff', (array) $user->roles, true ) );

		if ( ! $is_admin && ! $is_self_agent ) {
			return;
		}

		wp_nonce_field( 'mwp_agent_profile_' . $user->ID, 'mwp_agent_nonce' );

		if ( $is_self_agent ) {
			self::render_pending_notice_for_self( $user->ID );
		}

		$get = function ( $key, $default = '' ) use ( $user ) {
			$v = get_user_meta( $user->ID, self::META . $key, true );
			return '' !== $v ? $v : $default;
		};

		/**
		 * Render a single labelled input or textarea.
		 *
		 * @param string $key        Field key (without the META prefix).
		 * @param string $label      Visible label.
		 * @param string $type       'text' | 'url' | 'textarea'
		 * @param string $help       Optional help text shown below the input.
		 * @param string $default    Default value.
		 * @param string $placeholder Input placeholder.
		 */
		$f = function ( $key, $label, $type = 'text', $help = '', $default = '', $placeholder = '' ) use ( $get ) {
			$val  = $get( $key, $default );
			$name = self::META . $key;
			$id   = 'mwp_agent_' . $key;
			?>
			<div class="mwpa-f">
				<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
				<?php if ( 'textarea' === $type ) : ?>
					<textarea id="<?php echo esc_attr( $id ); ?>"
						name="<?php echo esc_attr( $name ); ?>"
						rows="3"
						placeholder="<?php echo esc_attr( $placeholder ); ?>"><?php echo esc_textarea( $val ); ?></textarea>
				<?php else : ?>
					<input type="<?php echo esc_attr( 'url' === $type ? 'url' : 'text' ); ?>"
						id="<?php echo esc_attr( $id ); ?>"
						name="<?php echo esc_attr( $name ); ?>"
						value="<?php echo esc_attr( $val ); ?>"
						placeholder="<?php echo esc_attr( $placeholder ); ?>">
				<?php endif; ?>
				<?php if ( $help ) : ?>
					<p class="mwpa-help"><?php echo esc_html( $help ); ?></p>
				<?php endif; ?>
			</div>
			<?php
		};

		$photo_id  = (int) $get( 'photo_id' );
		$photo_src = $photo_id ? wp_get_attachment_image_url( $photo_id, 'medium' ) : '';
		?>

		<div class="mwpa-admin-wrap">

			<!-- ── Header ──────────────────────────────────────────── -->
			<div class="mwpa-admin-header">
				<div class="mwpa-admin-header-icon">✈</div>
				<div>
					<h2><?php esc_html_e( 'Travel agent profile', 'multiwander-packages' ); ?></h2>
					<p><?php esc_html_e( 'Your public page on MultiWander. Fill in what you like — anything left empty is simply hidden.', 'multiwander-packages' ); ?></p>
				</div>
				<?php
				$mwpa_live_url = class_exists( 'MWP_Agent_Kit' ) ? MWP_Agent_Kit::agent_public_url( $user->ID ) : '';
				if ( $mwpa_live_url ) :
					?>
					<a class="mwpa-admin-header-live-link" href="<?php echo esc_url( $mwpa_live_url ); ?>" target="_blank" rel="noopener">
						<?php esc_html_e( 'View my live page ↗', 'multiwander-packages' ); ?>
					</a>
				<?php endif; ?>
				<label class="mwpa-admin-live-toggle">
					<input type="checkbox" name="<?php echo esc_attr( self::META ); ?>enabled" value="1" <?php checked( $get( 'enabled' ), '1' ); ?>>
					<?php esc_html_e( 'Page live', 'multiwander-packages' ); ?>
				</label>
			</div>

			<!-- ── Photo & Basics ──────────────────────────────────── -->
			<div class="mwpa-admin-card">
				<div class="mwpa-admin-card-title">👤 <?php esc_html_e( 'Photo & Basics', 'multiwander-packages' ); ?></div>
				<div class="mwpa-admin-photo-row">
					<div class="mwpa-admin-photo-col">
						<div class="mwp-agent-photo-field">
							<img src="<?php echo esc_url( $photo_src ); ?>"
								class="mwp-agent-photo-preview" alt=""
								style="<?php echo $photo_src ? '' : 'display:none;'; ?>">
							<input type="hidden"
								name="<?php echo esc_attr( self::META ); ?>photo_id"
								value="<?php echo esc_attr( $photo_id ); ?>"
								class="mwp-agent-photo-id">
							<button type="button" class="button mwp-agent-photo-pick">
								<?php esc_html_e( 'Choose / upload photo', 'multiwander-packages' ); ?>
							</button>
							<button type="button" class="button-link mwp-agent-photo-clear"
								style="margin-left:8px;color:#b32d2e;<?php echo $photo_id ? '' : 'display:none;'; ?>">
								<?php esc_html_e( 'Remove', 'multiwander-packages' ); ?>
							</button>
						</div>
					</div>
					<div class="mwpa-admin-photo-fields">
						<?php $f( 'headline', __( 'Headline', 'multiwander-packages' ), 'text',
							__( 'The blue line under your name.', 'multiwander-packages' ), '',
							__( 'e.g. Travel expert specialising in Spain and Turkey', 'multiwander-packages' ) ); ?>
						<?php $f( 'intro', __( 'Short intro', 'multiwander-packages' ), 'textarea',
							__( 'One or two sentences shown beside your photo.', 'multiwander-packages' ) ); ?>

						<!-- Gender (used for the country-page expert heading) -->
						<div class="mwpa-f">
							<label><?php esc_html_e( 'Grammatical gender', 'multiwander-packages' ); ?></label>
							<div style="display:flex;gap:24px;margin-top:4px;">
								<label style="font-weight:normal;cursor:pointer">
									<input type="radio" name="<?php echo esc_attr( self::META ); ?>gender" value="m" <?php checked( $get( 'gender', 'm' ), 'm' ); ?>>
									<?php esc_html_e( 'Male (ekspert)', 'multiwander-packages' ); ?>
								</label>
								<label style="font-weight:normal;cursor:pointer">
									<input type="radio" name="<?php echo esc_attr( self::META ); ?>gender" value="f" <?php checked( $get( 'gender', 'm' ), 'f' ); ?>>
									<?php esc_html_e( 'Female (ekspertka)', 'multiwander-packages' ); ?>
								</label>
							</div>
							<p class="mwpa-help"><?php esc_html_e( 'Used on country pages in "Meet our expert on …" — pick whichever form of the word applies to you.', 'multiwander-packages' ); ?></p>
						</div>

						<?php
						// Languages repeater: name + proficiency level.
						$lang_rows = self::parse_languages( (string) $get( 'languages' ) );
						if ( empty( $lang_rows ) ) { $lang_rows = array( array( 'name' => '', 'level' => '' ) ); }
						$lang_list_id = 'mwpa-profile-langs-list-' . $user->ID;
						?>
						<div class="mwpa-f">
							<label><?php esc_html_e( 'Languages', 'multiwander-packages' ); ?></label>
							<p class="mwpa-help" style="margin:2px 0 8px"><?php esc_html_e( 'One language per row, with a proficiency level.', 'multiwander-packages' ); ?></p>
							<div class="mwpa-langs-list" id="<?php echo esc_attr( $lang_list_id ); ?>">
								<?php foreach ( $lang_rows as $lrow ) :
									$lname  = isset( $lrow['name'] ) ? $lrow['name'] : '';
									$llevel = isset( $lrow['level'] ) ? $lrow['level'] : '';
								?>
								<div class="mwpa-lang-row">
									<input type="text" class="mwpa-lang-f-name"
										name="<?php echo esc_attr( self::META ); ?>languages_name[]"
										value="<?php echo esc_attr( $lname ); ?>"
										placeholder="<?php esc_attr_e( 'e.g. Polski', 'multiwander-packages' ); ?>">
									<select class="mwpa-lang-f-level" name="<?php echo esc_attr( self::META ); ?>languages_level[]">
										<option value=""><?php esc_html_e( '— poziom —', 'multiwander-packages' ); ?></option>
										<?php if ( $llevel && ! in_array( $llevel, self::language_levels(), true ) ) : ?>
											<option value="<?php echo esc_attr( $llevel ); ?>" selected><?php echo esc_html( $llevel ); ?></option>
										<?php endif; ?>
										<?php foreach ( self::language_levels() as $lvl ) : ?>
											<option value="<?php echo esc_attr( $lvl ); ?>" <?php selected( $llevel, $lvl ); ?>><?php echo esc_html( $lvl ); ?></option>
										<?php endforeach; ?>
									</select>
									<button type="button" class="mwpa-lang-remove button-link" title="<?php esc_attr_e( 'Remove', 'multiwander-packages' ); ?>">✕</button>
								</div>
								<?php endforeach; ?>
							</div>
							<button type="button" class="mwpa-lang-add button" data-list="<?php echo esc_attr( $lang_list_id ); ?>">
								➕ <?php esc_html_e( 'Add language', 'multiwander-packages' ); ?>
							</button>
						</div>
					</div>
				</div>
			</div>

			<!-- ── Stats ───────────────────────────────────────────── -->
			<div class="mwpa-admin-card">
				<div class="mwpa-admin-card-title">📊 <?php esc_html_e( 'Stats', 'multiwander-packages' ); ?></div>
				<div class="mwpa-admin-stats-grid">
					<?php for ( $i = 1; $i <= 3; $i++ ) : ?>
						<div class="mwpa-admin-stat-pair">
							<?php $f( 'stat' . $i . '_num',   __( 'Number', 'multiwander-packages' ), 'text', '', '', '12+' ); ?>
							<?php $f( 'stat' . $i . '_label', __( 'Label', 'multiwander-packages' ),  'text', '', '', __( 'Years of experience', 'multiwander-packages' ) ); ?>
						</div>
					<?php endfor; ?>
				</div>
			</div>

			<!-- ── Contact & Booking + Social Media ───────────────── -->
			<div class="mwpa-admin-card">
				<div class="mwpa-admin-card-title">📬 <?php esc_html_e( 'Contact, Booking & Social Media', 'multiwander-packages' ); ?></div>

				<p class="mwpa-admin-card-subtitle"><?php esc_html_e( 'Contact & Booking', 'multiwander-packages' ); ?></p>
				<div class="mwpa-admin-two-col" style="margin-bottom:18px">
					<?php $f( 'email',    __( 'E-mail', 'multiwander-packages' ),    'text', '', '', 'name@example.com' ); ?>
					<?php $f( 'phone',    __( 'Phone', 'multiwander-packages' ),     'text', '', '', '+48 000 000 000' ); ?>
					<?php $f( 'whatsapp', __( 'WhatsApp', 'multiwander-packages' ),  'text',
						__( 'Number or wa.me link.', 'multiwander-packages' ) ); ?>
					<?php $f( 'wap_id',   __( 'Wappointment staff ID', 'multiwander-packages' ), 'text',
						__( 'Your staff ID number in Wappointment — shows the live booking widget.', 'multiwander-packages' ) ); ?>
					<?php $f( 'cta_label', __( 'Button text', 'multiwander-packages' ), 'text', '',
						__( 'Book a free consultation!', 'multiwander-packages' ) ); ?>
					<?php $f( 'cta_url', __( 'Button link', 'multiwander-packages' ), 'url',
						__( 'Where the button goes — usually a mailto: link or booking page.', 'multiwander-packages' ), '',
						'mailto:you@example.com' ); ?>
				</div>

				<p class="mwpa-admin-card-subtitle">📱 <?php esc_html_e( 'Social Media', 'multiwander-packages' ); ?></p>
				<p class="mwpa-help" style="margin:-6px 0 12px">
					<?php esc_html_e( 'Leave any field empty and that icon will not appear on your page.', 'multiwander-packages' ); ?>
				</p>
				<div class="mwpa-admin-two-col">
					<?php $f( 'facebook_url',  'Facebook',  'url', '', '', 'https://facebook.com/yourpage' ); ?>
					<?php $f( 'instagram_url', 'Instagram', 'url', '', '', 'https://instagram.com/yourprofile' ); ?>
					<?php $f( 'linkedin_url',  'LinkedIn',  'url', '', '', 'https://linkedin.com/in/yourname' ); ?>
					<?php $f( 'youtube_url',   'YouTube',   'url', '', '', 'https://youtube.com/@yourchannel' ); ?>
				</div>
			</div>

			<!-- ── Rich text: About me ──────────────────────────────── -->
			<?php
			$rich_icons = array(
				'bio' => '📖',
			);
			foreach ( self::rich_fields() as $key => $label ) :
				$icon = isset( $rich_icons[ $key ] ) ? $rich_icons[ $key ] . ' ' : '';
				?>
				<div class="mwpa-admin-card">
					<div class="mwpa-admin-card-title"><?php echo esc_html( $icon . $label ); ?></div>
					<?php
					wp_editor(
						(string) $get( $key ),
						'mwp_agent_' . $key,
						array(
							'textarea_name' => self::META . $key,
							'textarea_rows' => 10,
							'media_buttons' => false,
							'teeny'         => false,
							'quicktags'     => false,
						)
					);
					?>
				</div>
			<?php endforeach; ?>

			<!-- ── Travel style (repeater, max 3, one line each) ────── -->
			<?php
			$style_raw  = (string) $get( 'style' );
			$style_list = json_decode( $style_raw, true );
			if ( ! is_array( $style_list ) ) {
				$legacy     = trim( wp_strip_all_tags( $style_raw ) );
				$style_list = ( '' !== $legacy ) ? array( $legacy ) : array();
			}
			if ( empty( $style_list ) ) {
				$style_list = array( '' );
			}
			$style_list_id = 'mwpa-profile-style-list-' . $user->ID;
			?>
			<div class="mwpa-admin-card">
				<div class="mwpa-admin-card-title">🧭 <?php esc_html_e( 'My travel style', 'multiwander-packages' ); ?></div>
				<p class="mwpa-help" style="margin-bottom:12px">
					<?php esc_html_e( 'Up to three, one short line each — these show as tags on the profile, not a paragraph. Start typing for some ideas.', 'multiwander-packages' ); ?>
				</p>
				<datalist id="mwpa-style-options-<?php echo absint( $user->ID ); ?>">
					<?php foreach ( self::travel_style_options() as $opt ) : ?>
						<option value="<?php echo esc_attr( $opt ); ?>"></option>
					<?php endforeach; ?>
				</datalist>
				<div class="mwpa-style-list" id="<?php echo esc_attr( $style_list_id ); ?>" data-max="3">
					<?php foreach ( $style_list as $one ) : ?>
						<div class="mwpa-style-row">
							<input type="text" class="mwpa-style-f-name" list="mwpa-style-options-<?php echo absint( $user->ID ); ?>"
								name="<?php echo esc_attr( self::META ); ?>style[]"
								value="<?php echo esc_attr( $one ); ?>"
								maxlength="60"
								placeholder="<?php esc_attr_e( 'e.g. Luksusowe podróże', 'multiwander-packages' ); ?>">
							<button type="button" class="mwpa-style-remove button-link" title="<?php esc_attr_e( 'Remove', 'multiwander-packages' ); ?>">✕</button>
						</div>
					<?php endforeach; ?>
				</div>
				<button type="button" class="mwpa-style-add button" data-list="<?php echo esc_attr( $style_list_id ); ?>" data-datalist="mwpa-style-options-<?php echo absint( $user->ID ); ?>" data-name="<?php echo esc_attr( self::META ); ?>style[]">
					➕ <?php esc_html_e( 'Add travel style', 'multiwander-packages' ); ?>
				</button>
			</div>

			<!-- ── Regions of expertise (repeater) ─────────────────── -->
			<?php
			$regions_json = $get( 'regions' );
			$regions_arr  = array();
			if ( $regions_json ) {
				$decoded = json_decode( $regions_json, true );
				if ( is_array( $decoded ) ) {
					$regions_arr = $decoded;
				}
			}
			$region_list_id = 'mwpa-profile-regions-list-' . $user->ID;
			?>
			<div class="mwpa-admin-card">
				<div class="mwpa-admin-card-title">🌍 <?php esc_html_e( 'Regions of expertise', 'multiwander-packages' ); ?></div>
				<p class="mwpa-help" style="margin-bottom:12px">
					<?php esc_html_e( 'One country or region per card. Type a country name under Flags and press Enter to add it — add as many as you like, one at a time. Flags also appear automatically from the region name if you leave that field empty. Add a subtitle, a short description and comma-separated tags to match the full card style.', 'multiwander-packages' ); ?>
				</p>
				<div class="mwpa-regions-list" id="<?php echo esc_attr( $region_list_id ); ?>">
					<?php
					// Normalise: old entries may be plain strings; new ones are {name,note} objects.
					$region_rows = ! empty( $regions_arr ) ? $regions_arr : array( array() );
					foreach ( $region_rows as $entry ) :
						if ( is_string( $entry ) ) {
							$rname = $entry; $rnote = ''; $rsub = ''; $rcountries = ''; $rtags = '';
						} else {
							$rname      = isset( $entry['name'] ) ? $entry['name'] : '';
							$rnote      = isset( $entry['note'] ) ? $entry['note'] : '';
							$rsub       = isset( $entry['subtitle'] ) ? $entry['subtitle'] : '';
							$rcountries = isset( $entry['countries'] ) ? $entry['countries'] : '';
							$rtags_raw  = isset( $entry['tags'] ) ? $entry['tags'] : '';
							$rtags      = is_array( $rtags_raw ) ? implode( ', ', $rtags_raw ) : (string) $rtags_raw;
						}
					?>
						<div class="mwpa-region-row">
							<div class="mwpa-region-fields">
								<input type="text" class="mwpa-region-f-name"
									name="<?php echo esc_attr( self::META ); ?>regions_name[]"
									value="<?php echo esc_attr( $rname ); ?>"
									placeholder="<?php esc_attr_e( 'Region — e.g. Hiszpania i Portugalia', 'multiwander-packages' ); ?>">
								<div class="mwpa-region-f-two">
									<input type="text" class="mwpa-region-f-subtitle"
										name="<?php echo esc_attr( self::META ); ?>regions_subtitle[]"
										value="<?php echo esc_attr( $rsub ); ?>"
										placeholder="<?php esc_attr_e( 'Subtitle — e.g. Osobiste Doświadczenie Życia', 'multiwander-packages' ); ?>">
									<input type="text" class="mwpa-region-f-countries"
										name="<?php echo esc_attr( self::META ); ?>regions_countries[]"
										value="<?php echo esc_attr( $rcountries ); ?>"
										placeholder="<?php esc_attr_e( 'Type a country, press Enter…', 'multiwander-packages' ); ?>">
								</div>
								<textarea class="mwpa-region-f-note" rows="2"
									name="<?php echo esc_attr( self::META ); ?>regions_note[]"
									placeholder="<?php esc_attr_e( 'Short description of your experience there', 'multiwander-packages' ); ?>"><?php echo esc_textarea( $rnote ); ?></textarea>
								<input type="text" class="mwpa-region-f-tags"
									name="<?php echo esc_attr( self::META ); ?>regions_tags[]"
									value="<?php echo esc_attr( $rtags ); ?>"
									placeholder="<?php esc_attr_e( 'Tags, comma-separated — e.g. Życie w Lizbonie, Wyspy Kanaryjskie', 'multiwander-packages' ); ?>">
							</div>
							<button type="button" class="mwpa-region-remove button-link" title="<?php esc_attr_e( 'Remove', 'multiwander-packages' ); ?>">✕</button>
						</div>
						<?php endforeach; ?>
				</div>
				<button type="button" class="mwpa-region-add button"
					data-list="<?php echo esc_attr( $region_list_id ); ?>">
					➕ <?php esc_html_e( 'Add region', 'multiwander-packages' ); ?>
				</button>
			</div>

			<!-- ── Admin-only settings ─────────────────────────────── -->
			<?php if ( $is_admin ) : ?>
			<div class="mwpa-admin-card mwpa-admin-card--admin">
				<div class="mwpa-admin-card-title">🔒 <?php esc_html_e( 'Admin Settings', 'multiwander-packages' ); ?></div>
				<p class="mwpa-help" style="margin-bottom:14px">
					<?php esc_html_e( 'Only admins can see and edit this section.', 'multiwander-packages' ); ?>
				</p>

				<!-- User ID (read-only, for shortcode reference) -->
				<div class="mwpa-f" style="margin-bottom:18px">
					<label><?php esc_html_e( 'WordPress User ID', 'multiwander-packages' ); ?></label>
					<code style="display:inline-block;background:#f3f4f6;border:1px solid #d0d5dd;border-radius:6px;padding:5px 12px;font-size:1.1rem;font-weight:700;color:#1a2e4a;letter-spacing:.04em;"><?php echo absint( $user->ID ); ?></code>
					<p class="mwpa-help"><?php esc_html_e( 'Use this in the shortcode: [multiwander_agent user="…"]', 'multiwander-packages' ); ?></p>
				</div>

				<?php
				// Deliberately empty by default — agents earn this badge, it
				// is never auto-filled. $default stays '' so the field is
				// genuinely blank until an admin types something in; the
				// example text is only a placeholder hint (6th arg).
				$f( 'badge', __( 'Badge text', 'multiwander-packages' ), 'text',
					__( 'The pink pill at the very top — set by admins only. Leave empty until they\'ve earned it.', 'multiwander-packages' ),
					'',
					__( 'e.g. Certified MultiWander Travel Expert', 'multiwander-packages' ) );
				?>
			</div>
			<?php endif; ?>

		</div><!-- .mwpa-admin-wrap -->
		<?php
	}

	/**
	 * Persist the agent fields from a profile save.
	 *
	 * @param int $user_id User being saved.
	 * @return void
	 */
	public static function save_profile( $user_id ) {
		if ( ! isset( $_POST['mwp_agent_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mwp_agent_nonce'] ) ), 'mwp_agent_profile_' . $user_id ) ) {
			return;
		}
		if ( get_current_user_id() !== (int) $user_id && ! current_user_can( 'edit_users' ) ) {
			return;
		}

		// A visibility kill-switch, not public content — saved immediately
		// either way, matching the Agent Kit page's own handle_save().
		update_user_meta( $user_id, self::META . 'enabled', isset( $_POST[ self::META . 'enabled' ] ) ? '1' : '' );

		if ( current_user_can( 'edit_users' ) ) {
			// An admin editing a user from user-edit.php: everything else
			// saves live, same as always.
			self::save_profile_fields_live( $user_id );
		} else {
			// The agent editing their OWN profile.php: nothing below goes
			// live until an admin approves it — exactly like the Agent Kit
			// page — merged into the SAME pending queue (MWP_Agent_Kit::
			// PENDING_META) so it makes no difference which of the two
			// screens they used.
			self::save_profile_fields_pending( $user_id );
		}
	}

	/**
	 * Admin path: every field saves straight to the live meta. Used only
	 * when an admin is editing a user from user-edit.php — an admin's own
	 * edits don't need their own approval.
	 *
	 * @param int $user_id
	 * @return void
	 */
	protected static function save_profile_fields_live( $user_id ) {
		update_user_meta( $user_id, self::META . 'photo_id', isset( $_POST[ self::META . 'photo_id' ] ) ? (int) $_POST[ self::META . 'photo_id' ] : 0 );

		$gender_raw = isset( $_POST[ self::META . 'gender' ] ) ? sanitize_key( $_POST[ self::META . 'gender' ] ) : 'm';
		update_user_meta( $user_id, self::META . 'gender', in_array( $gender_raw, array( 'm', 'f' ), true ) ? $gender_raw : 'm' );

		foreach ( self::fields() as $key => $f ) {
			$raw = isset( $_POST[ self::META . $key ] ) ? wp_unslash( $_POST[ self::META . $key ] ) : '';
			if ( 'url' === $f['type'] ) {
				$clean = esc_url_raw( $raw );
			} elseif ( 'textarea' === $f['type'] ) {
				$clean = sanitize_textarea_field( $raw );
			} else {
				$clean = sanitize_text_field( $raw );
			}
			update_user_meta( $user_id, self::META . $key, $clean );
		}

		// Badge is admin-only — this whole method only ever runs for an
		// admin, but keep the explicit check anyway as a second guard.
		if ( current_user_can( 'edit_users' ) && isset( $_POST[ self::META . 'badge' ] ) ) {
			update_user_meta( $user_id, self::META . 'badge', sanitize_text_field( wp_unslash( $_POST[ self::META . 'badge' ] ) ) );
		}

		foreach ( array_keys( self::rich_fields() ) as $key ) {
			$raw = isset( $_POST[ self::META . $key ] ) ? wp_unslash( $_POST[ self::META . $key ] ) : '';
			update_user_meta( $user_id, self::META . $key, wp_kses_post( $raw ) );
		}

		// Travel style: saved as a JSON array of up to three short, one-line entries.
		update_user_meta( $user_id, self::META . 'style', wp_json_encode( self::parse_travel_styles_from_post( self::META ), JSON_UNESCAPED_UNICODE ) );

		// Regions of expertise: saved as JSON array of rich {name, subtitle, countries, note, tags} objects.
		$regions = self::parse_regions_from_post( self::META );
		update_user_meta( $user_id, self::META . 'regions', wp_json_encode( $regions, JSON_UNESCAPED_UNICODE ) );

		// Languages: saved as JSON array of { name, level } objects.
		update_user_meta( $user_id, self::META . 'languages', wp_json_encode( self::parse_languages_from_post( self::META ), JSON_UNESCAPED_UNICODE ) );
	}

	/**
	 * Agent path: the exact same fields, but queued into
	 * MWP_Agent_Kit::PENDING_META for admin review instead of saved live —
	 * mirrors MWP_Agent_Kit::handle_save() field-for-field so the pending
	 * blob has the identical shape regardless of which screen produced it,
	 * and handle_approve() / render_pending_notice() need no changes to
	 * cope with either source.
	 *
	 * @param int $user_id
	 * @return void
	 */
	protected static function save_profile_fields_pending( $user_id ) {
		if ( ! class_exists( 'MWP_Agent_Kit' ) ) {
			return; // Shouldn't happen — Agent Kit is required for the approval queue to mean anything.
		}

		$pending = array();

		$pending['photo_id'] = isset( $_POST[ self::META . 'photo_id' ] ) ? (int) $_POST[ self::META . 'photo_id' ] : 0;

		$gender_raw = isset( $_POST[ self::META . 'gender' ] ) ? sanitize_key( $_POST[ self::META . 'gender' ] ) : 'm';
		$pending['gender'] = in_array( $gender_raw, array( 'm', 'f' ), true ) ? $gender_raw : 'm';

		foreach ( self::fields() as $key => $f ) {
			$raw = isset( $_POST[ self::META . $key ] ) ? wp_unslash( $_POST[ self::META . $key ] ) : '';
			if ( 'url' === $f['type'] ) {
				$pending[ $key ] = esc_url_raw( $raw );
			} elseif ( 'textarea' === $f['type'] ) {
				$pending[ $key ] = sanitize_textarea_field( $raw );
			} else {
				$pending[ $key ] = sanitize_text_field( $raw );
			}
		}

		// No badge here — it's admin-only and never shown to an agent in
		// the first place, so there's nothing in $_POST to pick up.

		foreach ( array_keys( self::rich_fields() ) as $key ) {
			$raw = isset( $_POST[ self::META . $key ] ) ? wp_unslash( $_POST[ self::META . $key ] ) : '';
			$pending[ $key ] = wp_kses_post( $raw );
		}

		$pending['style']     = wp_json_encode( self::parse_travel_styles_from_post( self::META ), JSON_UNESCAPED_UNICODE );
		$pending['regions']   = wp_json_encode( self::parse_regions_from_post( self::META ), JSON_UNESCAPED_UNICODE );
		$pending['languages'] = wp_json_encode( self::parse_languages_from_post( self::META ), JSON_UNESCAPED_UNICODE );

		$existing_pending = json_decode( (string) get_user_meta( $user_id, MWP_Agent_Kit::PENDING_META, true ), true );
		if ( ! is_array( $existing_pending ) ) {
			$existing_pending = array();
		}
		$pending_merged = array_merge( $existing_pending, $pending );
		update_user_meta( $user_id, MWP_Agent_Kit::PENDING_META, wp_json_encode( $pending_merged ) );

		MWP_Agent_Kit::notify_admin( $user_id );
	}

	// -----------------------------------------------------------------
	// Page ↔ agent link (meta box)
	// -----------------------------------------------------------------

	public static function add_meta_box() {
		add_meta_box(
			'mwp-agent-link',
			__( 'Travel agent profile', 'multiwander-packages' ),
			array( __CLASS__, 'render_meta_box' ),
			'page',
			'side'
		);
	}

	/**
	 * @param WP_Post $post Current page.
	 * @return void
	 */
	public static function render_meta_box( $post ) {
		wp_nonce_field( 'mwp_agent_page_' . $post->ID, 'mwp_agent_page_nonce' );
		$current = (int) get_post_meta( $post->ID, self::PAGE_META, true );

		$agents = get_users(
			array(
				'meta_key'   => self::META . 'enabled', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value' => '1',                    // phpcs:ignore WordPress.DB.SlowDBQuery
				'orderby'    => 'display_name',
				'order'      => 'ASC',
			)
		);
		?>
		<p><?php esc_html_e( 'Show a travel agent on this page:', 'multiwander-packages' ); ?></p>
		<select name="mwp_agent_user" style="width:100%">
			<option value="0"><?php esc_html_e( '— none —', 'multiwander-packages' ); ?></option>
			<?php foreach ( $agents as $a ) : ?>
				<option value="<?php echo esc_attr( $a->ID ); ?>" <?php selected( $current, $a->ID ); ?>>
					<?php echo esc_html( $a->display_name ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<p class="description" style="margin-top:8px">
			<?php
			printf(
				/* translators: %s: the shortcode */
				esc_html__( 'Then add %s to the page content where the profile should appear. Agents with no page here can be chosen once they tick “Enable my travel-agent page” on their profile.', 'multiwander-packages' ),
				'<code>[multiwander_agent]</code>'
			);
			?>
		</p>
		<?php
	}

	/**
	 * @param int $post_id Page being saved.
	 * @return void
	 */
	public static function save_page_link( $post_id ) {
		if ( ! isset( $_POST['mwp_agent_page_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mwp_agent_page_nonce'] ) ), 'mwp_agent_page_' . $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$uid = isset( $_POST['mwp_agent_user'] ) ? (int) $_POST['mwp_agent_user'] : 0;
		if ( $uid > 0 ) {
			update_post_meta( $post_id, self::PAGE_META, $uid );
		} else {
			delete_post_meta( $post_id, self::PAGE_META );
		}
	}

	// -----------------------------------------------------------------
	// Assets
	// -----------------------------------------------------------------

	/**
	 * @param string $hook Current admin screen.
	 * @return void
	 */
	public static function admin_assets( $hook ) {
		if ( ! in_array( $hook, array( 'profile.php', 'user-edit.php' ), true ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style(
			'mwp-agent-admin',
			MWP_URL . 'assets/agent-admin.css',
			array(),
			MWPP_asset_version( 'assets/agent-admin.css' )
		);
		// agent-admin.js handles both the photo picker and the regions repeater.
		wp_enqueue_script(
			'mwp-agent-admin',
			MWP_URL . 'assets/agent-admin.js',
			array(),
			MWPP_asset_version( 'assets/agent-admin.js' ),
			true
		);
	}

	public static function front_assets() {
		if ( ! is_singular() ) {
			return;
		}
		$post = get_post();
		if ( ! $post ) {
			return;
		}
		$has = has_shortcode( (string) $post->post_content, 'multiwander_agent' )
			|| has_shortcode( (string) $post->post_content, 'multiwander_agent_card' )
			|| has_shortcode( (string) $post->post_content, 'multiwander_agent_cta' )
			|| get_post_meta( $post->ID, self::PAGE_META, true );
		if ( ! $has ) {
			return;
		}
		wp_enqueue_style(
			'mwp-agent',
			MWP_URL . 'assets/agent.css',
			array(),
			MWPP_asset_version( 'assets/agent.css' )
		);
		wp_enqueue_script(
			'mwp-agent-front',
			MWP_URL . 'assets/agent-front.js',
			array(),
			MWPP_asset_version( 'assets/agent-front.js' ),
			true
		);
		wp_localize_script( 'mwp-agent-front', 'mwpaInquiry', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'mwpa_inquiry' ),
			'i18n'    => array(
				'sending' => self::t( 'Wysyłanie…', 'Sending…' ),
				'sent'    => self::t( 'Wysłane! Doradca odpowie e-mailem wkrótce.', 'Sent! The agent will reply by email shortly.' ),
				'error'   => self::t( 'Coś poszło nie tak — spróbuj ponownie lub napisz na podany adres e-mail.', 'Something went wrong — please try again, or use the email address above.' ),
				'invalid' => self::t( 'Uzupełnij imię, poprawny e-mail, liczbę osób oraz odpowiedź antyspamową.', 'Please fill in your name, a valid email, how many people are traveling, and the anti-spam answer.' ),
			),
		) );
	}

	// -----------------------------------------------------------------
	// Rendering
	// -----------------------------------------------------------------

	/**
	 * Resolve which agent a shortcode refers to.
	 *
	 * @param string $who Explicit user from the shortcode (ID, login or slug).
	 * @return int User ID, or 0.
	 */
	protected static function resolve_user( $who ) {
		if ( $who ) {
			if ( is_numeric( $who ) ) {
				return (int) $who;
			}
			$u = get_user_by( 'login', $who );
			if ( ! $u ) {
				$u = get_user_by( 'slug', $who );
			}
			return $u ? (int) $u->ID : 0;
		}

		$post = get_post();
		if ( $post ) {
			$linked = (int) get_post_meta( $post->ID, self::PAGE_META, true );
			if ( $linked ) {
				return $linked;
			}
		}
		return 0;
	}

	/**
	 * [multiwander_agent_card country="Tajlandia"] — compact teaser card for country pages.
	 *
	 * Shows the agent's circular photo, a gender-aware "Meet our expert on {country}"
	 * heading, their short intro, a contact button and a link to their full profile.
	 *
	 * @param array $atts Shortcode attributes:
	 *   - user    (optional) User ID, login or slug. Falls back to _mwp_agent_user page meta.
	 *   - country (optional) Country label used in the heading, e.g. "Tajlandia".
	 * @return string
	 */
	public static function render_card( $atts ) {
		$atts = shortcode_atts(
			array(
				'user'    => '',
				'country' => '',
			),
			$atts,
			'multiwander_agent_card'
		);

		$uid = self::resolve_user( $atts['user'] );
		if ( ! $uid ) {
			return current_user_can( 'edit_posts' )
				? '<p class="mwpa-notice">' . esc_html__( 'No travel agent is linked to this page yet — pick one in the "Travel agent profile" box beside the editor.', 'multiwander-packages' ) . '</p>'
				: '';
		}

		$user = get_userdata( $uid );
		if ( ! $user ) {
			return '';
		}

		$get = function ( $key, $default = '' ) use ( $uid ) {
			$v = get_user_meta( $uid, self::META . $key, true );
			return '' !== $v ? $v : $default;
		};

		$name      = $user->display_name;
		$photo_id  = (int) $get( 'photo_id' );
		$photo_src = $photo_id ? wp_get_attachment_image_url( $photo_id, 'medium' ) : '';
		$intro     = $get( 'intro' );
		$cta_label = $get( 'cta_label', __( 'Book a free consultation!', 'multiwander-packages' ) );
		$cta_url   = $get( 'cta_url' );
		$email     = $get( 'email' );
		$gender    = $get( 'gender', 'm' );
		$country   = sanitize_text_field( $atts['country'] );

		// Fall back CTA to mailto if no cta_url set.
		if ( ! $cta_url && $email ) {
			$cta_url = 'mailto:' . $email;
		}

		// Find the agent's own profile page (a page that links this agent AND contains the full shortcode).
		$profile_url = '';
		$linked_pages = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'meta_key'       => self::PAGE_META,   // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => $uid,              // phpcs:ignore WordPress.DB.SlowDBQuery
			'posts_per_page' => -1,
			'fields'         => 'ids',
		) );
		foreach ( $linked_pages as $pid ) {
			if ( has_shortcode( (string) get_post_field( 'post_content', $pid ), 'multiwander_agent' ) ) {
				$profile_url = get_permalink( $pid );
				break;
			}
		}

		// Heading: gender-aware "Meet our expert on {country}, {Name}".
		if ( $country ) {
			if ( 'f' === $gender ) {
				/* translators: 1: country name, 2: agent name */
				$heading_prefix = sprintf( __( 'Meet our female expert on %1$s,', 'multiwander-packages' ), esc_html( $country ) );
			} else {
				/* translators: 1: country name, 2: agent name */
				$heading_prefix = sprintf( __( 'Meet our expert on %1$s,', 'multiwander-packages' ), esc_html( $country ) );
			}
		} else {
			$heading_prefix = '';
		}

		ob_start();
		?>
		<div class="mwpa-widget">
			<div class="mwpa-widget-photo">
				<?php if ( $photo_src ) : ?>
					<img src="<?php echo esc_url( $photo_src ); ?>" alt="<?php echo esc_attr( $name ); ?>">
				<?php else : ?>
					<span class="mwpa-widget-photo-placeholder" aria-hidden="true">
						<svg viewBox="0 0 24 24"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5z"/></svg>
					</span>
				<?php endif; ?>
			</div>

			<div class="mwpa-widget-body">
				<span class="mwpa-widget-eyebrow">💬 <?php echo esc_html( self::t( 'Lokalny ekspert od podróży', 'Local travel expert' ) ); ?></span>
				<p class="mwpa-widget-heading">
					<?php if ( $heading_prefix ) : ?>
						<?php echo $heading_prefix; // already escaped above ?>
						<br>
					<?php endif; ?>
					<?php if ( $profile_url ) : ?>
						<a class="mwpa-widget-name" href="<?php echo esc_url( $profile_url ); ?>"><?php echo esc_html( $name ); ?></a>
					<?php else : ?>
						<strong class="mwpa-widget-name"><?php echo esc_html( $name ); ?></strong>
					<?php endif; ?>
				</p>

				<?php if ( $intro ) : ?>
					<p class="mwpa-widget-intro"><?php echo esc_html( $intro ); ?></p>
				<?php endif; ?>

				<div class="mwpa-widget-actions">
					<?php
					// When email is the only contact action (no external booking
					// link set), the big turquoise button OPENS the inline
					// message form directly — one clear action that never
					// dead-ends on a mailto: link the visitor's browser can't
					// open. A real booking URL still links out as before.
					$cta_is_mailto = ( '' === (string) $cta_url ) || ( 0 === strpos( (string) $cta_url, 'mailto:' ) );
					$form_first    = ( $email && $cta_is_mailto );
					$card_form_id  = self::inquiry_form_id( $uid, 'card' );
					?>
					<?php if ( $form_first ) : ?>
						<button type="button" class="mwpa-widget-btn" data-mwpa-toggle="<?php echo esc_attr( $card_form_id ); ?>" aria-expanded="false">
							<svg class="mwpa-widget-btn-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
							<?php
							printf(
								/* translators: %s: agent name */
								esc_html( self::t( 'Skontaktuj się z %s', 'Contact %s' ) ),
								esc_html( $name )
							);
							?>
						</button>
					<?php elseif ( $cta_url ) : ?>
						<a class="mwpa-widget-btn" href="<?php echo esc_url( $cta_url ); ?>">
							<svg class="mwpa-widget-btn-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
							<?php
							printf(
								/* translators: %s: agent name */
								esc_html( self::t( 'Skontaktuj się z %s', 'Contact %s' ) ),
								esc_html( $name )
							);
							?>
						</a>
					<?php endif; ?>

					<?php
					// Quiet fallback: the address shown as plain, copyable text,
					// for visitors who'd rather email directly.
					if ( $email ) :
						?>
						<p class="mwpa-widget-email">
							<?php echo esc_html( self::t( 'lub e-mail:', 'or email:' ) ); ?>
							<a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
							<button type="button" class="mwpa-copy-btn" data-mwpa-copy="<?php echo esc_attr( $email ); ?>" aria-label="<?php echo esc_attr( self::t( 'Skopiuj adres e-mail', 'Copy email address' ) ); ?>">📋</button>
						</p>
					<?php endif; ?>

					<?php if ( $email ) : ?>
						<?php self::render_inquiry_form( $uid, $name, 'card', ! $form_first ); ?>
					<?php endif; ?>

					<?php if ( $profile_url ) : ?>
						<a class="mwpa-widget-profile-link" href="<?php echo esc_url( $profile_url ); ?>">
							<?php echo esc_html( self::t( 'Zobacz pełny profil', 'View full profile' ) ); ?> →
						</a>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * [multiwander_agent_cta user="10" country="Dominikana"] — a compact,
	 * centered "message me directly" button, meant for the BOTTOM of a page
	 * that already has the full [multiwander_agent_card] teaser near the top.
	 * Prefers WhatsApp (fastest for a visitor to actually use), then falls
	 * back the same way the card does: cta_url, then mailto.
	 *
	 * @param array $atts Shortcode attributes:
	 *   - user    (optional) User ID, login or slug. Falls back to _mwp_agent_user page meta.
	 *   - country (optional) Country label used in the heading, e.g. "Dominikana".
	 * @return string
	 */
	public static function render_cta( $atts ) {
		$atts = shortcode_atts(
			array(
				'user'    => '',
				'country' => '',
			),
			$atts,
			'multiwander_agent_cta'
		);

		$uid = self::resolve_user( $atts['user'] );
		if ( ! $uid ) {
			return current_user_can( 'edit_posts' )
				? '<p class="mwpa-notice">' . esc_html__( 'No travel agent is linked to this page yet — pick one in the "Travel agent profile" box beside the editor.', 'multiwander-packages' ) . '</p>'
				: '';
		}

		$user = get_userdata( $uid );
		if ( ! $user ) {
			return '';
		}

		$get = function ( $key, $default = '' ) use ( $uid ) {
			$v = get_user_meta( $uid, self::META . $key, true );
			return '' !== $v ? $v : $default;
		};

		$name      = $user->display_name;
		$photo_id  = (int) $get( 'photo_id' );
		$photo_src = $photo_id ? wp_get_attachment_image_url( $photo_id, 'medium' ) : '';
		$email     = $get( 'email' );
		$whatsapp  = $get( 'whatsapp' );
		$cta_url   = $get( 'cta_url' );
		$country   = sanitize_text_field( $atts['country'] );

		$wa_url = '';
		if ( $whatsapp ) {
			$wa_url = ( 0 === strpos( $whatsapp, 'http' ) ) ? $whatsapp : 'https://wa.me/' . preg_replace( '/[^\d]/', '', $whatsapp );
		}

		// Prefer WhatsApp for this button — it's the fastest way for a
		// visitor to actually message the agent — then the usual fallbacks.
		$href = $wa_url ? $wa_url : ( $cta_url ? $cta_url : ( $email ? 'mailto:' . $email : '' ) );
		if ( ! $href ) {
			return '';
		}

		// If the button would only be a mailto: link (no WhatsApp, no booking
		// URL), make it OPEN the inline message form instead, so it never
		// dead-ends on a visitor whose browser has no mail app.
		$cta_form_first = ( $email && 0 === strpos( (string) $href, 'mailto:' ) );
		$cta_form_id    = self::inquiry_form_id( $uid, 'cta' );

		if ( $country ) {
			/* translators: %s: country name */
			$title = sprintf( esc_html( self::t( 'Masz pytania o %s?', 'Questions about %s?' ) ), esc_html( $country ) );
		} else {
			$title = esc_html( self::t( 'Masz pytania o ten wyjazd?', 'Questions about this trip?' ) );
		}

		ob_start();
		?>
		<div class="mwpa-cta">
			<?php if ( $photo_src ) : ?>
				<div class="mwpa-cta-photo">
					<img src="<?php echo esc_url( $photo_src ); ?>" alt="<?php echo esc_attr( $name ); ?>">
				</div>
			<?php endif; ?>
			<div class="mwpa-cta-body">
				<p class="mwpa-cta-title"><?php echo $title; // already escaped above ?></p>
				<p class="mwpa-cta-sub">
					<?php
					printf(
						/* translators: %s: agent name */
						esc_html( self::t( 'Napisz bezpośrednio do %s.', 'Message %s directly — no forms, no waiting.' ) ),
						esc_html( $name )
					);
					?>
				</p>
				<?php
				// Same mailto fallback as the card widget above — a visible,
				// copyable address in case the visitor's browser has no
				// email app to hand the mailto: link to.
				if ( 0 === strpos( (string) $href, 'mailto:' ) && $email ) :
					?>
					<p class="mwpa-cta-email">
						<a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
						<button type="button" class="mwpa-copy-btn" data-mwpa-copy="<?php echo esc_attr( $email ); ?>" aria-label="<?php echo esc_attr( self::t( 'Skopiuj adres e-mail', 'Copy email address' ) ); ?>">📋</button>
					</p>
				<?php endif; ?>
				<?php if ( $email ) : ?>
					<?php self::render_inquiry_form( $uid, $name, 'cta', ! $cta_form_first ); ?>
				<?php endif; ?>
			</div>
			<?php if ( $cta_form_first ) : ?>
			<button type="button" class="mwpa-cta-btn" data-mwpa-toggle="<?php echo esc_attr( $cta_form_id ); ?>" aria-expanded="false">
				<svg class="mwpa-cta-btn-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
				<?php
				printf(
					/* translators: %s: agent name */
					esc_html( self::t( 'Skontaktuj się z %s', 'Contact %s' ) ),
					esc_html( $name )
				);
				?>
			</button>
			<?php else : ?>
			<a class="mwpa-cta-btn" href="<?php echo esc_url( $href ); ?>">
				<?php if ( $wa_url ) : ?>
					<svg class="mwpa-cta-btn-ico" viewBox="0 0 24 24" fill="currentColor" width="18" height="18" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15l-1.1 4 4.2-1.1A10 10 0 1 0 12 2zm0 18a8 8 0 0 1-4.1-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8 8 0 1 1 12 20zm4.4-5.9c-.2-.1-1.4-.7-1.6-.8s-.4-.1-.5.1-.5.7-.6.8-.3.1-.5 0a6.6 6.6 0 0 1-1.9-1.2 7.2 7.2 0 0 1-1.3-1.7c-.1-.2 0-.4.1-.5l.4-.4.2-.4a.5.5 0 0 0 0-.4c-.1-.1-.5-1.3-.7-1.8s-.4-.4-.5-.4h-.5a.9.9 0 0 0-.7.3 2.8 2.8 0 0 0-.9 2.1 4.9 4.9 0 0 0 1 2.6 11.2 11.2 0 0 0 4.3 3.8c.6.3 1.1.4 1.5.5a3.6 3.6 0 0 0 1.6.1 2.7 2.7 0 0 0 1.8-1.2 2.2 2.2 0 0 0 .1-1.2c-.1-.1-.2-.2-.4-.3z"/></svg>
					<?php echo esc_html( self::t( 'Napisz na WhatsApp', 'Text me on WhatsApp' ) ); ?>
				<?php else : ?>
					<svg class="mwpa-cta-btn-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
					<?php
					printf(
						/* translators: %s: agent name */
						esc_html( self::t( 'Skontaktuj się z %s', 'Contact %s' ) ),
						esc_html( $name )
					);
					?>
				<?php endif; ?>
			</a>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * A small "send a quick message" form, toggled open by a link under the
	 * main contact button. Submits via AJAX to handle_inquiry() below, which
	 * emails the agent directly with the visitor's name/email/message — no
	 * page reload, no separate contact-form plugin needed.
	 *
	 * Shared by both render_card() and render_cta() so the two surfaces
	 * behave identically; each instance gets its own DOM ids via $uid plus
	 * a per-call suffix, since both shortcodes can appear on the same page.
	 *
	 * @param int    $uid    Agent user ID.
	 * @param string $name   Agent display name (for the submit button / toast).
	 * @param string $suffix Unique suffix so ids don't collide with another instance.
	 * @return void Echoes directly (called from inside an ob_start() block).
	 */
	/**
	 * Stable DOM id for an inquiry form, so the primary contact button can be
	 * wired to toggle the very same form open (one button, no extra link).
	 *
	 * @param int    $uid    Agent user ID.
	 * @param string $suffix Surface suffix: 'card', 'cta', 'profile'.
	 * @return string
	 */
	protected static function inquiry_form_id( $uid, $suffix ) {
		return 'mwpa-inquiry-' . absint( $uid ) . '-' . sanitize_html_class( $suffix );
	}

	protected static function render_inquiry_form( $uid, $name, $suffix, $with_toggle = true ) {
		$form_id = self::inquiry_form_id( $uid, $suffix );
		?>
		<?php if ( $with_toggle ) : ?>
		<p class="mwpa-inquiry-toggle-wrap">
			<button type="button" class="mwpa-inquiry-toggle" data-mwpa-toggle="<?php echo esc_attr( $form_id ); ?>" aria-expanded="false">
				✉️ <?php echo esc_html( self::t( 'Lub wyślij szybką wiadomość', 'Or send a quick message' ) ); ?>
			</button>
		</p>
		<?php endif; ?>
		<form class="mwpa-inquiry" id="<?php echo esc_attr( $form_id ); ?>" hidden>
			<input type="hidden" name="action" value="mwpa_send_inquiry">
			<input type="hidden" name="uid" value="<?php echo absint( $uid ); ?>">
			<input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'mwpa_inquiry' ) ); ?>">
			<input type="hidden" name="mwpa_page" value="<?php echo esc_url( get_permalink() ); ?>">
			<!-- Honeypot — invisible to people, visible to most spam bots. -->
			<div class="mwpa-inquiry-hp" aria-hidden="true">
				<label>Website <input type="text" name="mwpa_website" tabindex="-1" autocomplete="off"></label>
			</div>
			<div class="mwpa-inquiry-row">
				<input type="text" name="mwpa_name" placeholder="<?php echo esc_attr( self::t( 'Imię i nazwisko*', 'Your name*' ) ); ?>" required>
				<input type="email" name="mwpa_email" placeholder="<?php echo esc_attr( self::t( 'Adres e-mail*', 'Your email*' ) ); ?>" required>
			</div>
			<div class="mwpa-inquiry-row">
				<input type="number" name="mwpa_people" min="1" max="99" inputmode="numeric" placeholder="<?php echo esc_attr( self::t( 'Ile osób podróżuje?*', 'How many people are traveling?*' ) ); ?>" required>
				<input type="text" name="mwpa_airport" placeholder="<?php echo esc_attr( self::t( 'Lotnisko wylotu (opcjonalnie)', 'Departure airport (optional)' ) ); ?>">
			</div>
			<textarea name="mwpa_message" rows="3" placeholder="<?php echo esc_attr( self::t( 'Coś jeszcze? Terminy, budżet, pomysły na podróż…', 'Anything else? Dates, budget, trip ideas…' ) ); ?>"></textarea>
			<?php
			// Lightweight human check: a tiny arithmetic question. Together with
			// the honeypot and the per-visitor rate-limit this stops the
			// automated spam scripts fire at any public form — without a
			// third-party captcha, cookies, or anything the visitor has to
			// click. The correct answer never appears in the page; only an HMAC
			// of it does, so a bot can't just read it out of the markup.
			$math_a    = wp_rand( 2, 9 );
			$math_b    = wp_rand( 1, 9 );
			$math_hash = hash_hmac( 'sha256', (string) ( $math_a + $math_b ), wp_salt( 'nonce' ) );
			?>
			<div class="mwpa-inquiry-math">
				<label for="<?php echo esc_attr( $form_id ); ?>-math">
					<?php
					printf(
						/* translators: 1: first number, 2: second number */
						esc_html( self::t( 'Szybka weryfikacja — ile to %1$d + %2$d?', 'Quick check — what is %1$d + %2$d?' ) ),
						(int) $math_a,
						(int) $math_b
					);
					?>
				</label>
				<input type="text" id="<?php echo esc_attr( $form_id ); ?>-math" name="mwpa_math" inputmode="numeric" autocomplete="off" required>
				<input type="hidden" name="mwpa_math_h" value="<?php echo esc_attr( $math_hash ); ?>">
			</div>
			<button type="submit" class="mwpa-inquiry-submit">
				<?php
				printf(
					/* translators: %s: agent name */
					esc_html( self::t( 'Wyślij do %s', 'Send to %s' ) ),
					esc_html( $name )
				);
				?>
			</button>
			<p class="mwpa-inquiry-status" role="status" aria-live="polite"></p>
		</form>
		<?php
	}

	/**
	 * AJAX handler for the inline inquiry form above. Emails the agent
	 * directly — Reply-To is the visitor's own address, so the agent can
	 * just hit "reply" in their inbox.
	 *
	 * @return void Always ends in wp_send_json_success()/wp_send_json_error().
	 */
	public static function handle_inquiry() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'mwpa_inquiry' ) ) {
			wp_send_json_error( array( 'message' => __( 'Your session expired — please reload the page and try again.', 'multiwander-packages' ) ), 403 );
		}

		// Honeypot: a real visitor never fills this in.
		if ( ! empty( $_POST['mwpa_website'] ) ) {
			wp_send_json_success(); // Pretend it worked so the bot moves on.
		}

		// Language for the visitor-facing replies: this AJAX request's own URL
		// is always /wp-admin/admin-ajax.php, so read it from the page the form
		// was submitted from (/en/… → English, everything else → Polish).
		$page_url = isset( $_POST['mwpa_page'] ) ? esc_url_raw( wp_unslash( $_POST['mwpa_page'] ) ) : '';
		$is_en    = false;
		if ( $page_url ) {
			$ppath = '/' . trim( (string) wp_parse_url( $page_url, PHP_URL_PATH ), '/' ) . '/';
			$is_en = false !== strpos( $ppath, '/en/' );
		}
		$t = function ( $pl, $en ) use ( $is_en ) { return $is_en ? $en : $pl; };

		$uid = isset( $_POST['uid'] ) ? absint( $_POST['uid'] ) : 0;
		$agent = $uid ? get_userdata( $uid ) : false;
		$agent_email = $agent ? get_user_meta( $uid, self::META . 'email', true ) : '';
		if ( ! $agent || ! $agent_email || ! is_email( $agent_email ) ) {
			wp_send_json_error( array( 'message' => $t( 'Z tym doradcą nie można się teraz skontaktować.', 'This travel agent cannot be reached right now.' ) ), 400 );
		}

		$visitor_name    = isset( $_POST['mwpa_name'] ) ? sanitize_text_field( wp_unslash( $_POST['mwpa_name'] ) ) : '';
		$visitor_email   = isset( $_POST['mwpa_email'] ) ? sanitize_email( wp_unslash( $_POST['mwpa_email'] ) ) : '';
		$visitor_message = isset( $_POST['mwpa_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['mwpa_message'] ) ) : '';
		$visitor_people  = isset( $_POST['mwpa_people'] ) ? absint( wp_unslash( $_POST['mwpa_people'] ) ) : 0;
		$visitor_airport = isset( $_POST['mwpa_airport'] ) ? sanitize_text_field( wp_unslash( $_POST['mwpa_airport'] ) ) : '';

		// Required: name, a valid email, and how many people are traveling.
		// The free-text message and the departure airport are optional.
		if ( '' === $visitor_name || ! is_email( $visitor_email ) || $visitor_people < 1 ) {
			wp_send_json_error( array( 'message' => $t( 'Uzupełnij imię, poprawny e-mail oraz liczbę podróżujących osób.', 'Please fill in your name, a valid email, and how many people are traveling.' ) ), 400 );
		}

		// Anti-spam arithmetic check: compare an HMAC of the visitor's answer
		// to the HMAC that was rendered with the question. The expected answer
		// is never in the page, so a bot has to actually solve it.
		$math_answer = isset( $_POST['mwpa_math'] ) ? (int) wp_unslash( $_POST['mwpa_math'] ) : null;
		$math_hash   = isset( $_POST['mwpa_math_h'] ) ? sanitize_text_field( wp_unslash( $_POST['mwpa_math_h'] ) ) : '';
		$math_ok     = ( null !== $math_answer ) && $math_hash
			&& hash_equals( hash_hmac( 'sha256', (string) $math_answer, wp_salt( 'nonce' ) ), $math_hash );
		if ( ! $math_ok ) {
			wp_send_json_error( array( 'message' => $t( 'Nieprawidłowa odpowiedź antyspamowa — sprawdź działanie i spróbuj ponownie.', 'The anti-spam answer was not correct — please check the little sum and try again.' ) ), 400 );
		}

		// Light rate-limit: one submission per visitor+agent per 30 seconds,
		// so an accidental double-click (or a dumb script) can't flood the
		// agent's inbox.
		$rl_key = 'mwpa_inq_' . md5( $visitor_email . '|' . $uid );
		if ( get_transient( $rl_key ) ) {
			wp_send_json_success(); // Already sent moments ago — don't error, just don't resend.
		}
		set_transient( $rl_key, 1, 30 );

		$site_name = get_bloginfo( 'name' );

		$subject = sprintf( '[%1$s] Nowe zapytanie od %2$s', $site_name, $visitor_name );

		$body_lines = array(
			sprintf( '%1$s (%2$s) wysłał(a) zapytanie przez Twój profil MultiWander:', $visitor_name, $visitor_email ),
			'',
			sprintf( 'Liczba osób: %d', $visitor_people ),
		);
		if ( '' !== $visitor_airport ) {
			$body_lines[] = sprintf( 'Lotnisko wylotu: %s', $visitor_airport );
		}
		if ( '' !== $visitor_message ) {
			$body_lines[] = '';
			$body_lines[] = 'Wiadomość:';
			$body_lines[] = $visitor_message;
		}
		$body_lines[] = '';
		$body_lines[] = '—';
		if ( $page_url ) {
			$body_lines[] = sprintf( 'Wysłano ze strony: %s', $page_url );
		}
		$body = implode( "\n", $body_lines );

		$headers = array( 'Reply-To: ' . $visitor_name . ' <' . $visitor_email . '>' );

		$sent = wp_mail( $agent_email, $subject, $body, $headers );

		if ( ! $sent ) {
			wp_send_json_error( array( 'message' => $t( 'Nie udało się wysłać wiadomości — spróbuj ponownie lub napisz bezpośrednio na podany adres e-mail.', 'The message could not be sent — please try again, or use the email address directly.' ) ), 500 );
		}

		wp_send_json_success( array( 'message' => $t( 'Wysłane! Doradca odpowie e-mailem wkrótce.', 'Sent! The agent will reply by email shortly.' ) ) );
	}

	/**
	 * Parse the region repeater fields out of \$_POST into a clean array.
	 *
	 * Shared by the profile screen and the agent kit so both store the same
	 * rich shape: { name, subtitle, countries, note, tags[] }.
	 *
	 * @param string \$meta The meta prefix (MWP_Agent::META).
	 * @return array<int,array<string,mixed>>
	 */
	public static function parse_regions_from_post( $meta ) {
		$names     = isset( $_POST[ $meta . 'regions_name' ] ) ? (array) $_POST[ $meta . 'regions_name' ] : array();
		$subs      = isset( $_POST[ $meta . 'regions_subtitle' ] ) ? (array) $_POST[ $meta . 'regions_subtitle' ] : array();
		$countries = isset( $_POST[ $meta . 'regions_countries' ] ) ? (array) $_POST[ $meta . 'regions_countries' ] : array();
		$notes     = isset( $_POST[ $meta . 'regions_note' ] ) ? (array) $_POST[ $meta . 'regions_note' ] : array();
		$tags      = isset( $_POST[ $meta . 'regions_tags' ] ) ? (array) $_POST[ $meta . 'regions_tags' ] : array();
		$out = array();
		foreach ( $names as $i => $rname ) {
			$rname = self::fix_unicode_escapes( sanitize_text_field( wp_unslash( $rname ) ) );
			if ( '' === $rname ) { continue; }
			$sub  = isset( $subs[ $i ] ) ? self::fix_unicode_escapes( sanitize_text_field( wp_unslash( $subs[ $i ] ) ) ) : '';
			$cty  = isset( $countries[ $i ] ) ? sanitize_text_field( wp_unslash( $countries[ $i ] ) ) : '';
			$note = isset( $notes[ $i ] ) ? self::fix_unicode_escapes( sanitize_textarea_field( wp_unslash( $notes[ $i ] ) ) ) : '';
			$tagstr  = isset( $tags[ $i ] ) ? sanitize_text_field( wp_unslash( $tags[ $i ] ) ) : '';
			$taglist = array_values( array_filter( array_map( 'trim', explode( ',', self::fix_unicode_escapes( $tagstr ) ) ) ) );
			$out[] = array(
				'name'      => $rname,
				'subtitle'  => $sub,
				'countries' => $cty,
				'note'      => $note,
				'tags'      => $taglist,
			);
		}
		return $out;
	}

	/**
	 * Allowed proficiency levels for a spoken language (Polish labels).
	 *
	 * @return string[]
	 */
	public static function language_levels() {
		return array( 'Ojczysty', 'Biegły', 'Bardzo dobry', 'Komunikatywny' );
	}

	/**
	 * Normalise the stored languages value into a list of { name, level }.
	 *
	 * Accepts the new JSON array as well as the legacy comma string
	 * "Polski (Ojczysty), Angielski (Biegły)".
	 *
	 * @param string \$raw Stored meta value.
	 * @return array<int,array{name:string,level:string}>
	 */
	public static function parse_languages( $raw ) {
		$raw = (string) $raw;
		if ( '' === $raw ) { return array(); }
		$decoded = json_decode( $raw, true );
		if ( is_array( $decoded ) ) {
			$out = array();
			foreach ( $decoded as $e ) {
				if ( is_string( $e ) ) {
					$name = trim( $e ); $level = '';
					if ( preg_match( '/^(.+?)\s*\((.+?)\)\s*$/', $name, $m ) ) { $name = trim( $m[1] ); $level = trim( $m[2] ); }
					if ( '' !== $name ) { $out[] = array( 'name' => $name, 'level' => $level ); }
				} elseif ( isset( $e['name'] ) && '' !== $e['name'] ) {
					$out[] = array( 'name' => (string) $e['name'], 'level' => isset( $e['level'] ) ? (string) $e['level'] : '' );
				}
			}
			return $out;
		}
		// Legacy comma string.
		$out = array();
		foreach ( array_filter( array_map( 'trim', explode( ',', $raw ) ) ) as $item ) {
			$name = $item; $level = '';
			if ( preg_match( '/^(.+?)\s*\((.+?)\)\s*$/', $item, $m ) ) { $name = trim( $m[1] ); $level = trim( $m[2] ); }
			$out[] = array( 'name' => $name, 'level' => $level );
		}
		return $out;
	}

	/**
	 * Parse the languages repeater fields out of \$_POST into JSON.
	 *
	 * @param string \$meta Meta prefix.
	 * @return array<int,array{name:string,level:string}>
	 */
	/**
	 * Common travel-style suggestions, shown to the agent as datalist
	 * options while they type — a nudge toward something that fits the
	 * site's existing vocabulary, not a locked list. Polish first since
	 * that is the main market.
	 *
	 * @return string[]
	 */
	public static function travel_style_options() {
		return array(
			__( 'Luksusowe podróże', 'multiwander-packages' ),
			__( 'Przygoda i aktywny wypoczynek', 'multiwander-packages' ),
			__( 'Podróże rodzinne', 'multiwander-packages' ),
			__( 'Backpacking', 'multiwander-packages' ),
			__( 'Miesiąc miodowy i romantyczne wyjazdy', 'multiwander-packages' ),
			__( 'Kultura i historia', 'multiwander-packages' ),
			__( 'Plaża i relaks', 'multiwander-packages' ),
			__( 'Ekoturystyka', 'multiwander-packages' ),
			__( 'Podróże solo', 'multiwander-packages' ),
			__( 'Rejsy wycieczkowe', 'multiwander-packages' ),
			__( 'Wycieczki samochodowe', 'multiwander-packages' ),
			__( 'Wellness i spa', 'multiwander-packages' ),
			__( 'City breaks', 'multiwander-packages' ),
			__( 'Nieoczywiste kierunki', 'multiwander-packages' ),
		);
	}

	/**
	 * The "My travel style" repeater → a plain array of up to three short,
	 * one-line entries. Capped at three on purpose — this is meant to read
	 * at a glance on the profile page, not become a second bio.
	 *
	 * @param string $meta The meta prefix (MWP_Agent::META).
	 * @return string[]
	 */
	public static function parse_travel_styles_from_post( $meta ) {
		$raw = isset( $_POST[ $meta . 'style' ] ) ? (array) $_POST[ $meta . 'style' ] : array();
		$out = array();
		foreach ( $raw as $one ) {
			$one = self::fix_unicode_escapes( sanitize_text_field( wp_unslash( $one ) ) );
			if ( '' === $one ) {
				continue;
			}
			$out[] = $one;
			if ( count( $out ) >= 3 ) {
				break;
			}
		}
		return $out;
	}

	public static function parse_languages_from_post( $meta ) {
		$names  = isset( $_POST[ $meta . 'languages_name' ] ) ? (array) $_POST[ $meta . 'languages_name' ] : array();
		$levels = isset( $_POST[ $meta . 'languages_level' ] ) ? (array) $_POST[ $meta . 'languages_level' ] : array();
		$allowed = self::language_levels();
		$out = array();
		foreach ( $names as $i => $lname ) {
			$lname = self::fix_unicode_escapes( sanitize_text_field( wp_unslash( $lname ) ) );
			if ( '' === $lname ) { continue; }
			$lvl = isset( $levels[ $i ] ) ? sanitize_text_field( wp_unslash( $levels[ $i ] ) ) : '';
			if ( '' !== $lvl && ! in_array( $lvl, $allowed, true ) ) { $lvl = ''; }
			$out[] = array( 'name' => $lname, 'level' => $lvl );
		}
		return $out;
	}

	/**
	 * Repair mojibake left by a bad JSON round-trip.
	 *
	 * Polish characters were stored as the literal text "u0142" instead of
	 * the character ł (the escape lost its backslash). This turns any such
	 * uXXXX / \uXXXX sequence back into the real character for display.
	 *
	 * @param string \$str Possibly-corrupted text.
	 * @return string
	 */
	public static function fix_unicode_escapes( $str ) {
		if ( ! is_string( $str ) || '' === $str || false === strpos( $str, 'u' ) ) {
			return $str;
		}
		return preg_replace_callback(
			'/\\\\?u([0-9a-fA-F]{4})/',
			function ( $m ) {
				$cp = hexdec( $m[1] );
				if ( $cp < 0x20 ) { return $m[0]; }
				return mb_convert_encoding( pack( 'N', $cp ), 'UTF-8', 'UTF-32BE' );
			},
			$str
		);
	}

	/**
	 * Resolve the flag ISO codes for a region.
	 *
	 * The "Flags" field holds a comma-separated list the agent built one
	 * country at a time in the chip picker — plain country names, typed in
	 * English (e.g. "Thailand, Vietnam"). Each one is resolved to a code
	 * via country_name_to_code(). A bare two-letter code is still honoured
	 * too, so flags saved before the chip picker existed keep working.
	 * Falling that, the region name itself is scanned the same way, so a
	 * region called "Thailand" lights up its flag with no Flags field at
	 * all.
	 *
	 * @param string $countries Comma-separated country names or codes, may be empty.
	 * @param string $name      Region name, used for auto-detection.
	 * @return string[] Up to four lowercase ISO-3166-1 alpha-2 codes.
	 */
	protected static function region_flag_codes( $countries, $name ) {
		$codes = array();

		// 1. The Flags field: one country name (or legacy 2-letter code) per
		// comma-separated entry.
		if ( $countries ) {
			foreach ( preg_split( '/\s*,\s*/', trim( (string) $countries ) ) as $tok ) {
				$tok = trim( $tok );
				if ( '' === $tok ) {
					continue;
				}
				if ( preg_match( '/^[a-zA-Z]{2}$/', $tok ) ) {
					$codes[] = strtolower( $tok );
					continue;
				}
				$code = self::country_name_to_code( $tok );
				if ( $code ) {
					$codes[] = $code;
				}
			}
			$codes = array_values( array_unique( $codes ) );
		}

		// 2. Auto-detect from the region name.
		if ( empty( $codes ) && $name ) {
			$hay = function_exists( 'mb_strtolower' ) ? mb_strtolower( $name, 'UTF-8' ) : strtolower( $name );
			foreach ( self::country_flag_map() as $needle => $code ) {
				if ( false !== mb_strpos( $hay, $needle ) ) {
					$codes[] = $code;
				}
			}
			$codes = array_values( array_unique( $codes ) );
		}

		return array_slice( $codes, 0, 4 );
	}

	/**
	 * Polish country-name stems → ISO-3166-1 alpha-2 (flagcdn) codes.
	 *
	 * Stems (not full names) so declensions match, e.g. "hiszpan" matches
	 * both "Hiszpania" and "hiszpańska".
	 *
	 * @return array<string,string>
	 */
	protected static function country_flag_map() {
		return array(
			'hiszpan'    => 'es',
			'portugal'   => 'pt',
			'turcj'      => 'tr',
			'turcy'      => 'tr',
			'włoch'      => 'it',
			'wloch'      => 'it',
			'grecj'      => 'gr',
			'greck'      => 'gr',
			'francj'     => 'fr',
			'francu'     => 'fr',
			'niemc'      => 'de',
			'niemieck'   => 'de',
			'holandi'    => 'nl',
			'niderland'  => 'nl',
			'belgi'      => 'be',
			'austri'     => 'at',
			'szwajcari'  => 'ch',
			'chorwacj'   => 'hr',
			'słoweni'    => 'si',
			'sloweni'    => 'si',
			'albani'     => 'al',
			'czarnogór'  => 'me',
			'czarnogor'  => 'me',
			'serbi'      => 'rs',
			'bośni'      => 'ba',
			'bosni'      => 'ba',
			'bułgari'    => 'bg',
			'bulgari'    => 'bg',
			'rumuni'     => 'ro',
			'węgr'       => 'hu',
			'wegr'       => 'hu',
			'czech'      => 'cz',
			'słowacj'    => 'sk',
			'slowacj'    => 'sk',
			'polsk'      => 'pl',
			'ukrain'     => 'ua',
			'ukraińsk'   => 'ua',
			'cypr'       => 'cy',
			'malt'       => 'mt',
			'chin'       => 'cn',
			'wietnam'    => 'vn',
			'tajland'    => 'th',
			'tajlandi'   => 'th',
			'kambodż'    => 'kh',
			'kambodz'    => 'kh',
			'laos'       => 'la',
			'indonezj'   => 'id',
			'bali'       => 'id',
			'malezj'     => 'my',
			'singapur'   => 'sg',
			'filipin'    => 'ph',
			'japoni'     => 'jp',
			'japoń'      => 'jp',
			'kore'       => 'kr',
			'indi'       => 'in',
			'sri lank'   => 'lk',
			'nepal'      => 'np',
			'gruzj'      => 'ge',
			'armeni'     => 'am',
			'azerbejdż'  => 'az',
			'kazachstan' => 'kz',
			'uzbekistan' => 'uz',
			'maroko'     => 'ma',
			'marokań'    => 'ma',
			'tunezj'     => 'tn',
			'egipt'      => 'eg',
			'egipsk'     => 'eg',
			'jordani'    => 'jo',
			'izrael'     => 'il',
			'liban'      => 'lb',
			'emirat'     => 'ae',
			'katar'      => 'qa',
			'oman'       => 'om',
			'arabi'      => 'sa',
			'keni'       => 'ke',
			'tanzani'    => 'tz',
			'zanzibar'   => 'tz',
			'rpa'        => 'za',
			'afryk'      => 'za',
			'meksyk'     => 'mx',
			'kolumbi'    => 'co',
			'dominikan'  => 'do',
			'kostaryk'   => 'cr',
			'panam'      => 'pa',
			'brazyli'    => 'br',
			'argentyn'   => 'ar',
			'peru'       => 'pe',
			'chile'      => 'cl',
			'kuba'       => 'cu',
			'stany zjedn'=> 'us',
			'usa'        => 'us',
			'kanad'      => 'ca',
			'islandi'    => 'is',
			'norwegi'    => 'no',
			'szwecj'     => 'se',
			'finlandi'   => 'fi',
			'dani'       => 'dk',
			'irlandi'    => 'ie',
			'wielka bryt'=> 'gb',
			'angli'      => 'gb',
			'szkocj'     => 'gb',
			'australi'   => 'au',
			'nowa zeland'=> 'nz',
			'rosj'       => 'ru',
		);
	}

	/**
	 * English country names → ISO-3166-1 alpha-2 (flagcdn) codes, for the
	 * chip picker in the "Flags" field (agents type country names in
	 * English — see the Travel Agents screen).
	 *
	 * Keyed by the full lowercase name since, unlike the Polish map, there
	 * is no declension to strip down to a stem.
	 *
	 * @return array<string,string>
	 */
	protected static function country_name_map_en() {
		return array(
			'spain' => 'es', 'portugal' => 'pt', 'turkey' => 'tr', 'turkiye' => 'tr',
			'italy' => 'it', 'greece' => 'gr', 'france' => 'fr', 'germany' => 'de',
			'netherlands' => 'nl', 'holland' => 'nl', 'belgium' => 'be', 'austria' => 'at',
			'switzerland' => 'ch', 'croatia' => 'hr', 'slovenia' => 'si', 'albania' => 'al',
			'montenegro' => 'me', 'serbia' => 'rs', 'bosnia' => 'ba', 'bosnia and herzegovina' => 'ba',
			'bulgaria' => 'bg', 'romania' => 'ro', 'hungary' => 'hu', 'czech republic' => 'cz',
			'czechia' => 'cz', 'slovakia' => 'sk', 'poland' => 'pl', 'ukraine' => 'ua',
			'cyprus' => 'cy', 'malta' => 'mt', 'china' => 'cn', 'vietnam' => 'vn',
			'thailand' => 'th', 'cambodia' => 'kh', 'laos' => 'la', 'indonesia' => 'id',
			'bali' => 'id', 'malaysia' => 'my', 'singapore' => 'sg', 'philippines' => 'ph',
			'japan' => 'jp', 'south korea' => 'kr', 'korea' => 'kr', 'india' => 'in',
			'sri lanka' => 'lk', 'nepal' => 'np', 'georgia' => 'ge', 'armenia' => 'am',
			'azerbaijan' => 'az', 'kazakhstan' => 'kz', 'uzbekistan' => 'uz', 'morocco' => 'ma',
			'tunisia' => 'tn', 'egypt' => 'eg', 'jordan' => 'jo', 'israel' => 'il',
			'lebanon' => 'lb', 'united arab emirates' => 'ae', 'uae' => 'ae', 'qatar' => 'qa',
			'oman' => 'om', 'saudi arabia' => 'sa', 'kenya' => 'ke', 'tanzania' => 'tz',
			'zanzibar' => 'tz', 'south africa' => 'za', 'mexico' => 'mx', 'colombia' => 'co',
			'dominican republic' => 'do', 'dominicana' => 'do', 'costa rica' => 'cr', 'panama' => 'pa',
			'brazil' => 'br', 'argentina' => 'ar', 'peru' => 'pe', 'chile' => 'cl', 'cuba' => 'cu',
			'united states' => 'us', 'usa' => 'us', 'canada' => 'ca', 'iceland' => 'is',
			'norway' => 'no', 'sweden' => 'se', 'finland' => 'fi', 'denmark' => 'dk',
			'ireland' => 'ie', 'united kingdom' => 'gb', 'uk' => 'gb', 'england' => 'gb',
			'scotland' => 'gb', 'australia' => 'au', 'new zealand' => 'nz', 'russia' => 'ru',
		);
	}

	/**
	 * Turn one typed country name — English or Polish, exact or a loose
	 * match — into an ISO code, for the Flags chip picker.
	 *
	 * @param string $name A single country name, as typed.
	 * @return string Lowercase ISO-3166-1 alpha-2 code, or '' if unrecognised.
	 */
	protected static function country_name_to_code( $name ) {
		$hay = function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( (string) $name ), 'UTF-8' ) : strtolower( trim( (string) $name ) );
		if ( '' === $hay ) {
			return '';
		}

		// Exact match in the English map first — "Thailand" should not have
		// to survive a substring scan to resolve.
		$en = self::country_name_map_en();
		if ( isset( $en[ $hay ] ) ) {
			return $en[ $hay ];
		}

		// Loose (substring) match against both maps, English then Polish —
		// catches "Dominican Rep." or a Polish stem typed by habit.
		foreach ( $en as $needle => $code ) {
			if ( false !== mb_strpos( $hay, $needle ) ) {
				return $code;
			}
		}
		foreach ( self::country_flag_map() as $needle => $code ) {
			if ( false !== mb_strpos( $hay, $needle ) ) {
				return $code;
			}
		}

		return '';
	}

	/**
	 * [multiwander_agent] — render an agent's styled profile.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render( $atts ) {
		$atts = shortcode_atts( array( 'user' => '' ), $atts, 'multiwander_agent' );
		$uid  = self::resolve_user( $atts['user'] );

		if ( ! $uid ) {
			return current_user_can( 'edit_posts' )
				? '<p class="mwpa-notice">' . esc_html__( 'No travel agent is linked to this page yet — pick one in the “Travel agent profile” box beside the editor.', 'multiwander-packages' ) . '</p>'
				: '';
		}

		$user = get_userdata( $uid );
		if ( ! $user ) {
			return '';
		}

		$get = function ( $key, $default = '' ) use ( $uid ) {
			$v = get_user_meta( $uid, self::META . $key, true );
			return '' !== $v ? $v : $default;
		};

		$name      = $user->display_name;
		$photo_id  = (int) $get( 'photo_id' );
		$photo     = $photo_id ? wp_get_attachment_image( $photo_id, 'large', false, array( 'class' => 'mwpa-photo-img', 'alt' => $name ) ) : '';
		$badge     = $get( 'badge' );
		$headline  = $get( 'headline' );
		$intro     = $get( 'intro' );
		$cta_label = $get( 'cta_label' );
		$cta_url   = $get( 'cta_url' );

		$wap_id = (int) $get( 'wap_id' );

		$stats = array();
		for ( $i = 1; $i <= 3; $i++ ) {
			$num = $get( 'stat' . $i . '_num' );
			$lab = $get( 'stat' . $i . '_label' );
			if ( '' !== $num || '' !== $lab ) {
				$stats[] = array( 'num' => $num, 'label' => $lab );
			}
		}

		$languages = self::parse_languages( (string) $get( 'languages' ) );

		$bio = $get( 'bio' );

		// Travel style: stored as a JSON array of up to three short entries
		// (v1.84.0+). Fall back to old rich-text for legacy data so nothing
		// an agent already wrote disappears.
		$style_raw  = $get( 'style' );
		$style_list = json_decode( (string) $style_raw, true );
		if ( ! is_array( $style_list ) ) {
			$legacy     = trim( wp_strip_all_tags( (string) $style_raw ) );
			$style_list = ( '' !== $legacy ) ? array( $legacy ) : array();
		}
		$style_list = array_values( array_filter( array_map( 'trim', $style_list ) ) );

		// Regions: stored as JSON array (v1.69.9+). Fall back to old rich-text for legacy data.
		$regions_raw    = $get( 'regions' );
		$regions_decoded = $regions_raw ? json_decode( $regions_raw, true ) : null;
		$regions_is_list = is_array( $regions_decoded );
		$regions         = $regions_raw; // kept for old-text fallback

		$email    = $get( 'email' );
		$phone    = $get( 'phone' );
		$whatsapp = $get( 'whatsapp' );
		$has_contact = ( $email || $phone || $whatsapp );

		$facebook_url  = $get( 'facebook_url' );
		$instagram_url = $get( 'instagram_url' );
		$linkedin_url  = $get( 'linkedin_url' );
		$youtube_url   = $get( 'youtube_url' );
		$has_social = ( $facebook_url || $instagram_url || $linkedin_url || $youtube_url );

		// Language code lookup (for the structured language display).
		$lang_code_map = array(
			'polski'       => 'PL',
			'angielski'    => 'GB',
			'ukraiński'    => 'UA',
			'rosyjski'     => 'RU',
			'niemiecki'    => 'DE',
			'francuski'    => 'FR',
			'hiszpański'   => 'ES',
			'włoski'       => 'IT',
			'turecki'      => 'TR',
			'arabski'      => 'AR',
			'chiński'      => 'ZH',
			'japoński'     => 'JA',
			'koreański'    => 'KO',
			'portugalski'  => 'PT',
			'niderlandzki' => 'NL',
			'szwedzki'     => 'SE',
		);

		ob_start();
		?>
		<div class="mwpa">

			<?php if ( $badge ) : ?>
				<div class="mwpa-page-header">
					<span class="mwpa-badge"><?php echo esc_html( $badge ); ?></span>
				</div>
			<?php endif; ?>

			<h1 class="mwpa-name"><?php echo esc_html( $name ); ?></h1>

			<section class="mwpa-hero">
				<div class="mwpa-photo">
					<?php if ( $photo ) : ?>
						<?php echo $photo; // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<?php else : ?>
						<span class="mwpa-photo-placeholder" aria-hidden="true">
							<svg viewBox="0 0 24 24"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5z"/></svg>
						</span>
					<?php endif; ?>
				</div>

				<div class="mwpa-info">
					<?php if ( $headline ) : ?>
						<p class="mwpa-headline"><?php echo esc_html( $headline ); ?></p>
					<?php endif; ?>

					<?php if ( $intro ) : ?>
						<p class="mwpa-intro"><?php echo esc_html( $intro ); ?></p>
					<?php endif; ?>

					<?php if ( $stats ) : ?>
						<div class="mwpa-stats">
							<?php foreach ( $stats as $s ) : ?>
								<div class="mwpa-stat">
									<span class="mwpa-stat-num"><?php echo esc_html( $s['num'] ); ?></span>
									<span class="mwpa-stat-label"><?php echo esc_html( $s['label'] ); ?></span>
								</div>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<?php if ( $wap_id ) : ?>
						<div class="mwpa-wap">
							<?php echo do_shortcode( '[wap_widget title="Umów darmową konsultację!" staff="' . esc_attr( $wap_id ) . '"]' ); ?>
						</div>
					<?php elseif ( $cta_label && $cta_url ) : ?>
						<p class="mwpa-hero-cta">
							<a class="mwpa-widget-btn" href="<?php echo esc_url( $cta_url ); ?>"<?php echo ( 0 === strpos( (string) $cta_url, 'mailto:' ) ) ? '' : ' target="_blank" rel="noopener"'; ?>>
								<svg class="mwpa-widget-btn-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
								<?php echo esc_html( $cta_label ); ?>
							</a>
						</p>
					<?php endif; ?>
				</div>
			</section>

			<div class="mwpa-grid">
				<div class="mwpa-main">
					<?php if ( $bio ) : ?>
						<div class="mwpa-card">
							<h2><?php esc_html_e( 'About me', 'multiwander-packages' ); ?></h2>
							<div class="mwpa-prose"><?php echo wp_kses_post( wpautop( $bio ) ); ?></div>
						</div>
					<?php endif; ?>

					<?php if ( $regions_is_list && ! empty( $regions_decoded ) ) : ?>
						<div class="mwpa-card mwpa-card--regions">
							<h2><?php echo esc_html( self::t( 'Moje regiony specjalizacji', 'My regions of expertise' ) ); ?></h2>
							<div class="mwpa-region-list">
								<?php foreach ( $regions_decoded as $entry ) :
									// Backward-compat: old entries are plain strings.
									if ( is_string( $entry ) ) {
										$rname = $entry; $rnote = ''; $rsub = ''; $rcountries = ''; $rtags = array();
									} else {
										$rname      = isset( $entry['name'] ) ? $entry['name'] : '';
										$rnote      = isset( $entry['note'] ) ? $entry['note'] : '';
										$rsub       = isset( $entry['subtitle'] ) ? $entry['subtitle'] : '';
										$rcountries = isset( $entry['countries'] ) ? $entry['countries'] : '';
										$rtags      = isset( $entry['tags'] ) ? $entry['tags'] : array();
									}
									if ( ! $rname ) continue;

									// Repair mojibake from a bad JSON round-trip (u0142 → ł).
									$rname = self::fix_unicode_escapes( $rname );
									$rsub  = self::fix_unicode_escapes( $rsub );
									$rnote = self::fix_unicode_escapes( $rnote );

									// Flags: explicit ISO codes if given, else auto-derive from the name.
									$flag_codes = self::region_flag_codes( $rcountries, $rname );

									// Tags: stored as an array, or a comma-separated string.
									if ( is_string( $rtags ) ) {
										$rtags = array_filter( array_map( 'trim', explode( ',', $rtags ) ) );
									} elseif ( ! is_array( $rtags ) ) {
										$rtags = array();
									}
									$rtags = array_map( array( __CLASS__, 'fix_unicode_escapes' ), $rtags );
								?>
									<div class="mwpa-region-item">
										<div class="mwpa-region-head">
											<?php if ( $flag_codes ) : ?>
												<span class="mwpa-region-flags">
													<?php foreach ( $flag_codes as $code ) : ?>
														<img class="mwpa-region-flag" src="<?php echo esc_url( 'https://flagcdn.com/w40/' . $code . '.png' ); ?>" alt="" width="28" height="19" loading="lazy">
													<?php endforeach; ?>
												</span>
											<?php endif; ?>
											<span class="mwpa-region-heading">
												<span class="mwpa-region-name"><?php echo esc_html( $rname ); ?></span>
												<?php if ( $rsub ) : ?>
													<span class="mwpa-region-subtitle"><?php echo esc_html( $rsub ); ?></span>
												<?php endif; ?>
											</span>
										</div>
										<?php if ( $rnote ) : ?>
											<p class="mwpa-region-desc"><?php echo esc_html( $rnote ); ?></p>
										<?php endif; ?>
										<?php if ( ! empty( $rtags ) ) : ?>
											<div class="mwpa-region-tags">
												<?php foreach ( $rtags as $tag ) : ?>
													<span class="mwpa-region-tag"><?php echo esc_html( $tag ); ?></span>
												<?php endforeach; ?>
											</div>
										<?php endif; ?>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					<?php elseif ( ! $regions_is_list && $regions ) : ?>
						<!-- Legacy rich-text regions (pre-v1.69.9) -->
						<div class="mwpa-card">
							<h2><?php echo esc_html( self::t( 'Moje regiony specjalizacji', 'My regions of expertise' ) ); ?></h2>
							<div class="mwpa-prose"><?php echo wp_kses_post( wpautop( $regions ) ); ?></div>
						</div>
					<?php endif; ?>

				</div>

				<aside class="mwpa-side">
					<?php if ( $has_contact ) : ?>
						<div class="mwpa-card">
							<h2><?php printf( esc_html( self::t( 'Kontakt z %s', 'Contact %s' ) ), esc_html( $name ) ); ?></h2>
							<?php if ( $email ) : ?>
								<a class="mwpa-contact" href="mailto:<?php echo esc_attr( $email ); ?>">
									<span class="mwpa-contact-ico">✉</span><span><?php echo esc_html( $email ); ?></span>
								</a>
								<?php
								// A mailto: link only works if the visitor's browser/OS
								// has a desktop email app configured — otherwise clicking it
								// silently does nothing. Show the address as plain, copyable
								// text so the visitor can still reach the agent, and offer the
								// inline "send a quick message" form below.
								?>
								<p class="mwpa-widget-email">
									<?php echo esc_html( self::t( 'lub e-mail:', 'or email:' ) ); ?>
									<a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
									<button type="button" class="mwpa-copy-btn" data-mwpa-copy="<?php echo esc_attr( $email ); ?>" aria-label="<?php echo esc_attr( self::t( 'Skopiuj adres e-mail', 'Copy email address' ) ); ?>">📋</button>
								</p>
								<?php self::render_inquiry_form( $uid, $name, 'profile' ); ?>
							<?php endif; ?>
							<?php if ( $phone ) : ?>
								<a class="mwpa-contact" href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ); ?>">
									<span class="mwpa-contact-ico">☎</span><span><?php echo esc_html( $phone ); ?></span>
								</a>
							<?php endif; ?>
							<?php if ( $whatsapp ) : ?>
								<?php $wa = ( 0 === strpos( $whatsapp, 'http' ) ) ? $whatsapp : 'https://wa.me/' . preg_replace( '/[^\d]/', '', $whatsapp ); ?>
								<a class="mwpa-contact" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener">
									<span class="mwpa-contact-ico">◍</span><span>WhatsApp</span>
								</a>
							<?php endif; ?>
							<?php if ( $has_social ) : ?>
							<div class="mwpa-social">
								<?php if ( $facebook_url ) : ?>
									<a class="mwpa-social-btn" href="<?php echo esc_url( $facebook_url ); ?>" target="_blank" rel="noopener" aria-label="Facebook">
										<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
									</a>
								<?php endif; ?>
								<?php if ( $instagram_url ) : ?>
									<a class="mwpa-social-btn" href="<?php echo esc_url( $instagram_url ); ?>" target="_blank" rel="noopener" aria-label="Instagram">
										<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
									</a>
								<?php endif; ?>
								<?php if ( $linkedin_url ) : ?>
									<a class="mwpa-social-btn" href="<?php echo esc_url( $linkedin_url ); ?>" target="_blank" rel="noopener" aria-label="LinkedIn">
										<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/></svg>
									</a>
								<?php endif; ?>
								<?php if ( $youtube_url ) : ?>
									<a class="mwpa-social-btn" href="<?php echo esc_url( $youtube_url ); ?>" target="_blank" rel="noopener" aria-label="YouTube">
										<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58 2.78 2.78 0 0 0 1.95 1.96C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.96-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon fill="#fff" points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/></svg>
									</a>
								<?php endif; ?>
							</div>
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<?php if ( $style_list ) : ?>
						<div class="mwpa-card">
							<h2><?php echo esc_html( self::t( 'Mój styl podróżowania', 'My travel style' ) ); ?></h2>
							<ul class="mwpa-tags">
								<?php foreach ( $style_list as $one ) : ?>
									<li class="mwpa-tag"><?php echo esc_html( $one ); ?></li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>

					<?php if ( $languages ) : ?>
						<div class="mwpa-card">
							<h2><?php echo esc_html( self::t( 'Języki, którymi mówię', 'Languages I speak' ) ); ?></h2>
							<div class="mwpa-lang-list">
								<?php foreach ( $languages as $lang ) :
									$lang_name  = isset( $lang['name'] ) ? $lang['name'] : '';
									$lang_level = isset( $lang['level'] ) ? $lang['level'] : '';
									if ( '' === $lang_name ) { continue; }
									$lkey      = function_exists( 'mb_strtolower' ) ? mb_strtolower( $lang_name, 'UTF-8' ) : strtolower( $lang_name );
									$lang_code = isset( $lang_code_map[ $lkey ] )
										? $lang_code_map[ $lkey ]
										: strtoupper( substr( $lang_name, 0, 2 ) );
								?>
								<div class="mwpa-lang-item">
									<span class="mwpa-lang-code"><?php echo esc_html( $lang_code ); ?></span>
									<div class="mwpa-lang-text">
										<span class="mwpa-lang-name"><?php echo esc_html( $lang_name ); ?></span>
										<?php if ( $lang_level ) : ?>
											<span class="mwpa-lang-level"><?php echo esc_html( $lang_level ); ?></span>
										<?php endif; ?>
									</div>
								</div>
							<?php endforeach; ?>
							</div>
						</div>
					<?php endif; ?>
				</aside>
			</div>

			<?php if ( $cta_url || $email || $whatsapp ) : ?>
				<?php
				$wa_url = '';
				if ( $whatsapp ) {
					$wa_url = ( 0 === strpos( $whatsapp, 'http' ) ) ? $whatsapp : 'https://wa.me/' . preg_replace( '/[^\d]/', '', $whatsapp );
				}
				?>
				<div class="mwpa-cta-banner">
					<h2 class="mwpa-cta-banner-title">
						<?php echo esc_html( self::t( 'Gotów na swoją następną przygodę?', 'Ready for your next adventure?' ) ); ?>
					</h2>
					<div class="mwpa-cta-banner-btns">
						<?php if ( $cta_url && $cta_label ) : ?>
							<a class="mwpa-btn mwpa-btn-banner" href="<?php echo esc_url( $cta_url ); ?>" target="_blank" rel="noopener">
								💬 <?php echo esc_html( $cta_label ); ?>
							</a>
						<?php elseif ( $email ) : ?>
							<a class="mwpa-btn mwpa-btn-banner" href="mailto:<?php echo esc_attr( $email ); ?>">
								✉ <?php printf( esc_html( self::t( 'Napisz do %s', 'Write to %s' ) ), esc_html( $name ) ); ?>
							</a>
						<?php endif; ?>
						<?php if ( $whatsapp ) : ?>
							<a class="mwpa-btn mwpa-btn-banner mwpa-btn-wa" href="<?php echo esc_url( $wa_url ); ?>" target="_blank" rel="noopener">
								📱 WhatsApp
							</a>
						<?php endif; ?>
					</div>
					<?php
					// If the banner button falls back to mailto: (no booking
					// link set), that button does nothing for visitors without a
					// mail app. Show the copyable address here too so they can
					// still reach the agent — the inline form lives in the
					// contact card above.
					if ( ! ( $cta_url && $cta_label ) && $email ) :
						?>
						<p class="mwpa-cta-banner-email">
							<?php echo esc_html( self::t( 'lub e-mail:', 'or email:' ) ); ?>
							<a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
							<button type="button" class="mwpa-copy-btn" data-mwpa-copy="<?php echo esc_attr( $email ); ?>" aria-label="<?php echo esc_attr( self::t( 'Skopiuj adres e-mail', 'Copy email address' ) ); ?>">📋</button>
						</p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}
}
