<?php
/**
 * Booking registration — the "official booking paper" an agent sends to a
 * client once the client has said, on the phone, that they want to book.
 *
 * Flow:
 *  1. In the back office the agent enters a Travel Compositor / Holiday Package
 *     ID and gets a private link (this page), which they send to the client.
 *  2. The client opens the link, reviews the tour, fills in the data the
 *     agency needs to make the booking, accepts both tour operators' terms,
 *     and submits.
 *  3. The completed registration is emailed to the agent and to
 *     info@multiwander.com as the record of consent.
 *
 * The page is rendered entirely by PHP from the ID in the URL
 * (?mwp_booking=<id>&a=<agentId>), carries a noindex robots header, and is not
 * linked from anywhere, so it never appears in a search engine. It is reached
 * only by someone who has the link.
 *
 * NOTE: legal wording and the terms & conditions links are placeholders for
 * now — to be finalised with a lawyer. The layout and the data flow are built
 * so that only the text needs swapping later.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Booking {

	/** Query var that triggers this page. */
	const QV = 'mwp_booking';

	/** Where every completed registration is always also sent. */
	const AGENCY_EMAIL = 'info@multiwander.com';

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render' ) );
	}

	/**
	 * If the current request is a booking-registration link, render the
	 * standalone page and stop WordPress from loading the normal theme.
	 *
	 * @return void
	 */
	public static function maybe_render() {
		if ( ! isset( $_GET[ self::QV ] ) || '' === $_GET[ self::QV ] ) {
			return;
		}

		$id    = function_exists( 'mwp_extract_id' )
			? mwp_extract_id( sanitize_text_field( wp_unslash( $_GET[ self::QV ] ) ) )
			: preg_replace( '/[^0-9A-Za-z_-]/', '', (string) wp_unslash( $_GET[ self::QV ] ) );
		$agent = isset( $_GET['a'] ) ? absint( $_GET['a'] ) : 0;
		$lang  = ( isset( $_GET['lang'] ) && 'en' === $_GET['lang'] ) ? 'en' : 'pl';

		// Keep this page out of search engines and caches.
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow', true );

		list( $data ) = MWP_Admin::load_package( $id, $lang );

		if ( ! $id || ! $data || empty( $data['title'] ) ) {
			self::render_invalid( $lang );
			exit;
		}

		self::render_page( $data, $id, $agent, $lang );
		exit;
	}

	/**
	 * Pull just the handful of tour facts this page shows into a flat array.
	 *
	 * @param array  $data Normalised package data (see MWP_Parser).
	 * @param string $lang 'pl' | 'en'
	 * @return array
	 */
	protected static function summary( $data, $lang ) {
		$title = ! empty( $data['large_title'] ) ? $data['large_title'] : ( isset( $data['title'] ) ? $data['title'] : '' );

		$stops = array();
		foreach ( (array) ( isset( $data['destinations'] ) ? $data['destinations'] : array() ) as $d ) {
			if ( ! empty( $d['name'] ) ) {
				$stops[] = $d['name'];
			}
		}
		$route = implode( ' – ', array_slice( $stops, 0, 6 ) );

		$nights = isset( $data['duration']['nights'] ) ? (int) $data['duration']['nights'] : 0;
		$days   = isset( $data['duration']['days'] ) ? (int) $data['duration']['days'] : 0;
		if ( 'en' === $lang ) {
			$dur = $days ? sprintf( '%d days / %d nights', $days, $nights ) : '';
		} else {
			$dur = $days ? sprintf( '%d dni / %d nocy', $days, $nights ) : '';
		}

		$price = '';
		if ( function_exists( 'mwp_format_price' ) ) {
			$cur = ( 'en' === $lang ) ? 'eur' : 'pln';
			$pf  = mwp_format_price( (array) ( isset( $data['price'] ) ? $data['price'] : array() ), $lang, $cur );
			$price = ! empty( $pf['value'] ) ? trim( $pf['value'] . ' ' . $pf['symbol'] ) : '';
		}

		$hero = '';
		if ( ! empty( $data['hero_image'] ) ) {
			$hero = (string) $data['hero_image'];
		} elseif ( ! empty( $data['gallery'][0] ) ) {
			$hero = (string) $data['gallery'][0];
		}

		$desc = wp_strip_all_tags( (string) ( isset( $data['description'] ) ? $data['description'] : '' ) );
		$desc = wp_trim_words( $desc, 60, '…' );

		return compact( 'title', 'route', 'dur', 'price', 'hero', 'desc' );
	}

	/**
	 * Tiny PL/EN helper for this page's own chrome.
	 *
	 * @param string $lang
	 * @param string $pl
	 * @param string $en
	 * @return string
	 */
	protected static function t( $lang, $pl, $en ) {
		return ( 'en' === $lang ) ? $en : $pl;
	}

	/**
	 * The standalone booking-registration page. STEP 1: tour review summary
	 * only — the data form and the submit flow come in the next steps.
	 *
	 * @param array  $data  Package data.
	 * @param string $id    Package ID (kept for the form action later).
	 * @param int    $agent Agent user ID from the link (used for the email later).
	 * @param string $lang  'pl' | 'en'
	 * @return void
	 */
	protected static function render_page( $data, $id, $agent, $lang ) {
		$s = self::summary( $data, $lang );

		$doc_title = self::t( $lang, 'Zgłoszenie rezerwacyjne', 'Booking registration' ) . ' — ' . $s['title'];

		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!doctype html>
<html lang="<?php echo esc_attr( $lang ); ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<title><?php echo esc_html( $doc_title ); ?></title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600&family=Inter:wght@400;500;600;700&display=swap">
	<style>
		:root { --navy:#1a2e4a; --teal:#17b3a3; --ink:#1f2733; --muted:#5b6678; --line:#e6e8ec; --bg:#f4f7f9; }
		* { box-sizing: border-box; }
		body { margin:0; background:var(--bg); color:var(--ink); font-family:Inter,system-ui,sans-serif; line-height:1.55; }
		.wrap { max-width: 760px; margin: 0 auto; padding: 28px 18px 60px; }
		.brand { font-weight:700; letter-spacing:.3px; color:var(--navy); font-size:1.05rem; }
		.eyebrow { display:inline-block; margin:18px 0 6px; padding:5px 12px; border-radius:999px; background:rgba(23,179,163,.12); color:#0f8f82; font-size:.78rem; font-weight:700; text-transform:uppercase; letter-spacing:.5px; }
		h1 { font-family:Fraunces,Georgia,serif; font-weight:600; font-size:1.9rem; line-height:1.2; margin:4px 0 14px; color:var(--navy); }
		.card { background:#fff; border:1px solid var(--line); border-radius:16px; overflow:hidden; box-shadow:0 6px 22px rgba(20,30,50,.06); }
		.hero { width:100%; height:260px; object-fit:cover; display:block; background:#dfe6ea; }
		.card-body { padding:22px 24px; }
		.facts { display:flex; flex-wrap:wrap; gap:10px 22px; margin:0 0 14px; padding:0; list-style:none; }
		.facts li { font-size:.92rem; color:var(--muted); }
		.facts strong { color:var(--ink); font-weight:600; }
		.price { font-size:1.3rem; font-weight:700; color:var(--navy); }
		.price small { font-size:.8rem; font-weight:500; color:var(--muted); }
		.desc { color:#3b4452; font-size:.98rem; margin:14px 0 0; }
		.ref { margin-top:10px; font-size:.82rem; color:var(--muted); }
		.soon { margin-top:22px; padding:16px 18px; border:1px dashed var(--line); border-radius:12px; background:#fff; color:var(--muted); font-size:.9rem; }
		.foot { margin-top:26px; text-align:center; color:var(--muted); font-size:.8rem; }
		@media (max-width:560px){ .hero{height:190px;} h1{font-size:1.5rem;} }
	</style>
</head>
<body>
	<div class="wrap">
		<div class="brand">MultiWander</div>
		<span class="eyebrow"><?php echo esc_html( self::t( $lang, 'Zgłoszenie rezerwacyjne', 'Booking registration' ) ); ?></span>
		<h1><?php echo esc_html( $s['title'] ); ?></h1>

		<div class="card">
			<?php if ( $s['hero'] ) : ?>
				<img class="hero" src="<?php echo esc_url( $s['hero'] ); ?>" alt="">
			<?php endif; ?>
			<div class="card-body">
				<ul class="facts">
					<?php if ( $s['route'] ) : ?>
						<li><strong><?php echo esc_html( self::t( $lang, 'Trasa', 'Route' ) ); ?>:</strong> <?php echo esc_html( $s['route'] ); ?></li>
					<?php endif; ?>
					<?php if ( $s['dur'] ) : ?>
						<li><strong><?php echo esc_html( self::t( $lang, 'Czas trwania', 'Duration' ) ); ?>:</strong> <?php echo esc_html( $s['dur'] ); ?></li>
					<?php endif; ?>
				</ul>
				<?php if ( $s['price'] ) : ?>
					<div class="price">
						<?php echo esc_html( $s['price'] ); ?>
						<small><?php echo esc_html( self::t( $lang, 'za osobę', 'per person' ) ); ?></small>
					</div>
				<?php endif; ?>
				<?php if ( $s['desc'] ) : ?>
					<p class="desc"><?php echo esc_html( $s['desc'] ); ?></p>
				<?php endif; ?>
				<p class="ref"><?php echo esc_html( self::t( $lang, 'Numer oferty', 'Offer no.' ) ); ?>: <?php echo esc_html( $id ); ?></p>
			</div>
		</div>

		<div class="soon">
			<?php echo esc_html( self::t( $lang,
				'Formularz zgłoszeniowy pojawi się tutaj w następnym kroku.',
				'The registration form will appear here in the next step.'
			) ); ?>
		</div>

		<div class="foot">
			MultiWander &nbsp;·&nbsp; <?php echo esc_html( self::t( $lang, 'Organizator: Momira Travel', 'Tour operator: Momira Travel' ) ); ?>
		</div>
	</div>
</body>
</html>
		<?php
	}

	/**
	 * Shown when the link has no valid package ID behind it.
	 *
	 * @param string $lang
	 * @return void
	 */
	protected static function render_invalid( $lang ) {
		status_header( 404 );
		header( 'Content-Type: text/html; charset=utf-8' );
		$msg = self::t( $lang,
			'Ten link rezerwacyjny jest nieprawidłowy lub wygasł. Skontaktuj się ze swoim doradcą podróży.',
			'This booking link is invalid or has expired. Please contact your travel advisor.'
		);
		echo '<!doctype html><html lang="' . esc_attr( $lang ) . '"><head><meta charset="utf-8">'
			. '<meta name="viewport" content="width=device-width,initial-scale=1">'
			. '<meta name="robots" content="noindex, nofollow">'
			. '<title>MultiWander</title></head>'
			. '<body style="font-family:system-ui,sans-serif;background:#f4f7f9;color:#1f2733;margin:0;">'
			. '<div style="max-width:520px;margin:12vh auto;padding:28px 22px;text-align:center;">'
			. '<div style="font-weight:700;color:#1a2e4a;margin-bottom:10px;">MultiWander</div>'
			. '<p style="color:#5b6678;">' . esc_html( $msg ) . '</p></div></body></html>';
	}
}
