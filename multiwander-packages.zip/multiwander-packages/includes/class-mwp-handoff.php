<?php
/**
 * The handover into the booking engine.
 *
 * WHAT THIS SOLVES
 * ----------------
 * The visitor picks a start date and a party size on our page. Sending them on
 * with those values in the query string does nothing: the engine's idea page
 * ignores query parameters (tested — it comes up with its own defaults), and
 * travel-map.xhtml?tripId=N cannot be linked to either, because that number is
 * a counter inside the visitor's own session on the engine, not an address.
 *
 * HOW THE ENGINE ACTUALLY WANTS TO BE ENTERED
 * -------------------------------------------
 * Observed on a live Travel Compositor white-label that does exactly this
 * (suntrips.de, whose engine sits on kombireisen.suntrips.de): their WordPress
 * theme has a one-page script that renders a self-submitting form and POSTs it
 * to their engine at
 *
 *     POST /travel-map.xhtml?tripId=0&tripType=MULTI&directSubmit=true
 *
 * tripId=0 with directSubmit=true means "build a new trip out of the fields in
 * this POST". The engine creates it, assigns the real tripId, and the visitor
 * lands on the map with their dates and party already applied. No JSF view
 * state is involved, so this is a plain form post — which is why it can be sent
 * from another page at all.
 *
 * The reason it works for them and could not have worked for us before is the
 * domain: their engine is on suntrips.de, so the session cookie the POST
 * creates belongs to the same site. book.multiwander.com now gives MultiWander
 * the same arrangement.
 *
 * WHAT IS STILL A GUESS
 * ---------------------
 * The names of the POSTed fields. Their bridge is server-side PHP, so its
 * output cannot be read from outside, and the page submits itself before the
 * markup can be inspected. The names below are taken from the parameters their
 * own form collects, which is the best available evidence; every one of them
 * can be corrected in a single place — the mwp_handoff_fields filter — the
 * moment a real POST body is seen.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Handoff {

	const ACTION = 'mwp_handoff';

	public static function init() {
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'render' ) );
		add_action( 'admin_post_nopriv_' . self::ACTION, array( __CLASS__, 'render' ) );
	}

	/**
	 * The URL our Search button points at.
	 *
	 * @param string $package_id Travel Compositor package ID.
	 * @param string $lang       Language slug.
	 * @return string
	 */
	public static function url( $package_id, $lang = 'pl' ) {
		return add_query_arg(
			array(
				'action' => self::ACTION,
				'id'     => rawurlencode( (string) $package_id ),
				'lang'   => rawurlencode( (string) $lang ),
			),
			admin_url( 'admin-post.php' )
		);
	}

	/**
	 * Where the POST goes.
	 *
	 * @return string
	 */
	public static function endpoint() {
		$base = untrailingslashit( (string) apply_filters( 'mwp_booking_base', MWP_BOOKING_BASE ) );

		return apply_filters(
			'mwp_handoff_endpoint',
			$base . '/travel-map.xhtml?tripId=0&tripType=MULTI&directSubmit=true'
		);
	}

	/**
	 * Render the self-submitting form.
	 *
	 * Deliberately a real form rather than a redirect: the engine wants a POST,
	 * and a POST is the one thing a redirect cannot produce. The form submits
	 * itself on load, so the visitor sees a moment of "taking you to the
	 * booking system" and then the map — and with JavaScript off there is a
	 * button, rather than a dead end.
	 *
	 * @return void
	 */
	public static function render() {
		$id   = isset( $_GET['id'] ) ? preg_replace( '/\D/', '', wp_unslash( $_GET['id'] ) ) : '';
		$lang = isset( $_GET['lang'] ) && 'en' === $_GET['lang'] ? 'en' : 'pl';

		if ( '' === $id ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}

		// Only values this site itself put in the link are trusted; everything
		// is normalised before it is echoed into a form field.
		$date     = isset( $_GET['date'] ) ? sanitize_text_field( wp_unslash( $_GET['date'] ) ) : '';
		$adults   = isset( $_GET['adults'] ) ? max( 1, (int) $_GET['adults'] ) : 2;
		$children = isset( $_GET['children'] ) ? max( 0, (int) $_GET['children'] ) : 0;
		$rooms    = isset( $_GET['rooms'] ) ? max( 1, (int) $_GET['rooms'] ) : 1;
		$dist     = isset( $_GET['distribution'] ) ? sanitize_text_field( wp_unslash( $_GET['distribution'] ) ) : '';
		$ages     = isset( $_GET['ages'] ) ? preg_replace( '/[^0-9,\.]/', '', wp_unslash( $_GET['ages'] ) ) : '';

		$limits   = mwp_booking_limits();
		$adults   = min( $adults, $limits['max_pax'] );
		$children = min( $children, max( 0, $limits['max_pax'] - $adults ) );
		$rooms    = min( $rooms, $limits['max_rooms'] );

		// The engine's own date format in the observed bridge is DD.MM.YYYY,
		// not the ISO the date field produces.
		$pretty_date = '';
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m ) ) {
			$pretty_date = $m[3] . '.' . $m[2] . '.' . $m[1];
		}

		if ( '' === $dist ) {
			$dist = $children > 0 ? $adults . '-' . $children : (string) $adults;
		}

		$fields = apply_filters(
			'mwp_handoff_fields',
			array(
				'idea_id'           => $id,
				'departure_date'    => $pretty_date ? $pretty_date : $date,
				'distribution_code' => $adults . '-' . $children,
				'distribution'      => $dist,
				'adults'            => (string) $adults,
				'children'          => (string) $children,
				'rooms'             => (string) $rooms,
				'childrenAges'      => $ages,
				'triptype'          => 'MULTI',
				'language'          => $lang,
				'tab'               => 'buchung',
			),
			array(
				'id'       => $id,
				'lang'     => $lang,
				'date'     => $date,
				'adults'   => $adults,
				'children' => $children,
				'rooms'    => $rooms,
				'ages'     => $ages,
			)
		);

		$endpoint = self::endpoint();

		$waiting = ( 'en' === $lang )
			? 'Taking you to the booking system…'
			: 'Przechodzimy do systemu rezerwacji…';
		$button = ( 'en' === $lang ) ? 'Continue' : 'Kontynuuj';

		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!doctype html>
<html lang="<?php echo esc_attr( $lang ); ?>">
<head>
<meta charset="utf-8">
<meta name="robots" content="noindex,nofollow">
<title><?php echo esc_html( $waiting ); ?></title>
<style>
	body { margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center;
		font-family: 'Jost', system-ui, sans-serif; color: #1f2937; background: #fff; }
	.mwp-wait { text-align: center; }
	.mwp-spin { width: 34px; height: 34px; margin: 0 auto 16px; border-radius: 50%;
		border: 3px solid #d7e6e4; border-top-color: #17a398; animation: mwp-turn 1s linear infinite; }
	@keyframes mwp-turn { to { transform: rotate(360deg); } }
	button { margin-top: 14px; padding: 12px 22px; border: 0; border-radius: 8px;
		background: #17a398; color: #fff; font: inherit; cursor: pointer; }
</style>
</head>
<body>
	<form id="mwp-go" method="post" action="<?php echo esc_url( $endpoint ); ?>">
		<?php foreach ( $fields as $name => $value ) : ?>
			<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
		<?php endforeach; ?>

		<div class="mwp-wait">
			<div class="mwp-spin" aria-hidden="true"></div>
			<p><?php echo esc_html( $waiting ); ?></p>
			<noscript><button type="submit"><?php echo esc_html( $button ); ?></button></noscript>
		</div>
	</form>
	<script>document.getElementById('mwp-go').submit();</script>
</body>
</html>
		<?php
		exit;
	}
}
