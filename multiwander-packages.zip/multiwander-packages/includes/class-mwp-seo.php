<?php
/**
 * SEO for package pages.
 *
 * Yoast handles titles, canonicals and sitemaps perfectly well on its own.
 * What it cannot do is describe a travel package to a search engine — that
 * needs schema.org markup built from the actual package data, which is what
 * this class emits.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_SEO {

	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'json_ld' ), 20 );
		add_action( 'wp_footer', array( __CLASS__, 'faq_json_ld' ), 20 );
	}

	/**
	 * Turn a hand-written FAQ block into FAQPage structured data.
	 *
	 * The theme's country pages already mark FAQs up as
	 *
	 *     <div class="faq-item">
	 *       <h3 class="faq-question">…</h3>
	 *       <p class="faq-answer">…</p>
	 *     </div>
	 *
	 * so the same HTML pasted onto a package page is picked up automatically —
	 * no shortcode, no second place to maintain the questions.
	 *
	 * Worth knowing: Google now shows FAQ rich results only for a narrow set of
	 * authoritative sites, so treat this as machine-readability for AI answer
	 * engines and future crawlers rather than a guaranteed search feature. It
	 * costs nothing and the questions are already written.
	 *
	 * Emitted in the footer because it reads the rendered page content.
	 *
	 * @return void
	 */
	public static function faq_json_ld() {
		if ( ! is_singular( 'page' ) ) {
			return;
		}

		$post = get_post();
		if ( ! $post || false === strpos( (string) $post->post_content, 'faq-question' ) ) {
			return;
		}

		$pairs = self::extract_faqs( $post->post_content );
		if ( count( $pairs ) < 2 ) {
			// One lone question is not an FAQ page; don't claim it is.
			return;
		}

		$entities = array();
		foreach ( $pairs as $pair ) {
			$entities[] = array(
				'@type'          => 'Question',
				'name'           => $pair['q'],
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => $pair['a'],
				),
			);
		}

		echo "\n" . '<script type="application/ld+json">' .
			wp_json_encode(
				array(
					'@context'   => 'https://schema.org',
					'@type'      => 'FAQPage',
					'@id'        => get_permalink( $post ) . '#faq',
					'mainEntity' => $entities,
				),
				JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
			) .
			"</script>\n";
	}

	/**
	 * Pull question/answer pairs out of the theme's FAQ markup.
	 *
	 * @param string $html Page content.
	 * @return array<int,array{q:string,a:string}>
	 */
	protected static function extract_faqs( $html ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return array();
		}

		$html = do_shortcode( $html );

		$doc = new DOMDocument();
		// Suppress the warnings malformed page HTML would otherwise raise.
		$previous = libxml_use_internal_errors( true );
		$doc->loadHTML(
			'<?xml encoding="UTF-8"><div>' . $html . '</div>',
			LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
		);
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		$xpath = new DOMXPath( $doc );

		$questions = $xpath->query( "//*[contains(concat(' ', normalize-space(@class), ' '), ' faq-question ')]" );
		$answers   = $xpath->query( "//*[contains(concat(' ', normalize-space(@class), ' '), ' faq-answer ')]" );

		if ( ! $questions || ! $answers ) {
			return array();
		}

		$out = array();
		$n   = min( $questions->length, $answers->length );

		for ( $i = 0; $i < $n; $i++ ) {
			$q = trim( preg_replace( '/\s+/u', ' ', $questions->item( $i )->textContent ) );
			$a = trim( preg_replace( '/\s+/u', ' ', $answers->item( $i )->textContent ) );

			if ( '' !== $q && '' !== $a ) {
				$out[] = array(
					'q' => $q,
					'a' => $a,
				);
			}
		}

		return $out;
	}

	/**
	 * Emit TouristTrip structured data on package pages.
	 *
	 * TouristTrip is the closest schema.org type to a multi-stop holiday
	 * package: it carries the price offer, the trip length and the places
	 * visited, which is what Google needs to show anything richer than a
	 * plain blue link.
	 *
	 * @return void
	 */
	public static function json_ld() {
		if ( ! is_singular( 'page' ) ) {
			return;
		}

		$post_id = get_queried_object_id();
		if ( ! $post_id || ! get_post_meta( $post_id, MWP_META_ID, true ) ) {
			return;
		}

		$d = MWP_Sync::get_data( $post_id );
		if ( ! $d ) {
			return;
		}

		$lang = mwp_current_lang();

		$schema = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'TouristTrip',
			'@id'         => get_permalink( $post_id ) . '#trip',
			'name'        => get_the_title( $post_id ),
			'url'         => get_permalink( $post_id ),
			'description' => self::plain_description( $d, 300 ),
			'provider'    => array(
				'@type' => 'TravelAgency',
				'name'  => get_bloginfo( 'name' ),
				'url'   => home_url( '/' ),
			),
		);

		$hero = MWP_Frontend::hero_url( $post_id, $d );
		if ( $hero ) {
			$schema['image'] = $hero;
		}

		// ISO 8601 duration — "P13D" for a thirteen-day trip.
		if ( $d['duration']['days'] > 0 ) {
			$schema['itinerary']['@type'] = 'ItemList';
			$schema['subjectOf']          = array(
				'@type' => 'CreativeWork',
				'about' => sprintf( '%d days', $d['duration']['days'] ),
			);
			$schema['duration'] = 'P' . (int) $d['duration']['days'] . 'D';
		}

		// The places visited, in order.
		if ( $d['destinations'] ) {
			$elements = array();
			$position = 1;
			foreach ( $d['destinations'] as $stop ) {
				if ( '' === $stop['name'] ) {
					continue;
				}
				$place = array(
					'@type' => 'City',
					'name'  => $stop['name'],
				);
				if ( $stop['country'] ) {
					$place['containedInPlace'] = array(
						'@type' => 'Country',
						'name'  => $stop['country'],
					);
				}
				$elements[] = array(
					'@type'    => 'ListItem',
					'position' => $position++,
					'item'     => $place,
				);
			}
			if ( $elements ) {
				$schema['itinerary'] = array(
					'@type'           => 'ItemList',
					'numberOfItems'   => count( $elements ),
					'itemListElement' => $elements,
				);
			}
		}

		// Price. Displayed in PLN on Polish pages, so advertise the same
		// currency the visitor actually sees — a mismatch between the markup
		// and the page is exactly what triggers a structured-data penalty.
		$price = mwp_format_price( $d['price'], $lang );
		if ( null !== $d['price']['amount'] ) {
			$amount   = $d['price']['amount'];
			$currency = $d['price']['currency'];

			if ( ! empty( $price['converted'] ) && function_exists( 'get_eur_to_pln_exchange_rate' ) ) {
				$rate = (float) get_eur_to_pln_exchange_rate();
				if ( $rate > 0 ) {
					$amount   = round( $amount * $rate );
					$currency = 'PLN';
				}
			}

			$offer = array(
				'@type'         => 'Offer',
				'price'         => (string) round( $amount, 2 ),
				'priceCurrency' => $currency,
				'availability'  => $d['active']
					? 'https://schema.org/InStock'
					: 'https://schema.org/OutOfStock',
				'url'           => get_permalink( $post_id ),
			);

			// Prices are converted at render time and TC pricing moves, so
			// don't claim a validity longer than the next sync realistically is.
			$offer['priceValidUntil'] = gmdate( 'Y-m-d', time() + 30 * DAY_IN_SECONDS );

			/*
			 * When a trip only runs on set dates, say so.
			 *
			 * A Nile cruise that sails on Fridays is not "available now" in
			 * the way a dynamic package is, and a search engine shown the
			 * window rather than nothing can present the trip honestly. These
			 * are the same dates the calendar offers, so the page, the picker
			 * and the structured data cannot disagree.
			 */
			if ( empty( $d['departures']['is_empty'] ) && ! empty( $d['departures']['dates'] ) ) {
				$dates = (array) $d['departures']['dates'];

				$offer['availabilityStarts'] = (string) reset( $dates );
				$offer['availabilityEnds']   = (string) end( $dates );
			}

			$schema['offers'] = $offer;
		}

		echo "\n<!-- MultiWander Packages -->\n";
		echo '<script type="application/ld+json">' .
			wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) .
			"</script>\n";
	}

	/**
	 * Package description as plain text, trimmed to a length.
	 *
	 * @param array $data  Payload.
	 * @param int   $chars Maximum characters.
	 * @return string
	 */
	public static function plain_description( array $data, $chars = 155 ) {
		$text = isset( $data['description'] ) ? $data['description'] : '';
		$text = wp_strip_all_tags( $text, true );
		$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
		$text = preg_replace( '/\s+/u', ' ', $text );
		$text = trim( $text );

		if ( '' === $text ) {
			return '';
		}

		if ( function_exists( 'mb_strlen' ) ? mb_strlen( $text ) <= $chars : strlen( $text ) <= $chars ) {
			return $text;
		}

		$cut = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, $chars ) : substr( $text, 0, $chars );

		// Trim back to the last word so the description doesn't end mid-word.
		$space = strrpos( $cut, ' ' );
		if ( false !== $space && $space > $chars * 0.6 ) {
			$cut = substr( $cut, 0, $space );
		}

		return rtrim( $cut, " ,.;:–-" ) . '…';
	}

	/**
	 * Cut a string to a character limit at the last word boundary.
	 *
	 * Used for the title and the meta description: both are shown truncated by
	 * the search engine anyway, and a clean break reads far better than one in
	 * the middle of a word.
	 *
	 * @param string $text  Text.
	 * @param int    $limit Maximum characters.
	 * @return string
	 */
	public static function shorten( $text, $limit ) {
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $text ) : strlen( $text );
		if ( $length <= $limit ) {
			return $text;
		}

		$cut   = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, $limit ) : substr( $text, 0, $limit );
		$space = strrpos( $cut, ' ' );

		if ( false !== $space && $space > $limit * 0.6 ) {
			$cut = substr( $cut, 0, $space );
		}

		return rtrim( $cut, " ,.;:–-|" );
	}

	/**
	 * Did this plugin write the value that is already there?
	 *
	 * Anything written from now on carries a flag. For pages synced before the
	 * flag existed, the test is whether the stored value still opens with the
	 * text it was generated from — a human-written title or description will
	 * not. Getting this wrong in the cautious direction only means an old page
	 * keeps an over-long title until an editor changes it.
	 *
	 * @param int    $post_id Post.
	 * @param string $flag    Meta key holding the flag.
	 * @param string $current Stored value.
	 * @param string $source  Text it would have been generated from.
	 * @return bool
	 */
	protected static function is_ours( $post_id, $flag, $current, $source ) {
		if ( get_post_meta( $post_id, $flag, true ) ) {
			return true;
		}

		$source = trim( (string) $source );
		if ( '' === $source ) {
			return false;
		}

		$head = function_exists( 'mb_substr' ) ? mb_substr( $source, 0, 24 ) : substr( $source, 0, 24 );

		return 0 === strpos( trim( (string) $current ), $head );
	}

	/**
	 * Write an SEO title for a freshly synced package.
	 *
	 * Defensive, not decorative: the live site was serving "MultiWander" as
	 * the <title> of every package page — the site name alone, with no page
	 * name — because Yoast's title template for Pages was not producing one.
	 * Google uses <title> as the clickable headline, so every package page
	 * would have competed in search results as the same identical blue link.
	 *
	 * Writing an explicit per-page title makes the plugin independent of that
	 * template. A title an editor has written by hand is never overwritten.
	 *
	 * @param int    $post_id Post.
	 * @param array  $data    Payload.
	 * @param string $lang    Language slug.
	 * @return void
	 */
	public static function maybe_set_title( $post_id, array $data, $lang = 'pl' ) {
		$existing = get_post_meta( $post_id, '_yoast_wpseo_title', true );

		// An editor's own title is never touched. One this plugin wrote is
		// rewritten, so a change to the length rules reaches the pages that
		// were synced under the old ones instead of only new packages.
		if ( $existing && ! self::is_ours( $post_id, '_mwp_seo_title_auto', $existing, $data['title'] ) ) {
			return;
		}

		$en    = ( 'en' === $lang );
		$title = trim( $data['title'] );
		if ( '' === $title ) {
			return;
		}

		// A short qualifier helps the result stand out without pushing the
		// title past the ~60 characters Google will actually show.
		$qualifier = '';
		if ( $data['duration']['days'] ) {
			$qualifier = sprintf( $en ? '%d days' : '%d dni', $data['duration']['days'] );
		}

		$brand = get_bloginfo( 'name' );

		// Google shows about sixty characters and cuts the rest with an
		// ellipsis, so the title is built up piece by piece and a piece is
		// only added while the whole thing still fits. Anything longer is not
		// a longer title — it is a truncated one.
		$limit = (int) apply_filters( 'mwp_seo_title_length', 60 );

		$fits = function ( $candidate ) use ( $limit ) {
			$length = function_exists( 'mb_strlen' ) ? mb_strlen( $candidate ) : strlen( $candidate );
			return $length <= $limit;
		};

		// The trip name itself comes first, shortened at a word boundary if it
		// alone is over the limit.
		$seo_title = $fits( $title ) ? $title : self::shorten( $title, $limit );

		foreach ( array( $qualifier, $brand ) as $piece ) {
			if ( ! $piece ) {
				continue;
			}
			$candidate = $seo_title . ' | ' . $piece;
			if ( $fits( $candidate ) ) {
				$seo_title = $candidate;
			}
		}

		update_post_meta( $post_id, '_yoast_wpseo_title', $seo_title );
		update_post_meta( $post_id, '_mwp_seo_title_auto', 1 );
	}

	/**
	 * Are these the same words, ignoring case?
	 *
	 * @param string $a One.
	 * @param string $b The other.
	 * @return bool
	 */
	protected static function same_words( $a, $b ) {
		$fold = function ( $text ) {
			$text = trim( preg_replace( '/\s+/u', ' ', (string) $text ) );
			return function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
		};

		return $fold( $a ) === $fold( $b );
	}

	/**
	 * Set Yoast's focus keyphrase from the package title.
	 *
	 * A keyphrase is not a title: Yoast scores a long one badly and its whole
	 * analysis stops being useful. So the core of the title is used — the part
	 * before the colon, which on these packages is the actual subject
	 * ("Wietnam & Kambodża: od Hanoi po Angkor Wat" gives "Wietnam Kambodża").
	 * Where there is no colon, the first few words are taken instead.
	 *
	 * Never overwrites a keyphrase an editor has set by hand.
	 *
	 * @param int    $post_id Post.
	 * @param array  $data    Payload.
	 * @param string $lang    Language slug.
	 * @return void
	 */
	public static function maybe_set_focus_keyphrase( $post_id, array $data, $lang = 'pl' ) {
		$existing = (string) get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );

		$title = trim( $data['title'] );
		if ( '' === $title ) {
			return;
		}

		// Everything before the first colon, dash or pipe is the subject.
		$core = preg_split( '/\s*[:|–—-]\s*/u', $title, 2 );
		$core = trim( $core[0] );

		if ( '' === $core ) {
			$core = $title;
		}

		// "Wietnam & Kambodża" -> "Wietnam Kambodża": ampersands and stray
		// punctuation only dilute the match.
		$core = str_replace( array( '&', '+' ), ' ', $core );
		$core = preg_replace( '/[^\p{L}\p{N}\s]/u', '', $core );
		$core = trim( preg_replace( '/\s+/u', ' ', $core ) );

		// Drop a leading trip length. "11 Days Jewels of Thailand" is searched
		// for as "Jewels of Thailand"; nobody types the day count.
		$core = preg_replace(
			'/^\d+\s+(days?|dni|dnia|nights?|nocy|noce)\s+/iu',
			'',
			$core
		);

		// Keep it to a phrase. Yoast's own guidance is roughly four words.
		$words = preg_split( '/\s+/u', trim( $core ) );
		if ( count( $words ) > 4 ) {
			$words = array_slice( $words, 0, 4 );
		}

		// Never end on a connecting word — truncating "Jewels of Thailand" to
		// "Jewels of" leaves a keyphrase that matches nothing.
		$connectors = array(
			'of', 'the', 'and', 'to', 'from', 'in', 'with', 'a', 'an', 'for', 'by',
			'od', 'do', 'po', 'przez', 'i', 'w', 'na', 'z', 'za', 'oraz', 'ze',
		);
		while ( $words && in_array( mb_strtolower( end( $words ) ), $connectors, true ) ) {
			array_pop( $words );
		}

		$core = implode( ' ', $words );

		if ( '' === $core ) {
			return;
		}

		// Lower case throughout. Yoast matches the keyphrase against the page
		// case-insensitively, so capitals buy nothing — but they do make the
		// keyphrase read as a proper noun in the editor and invite someone to
		// "correct" it, and they make two otherwise identical keyphrases look
		// different in a report. mb_strtolower, not strtolower: the Polish
		// titles carry ą, ć, ż and the rest, which the byte version mangles.
		$core = function_exists( 'mb_strtolower' )
			? mb_strtolower( $core, 'UTF-8' )
			: strtolower( $core );

		$keyphrase = (string) apply_filters( 'mwp_focus_keyphrase', $core, $post_id, $data, $lang );

		/*
		 * An editor's own keyphrase is never touched — except when it is the
		 * one this plugin wrote and the ONLY difference is capitalisation.
		 * Without that exception the pages synced before this rule would keep
		 * their capitals forever, since the check above stops at anything
		 * already set. Same words, different case, means it is ours.
		 */
		if ( '' !== $existing && ! self::same_words( $existing, $keyphrase ) ) {
			return;
		}

		if ( $existing === $keyphrase ) {
			return;
		}

		update_post_meta( $post_id, '_yoast_wpseo_focuskw', $keyphrase );
	}

	/**
	 * Build a meta description for a freshly synced package.
	 *
	 * Written once, on creation, and never over an existing value — an editor
	 * who has hand-written a description keeps it.
	 *
	 * @param int   $post_id Post.
	 * @param array $data    Payload.
	 * @param string $lang   Language slug.
	 * @return void
	 */
	public static function maybe_set_meta_description( $post_id, array $data, $lang = 'pl' ) {
		$existing = get_post_meta( $post_id, '_yoast_wpseo_metadesc', true );

		if ( $existing && ! self::is_ours( $post_id, '_mwp_seo_desc_auto', $existing, self::plain_description( $data, 400 ) ) ) {
			return;
		}

		// The package's own description is the meta description: it is written
		// by a human, it is already in the right language, and it describes the
		// trip better than anything assembled from fields.
		$limit       = (int) apply_filters( 'mwp_seo_description_length', 140 );
		$description = self::plain_description( $data, $limit );

		// Only when a package has no description of its own is one built from
		// the structured data, so the page never ships without one.
		if ( '' === $description ) {
			$en    = ( 'en' === $lang );
			$stops = wp_list_pluck( $data['destinations'], 'name' );
			$price = mwp_format_price( $data['price'], $lang );

			$parts = array();

			if ( $data['duration']['days'] && $stops ) {
				$parts[] = sprintf(
					$en ? '%1$d-day trip through %2$s.' : '%1$d-dniowa podróż przez %2$s.',
					$data['duration']['days'],
					implode( ', ', array_slice( $stops, 0, 3 ) )
				);
			}

			if ( $price['value'] ) {
				$parts[] = sprintf(
					$en ? 'From %1$s %2$s per person, flights included.' : 'Już od %1$s %2$s za osobę, z przelotem.',
					$price['value'],
					$price['symbol']
				);
			}

			$parts[] = $en
				? 'Fully customisable — change dates, hotels and departure airport.'
				: 'W pełni elastyczna — zmień terminy, hotele i lotnisko wylotu.';

			$description = trim( implode( ' ', $parts ) );

			// The assembled sentences can run past the limit too — the search
			// result would simply cut them mid-word.
			$description = self::shorten( $description, $limit );
		}

		if ( '' !== $description ) {
			update_post_meta( $post_id, '_yoast_wpseo_metadesc', $description );
			update_post_meta( $post_id, '_mwp_seo_desc_auto', 1 );
		}
	}
}
