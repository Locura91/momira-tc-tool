<?php
/**
 * Creates and updates the package pages.
 *
 * One Travel Compositor package becomes one Polish page and one English page,
 * linked to each other through Polylang, each under its language's hub:
 *
 *     /pakiety-podrozy/{polish-title}
 *     /en/package-tours/{english-title}
 *
 * Both addresses are permanent. They are decided when the page is created and
 * never rewritten afterwards, however often the trip is retitled or relisted in
 * Travel Compositor — a link a client saved still opens the trip.
 *
 * They are ordinary WordPress Pages on purpose. A custom post type cannot have
 * a Page as its parent, so producing /pakiety-podrozy/{slug} with a CPT
 * would mean hand-written rewrite rules plus permalink filters, kept working
 * against the cache plugin, Yoast's sitemaps and breadcrumbs. Core page
 * hierarchy already does exactly this, correctly.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Sync {

	/** @var MWP_Client */
	protected $client;

	public function __construct( MWP_Client $client = null ) {
		$this->client = $client ? $client : new MWP_Client();
	}

	/**
	 * Sync every package ID listed on a country page.
	 *
	 * @param int $country_id Country page ID.
	 * @return array{synced:array,errors:array,warnings:array}
	 */
	public function sync_country_page( $country_id ) {
		$result = array(
			'synced'   => array(),
			'errors'   => array(),
			'warnings' => array(),
		);

		$ids = self::get_package_ids( $country_id );
		if ( ! $ids ) {
			return $result;
		}

		self::mirror_settings( $country_id );

		foreach ( $ids as $package_id ) {
			$one = $this->sync_package( $package_id, $country_id );

			if ( is_wp_error( $one ) ) {
				$result['errors'][ $package_id ] = $one->get_error_message();
				continue;
			}

			$result['synced'][ $package_id ] = $one;
			if ( ! empty( $one['warnings'] ) ) {
				$result['warnings'][ $package_id ] = $one['warnings'];
			}
		}

		return $result;
	}

	/**
	 * Sync one package into PL + EN child pages.
	 *
	 * @param string $package_id TC package id.
	 * @param int    $country_id Parent country page ID (the Polish one).
	 * @return array|WP_Error
	 */
	public function sync_package( $package_id, $country_id ) {
		$package_id = mwp_extract_id( $package_id );
		if ( '' === $package_id ) {
			return new WP_Error( 'mwp_bad_id', __( 'That does not look like a package ID.', 'multiwander-packages' ) );
		}

		$payloads = array();
		$warnings = array();

		foreach ( mwp_languages() as $site_lang => $tc_lang ) {
			$info = $this->client->get_info( $package_id, $tc_lang );
			if ( is_wp_error( $info ) ) {
				// Polish is the source language: without it there is no page.
				if ( 'pl' === $site_lang ) {
					return $info;
				}
				$warnings[] = sprintf(
					/* translators: 1: language, 2: error */
					__( 'Could not load the %1$s version: %2$s', 'multiwander-packages' ),
					strtoupper( $site_lang ),
					$info->get_error_message()
				);
				continue;
			}

			$detail   = $this->client->get_detail( $package_id, $tc_lang );
			$calendar = $this->client->get_calendar( $package_id, $tc_lang );

			// A missing detail or calendar is survivable — the page still has
			// its title, description, price and hero image.
			$payloads[ $site_lang ] = MWP_Parser::normalise(
				$info,
				is_wp_error( $detail ) ? array() : $detail,
				is_wp_error( $calendar ) ? array() : $calendar
			);

			if ( is_wp_error( $detail ) ) {
				$warnings[] = sprintf(
					/* translators: %s: error message */
					__( 'Itinerary detail unavailable: %s', 'multiwander-packages' ),
					$detail->get_error_message()
				);
			}
		}

		if ( empty( $payloads['pl'] ) ) {
			return new WP_Error( 'mwp_no_pl', __( 'No Polish data came back for this package.', 'multiwander-packages' ) );
		}

		// Catch the untranslated case before it reaches a live Polish page.
		if ( ! empty( $payloads['en'] ) ) {
			$pl_title = $payloads['pl']['title'];
			$en_title = $payloads['en']['title'];
			if ( '' !== $pl_title && $pl_title === $en_title ) {
				$warnings[] = sprintf(
					/* translators: %s: package title */
					__( 'This package has no Polish translation in Travel Compositor — the Polish page will show the English title "%s". Translate it in Travel Compositor, then re-sync.', 'multiwander-packages' ),
					$pl_title
				);
			}
		}

		if ( empty( $payloads['pl']['active'] ) ) {
			$warnings[] = __( 'Travel Compositor marks this package as inactive.', 'multiwander-packages' );
		}

		// ---- Create or update the pages ----
		//
		// Every package lives under its language's hub page, never under the
		// country page it happens to be listed on:
		//
		//     /pakiety-podrozy/{polish-title}
		//     /en/package-tours/{english-title}
		//
		// The country page a trip is listed on is a merchandising decision that
		// changes over time — and a trip crossing two countries has no single
		// right answer. Tying the address to it made the address unstable. One
		// fixed home per language means an ID entered anywhere produces the
		// same two URLs, and those URLs never move again.
		$posts   = array();
		$post_id = $this->upsert_page( $package_id, $payloads['pl'], self::hub_id( 'pl' ), 'pl' );
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}
		$posts['pl'] = $post_id;

		if ( ! empty( $payloads['en'] ) ) {
			$en_id = $this->upsert_page( $package_id, $payloads['en'], self::hub_id( 'en' ), 'en' );
			if ( ! is_wp_error( $en_id ) ) {
				$posts['en'] = $en_id;
			} else {
				$warnings[] = $en_id->get_error_message();
			}
		}

		$this->link_translations( $posts );

		// A package tagged "Safari" in Travel Compositor turns up on the
		// Safari page here, without anyone copying an ID across.
		foreach ( MWP_Themes::route( $package_id, MWP_Themes::both( $payloads ) ) as $theme_label ) {
			$warnings[] = sprintf(
				/* translators: %s: theme page name */
				__( 'Added to the %s page (matched by its Travel Compositor themes).', 'multiwander-packages' ),
				$theme_label
			);
		}

		return array(
			'posts'    => $posts,
			'title'    => $payloads['pl']['title'],
			'url'      => get_permalink( $posts['pl'] ),
			'warnings' => $warnings,
		);
	}

	/**
	 * Create the page if it doesn't exist yet, otherwise update it in place.
	 *
	 * @param string $package_id TC id.
	 * @param array  $data       Normalised payload.
	 * @param int    $parent_id  Parent page.
	 * @param string $lang       Site language slug.
	 * @return int|WP_Error Post ID.
	 */
	protected function upsert_page( $package_id, array $data, $parent_id, $lang ) {
		$existing = self::find_package_page( $package_id, $lang );

		$title = $data['title'];
		if ( '' === $title ) {
			$title = sprintf( 'Pakiet %s', $package_id );
		}

		$postarr = array(
			'post_type'    => 'page',
			'post_title'   => $title,
			'post_content' => '', // Rendered from meta; see MWP_Frontend.
			'post_parent'  => (int) $parent_id,
			'post_status'  => 'publish',
		);

		if ( $existing ) {
			$postarr['ID'] = $existing;

			/*
			 * The address is fixed for good; the home is the hub.
			 *
			 * Two separate rules, both about the same promise — a link a client
			 * saved a year ago still opens the trip:
			 *
			 *  - post_name is never rewritten after creation. Travel Compositor
			 *    retitles packages fairly often, and the slug used to follow the
			 *    title, silently 404ing every link already in the wild. Content
			 *    keeps updating on every sync; the URL does not.
			 *
			 *  - post_parent is set to the language hub. For pages created under
			 *    the old country-page scheme this moves them once, which does
			 *    change those addresses — unavoidable, and the point of the new
			 *    structure. After that first move nothing shifts again, because
			 *    the hub is the same for every package regardless of country.
			 */
			$current_parent = (int) wp_get_post_parent_id( $existing );
			if ( $current_parent === (int) $parent_id ) {
				unset( $postarr['post_parent'] );
			}

			// Leave the editor's content alone. The trip layout is rendered
			// from meta, so this field only ever holds what a person typed —
			// an FAQ block, a note, an advisor card. Writing an empty string
			// here on every refresh would delete that work silently, and the
			// daily cron would do it whether or not anyone was looking.
			unset( $postarr['post_content'] );


			// Keep a manually unpublished page unpublished.
			$current = get_post_status( $existing );
			if ( in_array( $current, array( 'draft', 'private', 'pending' ), true ) ) {
				unset( $postarr['post_status'] );
			}

			$post_id = wp_update_post( $postarr, true );
		} else {
			$postarr['post_name'] = mwp_slug( $title );

			// Tell Polylang which language this insert belongs to. The filter
			// is removed immediately afterwards — leaving it attached would
			// force the language of every later insert in the same request.
			$set_lang = function () use ( $lang ) {
				return $lang;
			};
			add_filter( 'pll_inserted_post_language', $set_lang );
			$post_id = wp_insert_post( $postarr, true );
			remove_filter( 'pll_inserted_post_language', $set_lang );
		}

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		if ( function_exists( 'pll_set_post_language' ) ) {
			pll_set_post_language( $post_id, $lang );
		}

		update_post_meta( $post_id, MWP_META_ID, $package_id );

		// Remember where this page lives, so the admin can show which country
		// page owns a trip that is listed in several places. Backfilled for
		// pages created before this was recorded; never rewritten afterwards.
		if ( ! get_post_meta( $post_id, MWP_META_HOME, true ) ) {
			$home = wp_get_post_parent_id( $post_id );
			if ( $home ) {
				update_post_meta( $post_id, MWP_META_HOME, (int) $home );
			}
		}
		update_post_meta( $post_id, MWP_META_DATA, wp_slash( wp_json_encode( $data ) ) );
		update_post_meta( $post_id, MWP_META_SYNCED, current_time( 'mysql' ) );

		$this->apply_page_template( $post_id );
		$this->hide_theme_header( $post_id );
		MWP_SEO::maybe_set_title( $post_id, $data, $lang );
		MWP_SEO::maybe_set_focus_keyphrase( $post_id, $data, $lang );
		MWP_SEO::maybe_set_meta_description( $post_id, $data, $lang );
		$this->maybe_set_featured_image( $post_id, $data );

		return $post_id;
	}

	/**
	 * Apply the page template chosen in settings.
	 *
	 * The package layout prints its own H1, so the page must use a template
	 * that does NOT also print the title — otherwise every package page ships
	 * two H1s, which search engines read as a confused page.
	 *
	 * @param int $post_id Post.
	 * @return void
	 */
	protected function apply_page_template( $post_id ) {
		$template = (string) get_option( 'mwp_page_template', '' );

		// Nothing chosen in settings: inherit the country page's template.
		//
		// This matters more than it sounds. On the default template the theme
		// prints a full-width featured-image banner with the page title over
		// it — so a package page showed the hero photo twice, once as the
		// theme's banner and again in the plugin's own collage. The country
		// pages already use a template that prints neither ("Page Builder,
		// Transparent Header, Without Title"), so following the parent gets
		// the right result without anyone configuring anything.
		if ( '' === $template ) {
			$parent = wp_get_post_parent_id( $post_id );
			if ( $parent ) {
				$inherited = (string) get_post_meta( $parent, '_wp_page_template', true );
				if ( $inherited && 'default' !== $inherited ) {
					update_post_meta( $post_id, '_wp_page_template', $inherited );
				}
			}
			return;
		}

		if ( 'default' === $template ) {
			delete_post_meta( $post_id, '_wp_page_template' );
			return;
		}

		update_post_meta( $post_id, '_wp_page_template', $template );
	}

	/**
	 * Ask the theme not to print its own featured-image banner or title.
	 *
	 * Inspiro stores these as per-page toggles. The exact meta keys differ
	 * between versions, so every known spelling is set — an unused key is
	 * harmless, whereas guessing one and being wrong leaves the duplicate
	 * banner in place. The template inheritance above is the primary fix;
	 * this is belt and braces for pages left on the default template.
	 *
	 * @param int $post_id Post.
	 * @return void
	 */
	protected function hide_theme_header( $post_id ) {
		if ( ! apply_filters( 'mwp_hide_theme_header', true, $post_id ) ) {
			return;
		}

		$keys = array(
			'inspiro_hide_featured_image',
			'_inspiro_hide_featured_image',
			'inspiro_page_hide_featured_image',
			'hide_featured_image',
			'inspiro_hide_page_title',
			'_inspiro_hide_page_title',
			'inspiro_page_hide_title',
			'hide_page_title',
		);

		foreach ( $keys as $key ) {
			update_post_meta( $post_id, $key, '1' );
		}
	}

	/**
	 * Give the page a featured image so archives, Yoast and social cards work.
	 *
	 * The hero is sideloaded into the media library rather than hotlinked:
	 * Travel Compositor URLs change, and a local copy gets WordPress's own
	 * resizing and lazy-loading. A manual override always wins.
	 *
	 * @param int   $post_id Post.
	 * @param array $data    Payload.
	 * @return void
	 */
	protected function maybe_set_featured_image( $post_id, array $data ) {
		$override = get_post_meta( $post_id, MWP_META_IMAGE, true );
		$url      = $override ? $override : $data['hero_image'];

		if ( ! $url || ! preg_match( '#^https?://#i', $url ) ) {
			return;
		}

		if ( ! apply_filters( 'mwp_import_images', true, $post_id ) ) {
			return;
		}

		$current = (int) get_post_thumbnail_id( $post_id );

		if ( $current ) {
			/*
			 * A picture already imported for this page is replaced when Travel
			 * Compositor changes it, and left alone otherwise.
			 *
			 * It used to be "if there is a thumbnail, stop" — so the first
			 * photograph a package ever had was the photograph it kept
			 * forever, however many times the trip was re-shot. Title, price
			 * and itinerary all refreshed around a stale image.
			 *
			 * The source URL travels with the attachment, so we can tell
			 * "still the same picture" from "they changed it". An attachment
			 * without that marker was put there by a person, and a person's
			 * choice outranks the feed — it is never touched.
			 */
			$source = (string) get_post_meta( $current, '_mwp_source_url', true );

			if ( '' === $source ) {
				return;
			}

			if ( $source === $url ) {
				return;
			}
		}

		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$attachment_id = media_sideload_image( $url, $post_id, $data['title'], 'id' );

		if ( is_wp_error( $attachment_id ) ) {
			mwp_log( 'Hero image import failed', array(
				'post'  => $post_id,
				'url'   => $url,
				'error' => $attachment_id->get_error_message(),
			) );
			return;
		}

		// Remember where it came from, so the next sync can tell whether the
		// package's picture has actually changed.
		update_post_meta( $attachment_id, '_mwp_source_url', $url );

		// Travel Compositor serves photographs as it has them — the hero that
		// was costing this site 1.3 MB was a PNG. Resizing and re-encoding
		// happens once here rather than being paid by every visitor.
		MWP_Images::optimise( $attachment_id );

		set_post_thumbnail( $post_id, $attachment_id );

		/*
		 * Clear away the picture this one replaces — but only if this plugin
		 * imported it, and only if nothing else is using it. Hundreds of
		 * packages re-shot over a season would otherwise silently fill the
		 * media library with images no page references.
		 */
		if ( $current && $current !== (int) $attachment_id
			&& get_post_meta( $current, '_mwp_source_url', true )
			&& ! self::attachment_in_use( $current, $post_id ) ) {
			wp_delete_attachment( $current, true );
		}
	}

	/**
	 * Is this attachment the featured image of any other post?
	 *
	 * @param int $attachment_id Attachment.
	 * @param int $ignore_post   Post to disregard (the one being updated).
	 * @return bool
	 */
	protected static function attachment_in_use( $attachment_id, $ignore_post ) {
		$users = get_posts( array(
			'post_type'        => 'any',
			'post_status'      => 'any',
			'posts_per_page'   => 2,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => false,
			'lang'             => '',
			'meta_query'       => array(
				array(
					'key'   => '_thumbnail_id',
					'value' => (int) $attachment_id,
				),
			),
		) );

		foreach ( $users as $user_id ) {
			if ( (int) $user_id !== (int) $ignore_post ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Tell Polylang that these posts are translations of each other.
	 *
	 * Without this the language switcher breaks on exactly the pages you most
	 * want indexed.
	 *
	 * @param array $posts language slug => post ID.
	 * @return void
	 */
	protected function link_translations( array $posts ) {
		if ( count( $posts ) < 2 || ! function_exists( 'pll_save_post_translations' ) ) {
			return;
		}
		pll_save_post_translations( array_map( 'intval', $posts ) );
	}

	/**
	 * The country page's counterpart in another language.
	 *
	 * Falls back to the Polish parent so an English page is never orphaned at
	 * the site root.
	 *
	 * @param int    $country_id Polish country page.
	 * @param string $lang       Target language.
	 * @return int
	 */
	protected function translated_parent( $country_id, $lang ) {
		if ( function_exists( 'pll_get_post' ) ) {
			$translated = pll_get_post( $country_id, $lang );
			if ( $translated ) {
				return (int) $translated;
			}
		}
		return (int) $country_id;
	}

	// -----------------------------------------------------------------
	// Lookups
	// -----------------------------------------------------------------

	/**
	 * Find the page representing a package in a given language.
	 *
	 * @param string $package_id TC id.
	 * @param string $lang       Language slug.
	 * @return int 0 when not found.
	 */
	public static function find_package_page( $package_id, $lang = 'pl' ) {
		$args = array(
			'post_type'        => 'page',
			'post_status'      => array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page'   => 1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => false,
			'meta_query'       => array(
				array(
					'key'   => MWP_META_ID,
					'value' => (string) $package_id,
				),
			),
		);

		if ( function_exists( 'pll_current_language' ) ) {
			$args['lang'] = $lang;
		}

		$found = get_posts( $args );

		return $found ? (int) $found[0] : 0;
	}

	/**
	 * The page every package of one language lives under.
	 *
	 * /pakiety-podrozy for Polish, /en/package-tours for English (Polylang adds
	 * the language prefix itself). Created on first use if it isn't there, and
	 * the two are linked as translations of each other so the language switcher
	 * works on them as well.
	 *
	 * The resolved ID is remembered in an option, but the slug is checked first
	 * on every call — an editor who renames or deletes the hub gets it found or
	 * rebuilt rather than a site full of orphaned trips.
	 *
	 * @param string $lang Language slug.
	 * @return int Page ID, or 0 if it could not be created.
	 */
	public static function hub_id( $lang ) {
		$lang = ( 'en' === $lang ) ? 'en' : 'pl';

		$slug  = ( 'en' === $lang ) ? 'package-tours' : 'pakiety-podrozy';
		$title = ( 'en' === $lang ) ? 'Package Tours' : 'Pakiety Podróży';
		$slug  = (string) apply_filters( 'mwp_hub_slug', $slug, $lang );

		$option = 'mwp_hub_' . $lang;
		$stored = (int) get_option( $option, 0 );

		if ( $stored && 'page' === get_post_type( $stored ) && 'trash' !== get_post_status( $stored ) ) {
			return $stored;
		}

		// A page with that address may already exist — built by hand, or left
		// behind by an earlier install. Adopt it rather than making a second.
		$existing = get_page_by_path( $slug );
		if ( $existing instanceof WP_Post ) {
			update_option( $option, (int) $existing->ID );
			self::pair_hubs();
			return (int) $existing->ID;
		}

		$set_lang = function () use ( $lang ) {
			return $lang;
		};
		add_filter( 'pll_inserted_post_language', $set_lang );

		$page_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_title'   => $title,
				'post_name'    => $slug,
				'post_status'  => 'publish',
				'post_content' => '',
				'post_parent'  => 0,
			),
			true
		);

		remove_filter( 'pll_inserted_post_language', $set_lang );

		if ( is_wp_error( $page_id ) ) {
			mwp_log( 'Could not create the ' . $lang . ' package hub: ' . $page_id->get_error_message() );
			return 0;
		}

		if ( function_exists( 'pll_set_post_language' ) ) {
			pll_set_post_language( $page_id, $lang );
		}

		update_option( $option, (int) $page_id );
		self::pair_hubs();

		return (int) $page_id;
	}

	/**
	 * Link the two hub pages as translations of one another.
	 *
	 * Only once both exist — calling it earlier would save a half pair.
	 *
	 * @return void
	 */
	protected static function pair_hubs() {
		if ( ! function_exists( 'pll_save_post_translations' ) ) {
			return;
		}

		$pl = (int) get_option( 'mwp_hub_pl', 0 );
		$en = (int) get_option( 'mwp_hub_en', 0 );

		if ( $pl && $en ) {
			pll_save_post_translations( array( 'pl' => $pl, 'en' => $en ) );
		}
	}

	/**
	 * Copy the offer settings onto the country page's translations.
	 *
	 * The IDs are stored once, on the Polish page, and every language reads
	 * them from there — so a package added on the English page has always
	 * produced both language versions. What it did not do was show up in the
	 * English page's own meta box in every situation, and if the two pages
	 * were ever unlinked in Polylang the list would have been stranded on one
	 * of them.
	 *
	 * Writing the same values onto each translation costs nothing and removes
	 * both problems: whichever language an editor opens, they see the list
	 * that is actually in use.
	 *
	 * @param int $country_id Source (Polish) country page.
	 * @return void
	 */
	public static function mirror_settings( $country_id ) {
		$country_id = (int) $country_id;

		if ( ! $country_id || ! function_exists( 'pll_get_post_translations' ) ) {
			return;
		}

		$keys = array( MWP_META_IDS, MWP_META_HEADING, MWP_META_SUB, MWP_META_LAYOUT );
		foreach ( pll_get_post_translations( $country_id ) as $translated ) {
			$translated = (int) $translated;

			if ( $translated === $country_id || ! $translated ) {
				continue;
			}

			foreach ( $keys as $key ) {
				$value = get_post_meta( $country_id, $key, true );

				if ( '' === $value || null === $value ) {
					delete_post_meta( $translated, $key );
				} else {
					update_post_meta( $translated, $key, $value );
				}
			}
		}
	}

	/**
	 * The Polish original of a country page.
	 *
	 * Package IDs are always stored on, and synced from, the Polish page:
	 * Polish is the source language and the Polish country page is the parent
	 * the Polish package pages hang off. Entering IDs while editing the
	 * English page must not build the tree under the English parent.
	 *
	 * @param int $post_id Any language's country page.
	 * @return int
	 */
	public static function source_country_id( $post_id ) {
		$post_id = (int) $post_id;
		if ( ! $post_id || ! function_exists( 'pll_get_post_language' ) ) {
			return $post_id;
		}

		$lang = pll_get_post_language( $post_id, 'slug' );
		if ( ! $lang || 'pl' === $lang ) {
			return $post_id;
		}

		$pl = pll_get_post( $post_id, 'pl' );

		return $pl ? (int) $pl : $post_id;
	}

	/**
	 * Package IDs entered on a country page.
	 *
	 * @param int $country_id Page ID.
	 * @return string[]
	 */
	public static function get_package_ids( $country_id ) {
		$raw = get_post_meta( $country_id, MWP_META_IDS, true );
		if ( ! $raw ) {
			return array();
		}

		$lines = preg_split( '/[\r\n,]+/', (string) $raw );
		$ids   = array();

		foreach ( $lines as $line ) {
			$id = mwp_extract_id( $line );
			if ( '' !== $id && ! in_array( $id, $ids, true ) ) {
				$ids[] = $id;
			}
		}

		return $ids;
	}

	/**
	 * Package pages belonging to a country page, in the order their IDs were
	 * entered — so the editor controls the order of the offer row.
	 *
	 * @param int    $country_id Country page.
	 * @param string $lang       Language slug.
	 * @return WP_Post[]
	 */
	public static function get_package_pages( $country_id, $lang = 'pl' ) {
		$posts = array();
		foreach ( self::get_package_ids( $country_id ) as $id ) {
			$post_id = self::find_package_page( $id, $lang );
			if ( $post_id && 'publish' === get_post_status( $post_id ) ) {
				$posts[] = get_post( $post_id );
			}
		}
		return $posts;
	}

	/**
	 * Read the stored payload off a package page.
	 *
	 * @param int $post_id Post.
	 * @return array|null
	 */
	/**
	 * The most recently added package pages, in one language.
	 *
	 * "Newest" is the date the page was created here, not a field from Travel
	 * Compositor — which is the right answer for a landing page, because what
	 * it advertises is what MultiWander has just started selling. A package
	 * re-synced for a new price does not jump back to the front.
	 *
	 * @param string $lang  Language slug.
	 * @param int    $limit How many.
	 * @return WP_Post[]
	 */
	public static function latest_package_pages( $lang, $limit = 12 ) {
		$args = array(
			'post_type'        => 'page',
			'post_status'      => 'publish',
			'posts_per_page'   => max( 1, min( 40, (int) $limit ) ),
			'orderby'          => 'date',
			'order'            => 'DESC',
			'no_found_rows'    => true,
			'suppress_filters' => false,
			'meta_query'       => array(
				array(
					'key'     => MWP_META_ID,
					'compare' => 'EXISTS',
				),
			),
		);

		if ( function_exists( 'pll_current_language' ) ) {
			$args['lang'] = $lang;
		}

		return get_posts( $args );
	}

	public static function get_data( $post_id ) {
		$raw = get_post_meta( $post_id, MWP_META_DATA, true );
		if ( ! $raw ) {
			return null;
		}
		$data = json_decode( $raw, true );
		return is_array( $data ) ? $data : null;
	}
}
