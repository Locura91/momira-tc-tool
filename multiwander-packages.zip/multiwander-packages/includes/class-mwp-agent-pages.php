<?php
/**
 * Admin: Create and manage public profile pages for travel agents.
 *
 * Lists every WordPress user with the wappointment_staff role, shows which
 * have a linked profile page already, and lets an administrator create one
 * for each agent that does not yet have one — slug, shortcode, and the two
 * pieces of glue meta all handled automatically.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Agent_Pages {

	const MENU_SLUG     = 'mwp-agents';
	const CREATE_ACTION = 'mwp_create_agent_page';
	const NOTICE_KEY    = 'mwp_agent_pages_notice_';

	/**
	 * The WordPress role that identifies live-site travel agents.
	 * On the live site this is `wappointment_staff`; the plugin also
	 * registers `travel_agent` for its own kit screen but that role is
	 * not yet deployed to production.
	 */
	const STAFF_ROLE = 'wappointment_staff';

	public static function init() {
		add_action( 'admin_menu',                array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_' . self::CREATE_ACTION, array( __CLASS__, 'handle_create' ) );
	}

	// -----------------------------------------------------------------
	// Menu
	// -----------------------------------------------------------------

	public static function menu() {
		add_menu_page(
			__( 'Travel Agents', 'multiwander-packages' ),
			__( 'Travel Agents', 'multiwander-packages' ),
			'manage_options',
			self::MENU_SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-groups',
			27
		);
	}

	// -----------------------------------------------------------------
	// Main screen
	// -----------------------------------------------------------------

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Pull and display any queued notice from a just-completed create.
		$notice_key = self::NOTICE_KEY . get_current_user_id();
		$notice     = get_transient( $notice_key );
		if ( $notice ) {
			delete_transient( $notice_key );
			echo '<div class="notice notice-' . esc_attr( $notice['type'] ) . ' is-dismissible"><p>' .
				esc_html( $notice['message'] ) . '</p></div>';
		}

		// Everyone with the staff role, regardless of enabled status.
		$agents = get_users( array( 'role' => self::STAFF_ROLE ) );

		// Build a lookup: user_id → profile page post ID (or 0).
		$linked = self::get_linked_pages( $agents );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Travel Agents', 'multiwander-packages' ); ?></h1>

			<p class="description" style="max-width:72ch">
				<?php esc_html_e( 'Every person with the Wappointment Staff role appears here. Fill in their profile on their WordPress user account, then press "Create Profile Page" — the plugin builds the public page, sets the shortcode, and wires everything up automatically.', 'multiwander-packages' ); ?>
			</p>

			<?php if ( ! $agents ) : ?>
				<div class="notice notice-warning inline">
					<p><?php esc_html_e( 'No users with the Wappointment Staff role found. Add users in Users → All Users and assign them the Wappointment Staff role.', 'multiwander-packages' ); ?></p>
				</div>
			<?php else : ?>

			<table class="wp-list-table widefat fixed striped" style="margin-top:18px">
				<thead>
					<tr>
						<th style="width:220px"><?php esc_html_e( 'Name', 'multiwander-packages' ); ?></th>
						<th style="width:60px"><?php esc_html_e( 'User ID', 'multiwander-packages' ); ?></th>
						<th><?php esc_html_e( 'Email', 'multiwander-packages' ); ?></th>
						<th style="width:180px"><?php esc_html_e( 'Profile fields', 'multiwander-packages' ); ?></th>
						<th style="width:220px"><?php esc_html_e( 'Profile page', 'multiwander-packages' ); ?></th>
						<th style="width:220px"><?php esc_html_e( 'Shortcode', 'multiwander-packages' ); ?></th>
						<th style="width:160px"><?php esc_html_e( 'Actions', 'multiwander-packages' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $agents as $user ) : ?>
					<?php
					$page_id   = isset( $linked[ $user->ID ] ) ? $linked[ $user->ID ] : 0;
					$enabled   = get_user_meta( $user->ID, MWP_Agent::META . 'enabled', true );
					$fields    = self::profile_summary( $user->ID );
					$shortcode = '[multiwander_agent user="' . $user->ID . '"]';
					?>
					<tr>
						<td>
							<strong>
								<a href="<?php echo esc_url( get_edit_user_link( $user->ID ) ); ?>">
									<?php echo esc_html( $user->display_name ); ?>
								</a>
							</strong>
							<?php if ( '1' === $enabled ) : ?>
								<br><span style="color:#1e8e3e;font-size:11px">&#10003; <?php esc_html_e( 'enabled', 'multiwander-packages' ); ?></span>
							<?php else : ?>
								<br><span style="color:#999;font-size:11px"><?php esc_html_e( 'not enabled', 'multiwander-packages' ); ?></span>
							<?php endif; ?>
						</td>
						<td><code style="font-size:12px;font-weight:700;background:#f3f4f6;padding:2px 6px;border-radius:4px"><?php echo absint( $user->ID ); ?></code></td>
						<td><?php echo esc_html( $user->user_email ); ?></td>
						<td>
							<?php foreach ( $fields as $label => $filled ) : ?>
								<span style="display:inline-block;margin:1px 3px 1px 0;font-size:11px;color:<?php echo $filled ? '#1e8e3e' : '#aaa'; ?>">
									<?php echo $filled ? '&#10003;' : '&#10007;'; ?>
									<?php echo esc_html( $label ); ?>
								</span>
							<?php endforeach; ?>
						</td>
						<td>
							<?php if ( $page_id ) : ?>
								<span style="color:#1e8e3e">&#10003;</span>
								<a href="<?php echo esc_url( (string) get_edit_post_link( $page_id ) ); ?>">
									<?php echo esc_html( get_the_title( $page_id ) ); ?>
								</a><br>
								<a href="<?php echo esc_url( (string) get_permalink( $page_id ) ); ?>" target="_blank" rel="noopener" style="font-size:11px;color:#777">
									<?php echo esc_html( wp_make_link_relative( (string) get_permalink( $page_id ) ) ); ?>
								</a>
							<?php else : ?>
								<span style="color:#999">—</span>
							<?php endif; ?>
						</td>
						<td>
							<code style="font-size:11px;word-break:break-all"><?php echo esc_html( $shortcode ); ?></code>
						</td>
						<td>
							<?php if ( ! $page_id ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="<?php echo esc_attr( self::CREATE_ACTION ); ?>">
									<input type="hidden" name="user_id" value="<?php echo esc_attr( $user->ID ); ?>">
									<?php wp_nonce_field( self::CREATE_ACTION . '_' . $user->ID, 'mwp_agent_nonce' ); ?>
									<button type="submit" class="button button-primary">
										<?php esc_html_e( 'Create Profile Page', 'multiwander-packages' ); ?>
									</button>
								</form>
							<?php else : ?>
								<a href="<?php echo esc_url( (string) get_permalink( $page_id ) ); ?>" target="_blank" rel="noopener" class="button">
									<?php esc_html_e( 'View Page', 'multiwander-packages' ); ?>
								</a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php endif; ?>
		</div>
		<?php
	}

	// -----------------------------------------------------------------
	// Handle the "Create Profile Page" form POST
	// -----------------------------------------------------------------

	public static function handle_create() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'multiwander-packages' ) );
		}

		$user_id = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;

		if ( ! $user_id ) {
			wp_die( esc_html__( 'No user specified.', 'multiwander-packages' ) );
		}

		check_admin_referer( self::CREATE_ACTION . '_' . $user_id, 'mwp_agent_nonce' );

		$notice_key = self::NOTICE_KEY . get_current_user_id();
		$redirect   = admin_url( 'admin.php?page=' . self::MENU_SLUG );

		// Make sure the user exists and has the right role.
		$user = get_userdata( $user_id );
		if ( ! $user || ! in_array( self::STAFF_ROLE, (array) $user->roles, true ) ) {
			set_transient( $notice_key, array(
				'type'    => 'error',
				'message' => __( 'User not found or not a Wappointment Staff member.', 'multiwander-packages' ),
			), 60 );
			wp_safe_redirect( $redirect );
			exit;
		}

		// Guard: don't create a duplicate if a page is already linked.
		$existing = self::find_agent_page( $user_id );
		if ( $existing ) {
			set_transient( $notice_key, array(
				'type'    => 'warning',
				'message' => sprintf(
					/* translators: %s: agent display name */
					__( 'A profile page already exists for %s — no new page was created.', 'multiwander-packages' ),
					$user->display_name
				),
			), 60 );
			wp_safe_redirect( $redirect );
			exit;
		}

		// Derive a clean slug from the agent's display name.
		// sanitize_title() already handles Polish characters via remove_accents().
		$slug = sanitize_title( $user->display_name );

		// Ensure uniqueness: if the slug is taken, WordPress's wp_unique_post_slug()
		// is called internally by wp_insert_post(), so we don't need to handle it.

		$page_id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $user->display_name,
			'post_name'    => $slug,
			'post_content' => '<!-- wp:shortcode -->[multiwander_agent user="' . $user_id . '"]<!-- /wp:shortcode -->',
			'post_author'  => $user_id,
		), true );

		if ( is_wp_error( $page_id ) ) {
			set_transient( $notice_key, array(
				'type'    => 'error',
				'message' => sprintf(
					/* translators: %s: error message */
					__( 'Could not create page: %s', 'multiwander-packages' ),
					$page_id->get_error_message()
				),
			), 60 );
			wp_safe_redirect( $redirect );
			exit;
		}

		// Link the page to the agent user and mark the user as enabled.
		update_post_meta( $page_id, MWP_Agent::PAGE_META, $user_id );
		update_user_meta( $user_id, MWP_Agent::META . 'enabled', '1' );

		set_transient( $notice_key, array(
			'type'    => 'success',
			'message' => sprintf(
				/* translators: 1: agent display name, 2: page URL */
				__( 'Profile page created for %1$s at %2$s', 'multiwander-packages' ),
				$user->display_name,
				get_permalink( $page_id )
			),
		), 60 );

		wp_safe_redirect( $redirect );
		exit;
	}

	// -----------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------

	/**
	 * Build a user_id → page_id map for a list of WP_User objects.
	 *
	 * Runs a single posts query for all agents at once rather than N separate
	 * queries, so the list screen stays fast even with dozens of agents.
	 *
	 * @param WP_User[] $agents
	 * @return int[] user_id => page_id
	 */
	private static function get_linked_pages( array $agents ) {
		if ( ! $agents ) {
			return array();
		}

		$user_ids = wp_list_pluck( $agents, 'ID' );

		$pages = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft', 'pending' ),
			'posts_per_page' => -1,
			'meta_query'     => array(
				array(
					'key'     => MWP_Agent::PAGE_META,
					'value'   => $user_ids,
					'compare' => 'IN',
				),
			),
			'fields'         => 'ids',
		) );

		$map = array();
		foreach ( $pages as $pid ) {
			$uid = (int) get_post_meta( $pid, MWP_Agent::PAGE_META, true );
			if ( $uid ) {
				$map[ $uid ] = $pid;
			}
		}

		return $map;
	}

	/**
	 * Find the profile page linked to a single user, or return 0.
	 *
	 * @param int $user_id
	 * @return int  Page post ID, or 0 if none found.
	 */
	private static function find_agent_page( $user_id ) {
		$pages = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page' => 1,
			'meta_key'       => MWP_Agent::PAGE_META,
			'meta_value'     => (int) $user_id,
			'fields'         => 'ids',
		) );

		return $pages ? (int) $pages[0] : 0;
	}

	/**
	 * Return a label → bool map of key profile fields for the table display.
	 *
	 * @param int $user_id
	 * @return bool[]  label => true if filled
	 */
	private static function profile_summary( $user_id ) {
		$prefix = MWP_Agent::META;

		return array(
			__( 'Photo',    'multiwander-packages' ) => (bool) get_user_meta( $user_id, $prefix . 'photo_id',  true ),
			__( 'Headline', 'multiwander-packages' ) => (bool) get_user_meta( $user_id, $prefix . 'headline',  true ),
			__( 'Bio',      'multiwander-packages' ) => (bool) get_user_meta( $user_id, $prefix . 'bio',       true ),
			__( 'Regions',  'multiwander-packages' ) => (bool) get_user_meta( $user_id, $prefix . 'regions',   true ),
		);
	}
}
