<?php
/**
 * Front end: the teaser cards and the package page.
 *
 * Nothing here calls the API. Everything comes from post meta written at sync
 * time, so page loads stay fast and a slow Travel Compositor can never slow
 * the site down — which is exactly what the old scraping shortcode did on
 * every uncached view.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Frontend {

	public static function init() {
		add_shortcode( 'multiwander_offers', array( __CLASS__, 'offers_shortcode' ) );

		/*
		 * [multiwander_latest] — the newest trips, with no list to maintain.
		 *
		 * Every other placement on the site names its packages by ID, which is
		 * right for a country or a theme page: somebody decided those trips
		 * belong there. A landing page wants the opposite — whatever went up
		 * most recently, without anyone remembering to come back and change
		 * it. Same cards, same layouts; only the question differs.
		 */
		add_shortcode( 'multiwander_latest', array( __CLASS__, 'latest_shortcode' ) );
		add_filter( 'the_content', array( __CLASS__, 'package_content' ), 20 );
		add_filter( 'the_title', array( __CLASS__, 'suppress_theme_title' ), 5, 2 );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		// Priority 100: the child theme enqueues its stylesheet at 20, so at the
		// default 10 this file would load FIRST and lose every specificity tie
		// to it — which is exactly what turned the buttons turquoise-on-
		// turquoise and let the theme's list markers show through.
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ), 100 );
		add_action( 'wp_head', array( __CLASS__, 'site_wide_css' ), 99 );
	}

	/**
	 * The handful of rules that have to apply everywhere.
	 *
	 * The plugin's stylesheet only loads on pages that show packages, which is
	 * right for everything in it — but the theme's floating "back to top"
	 * button appears on every page, and hiding it is a site-wide decision.
	 * Printed inline rather than as another stylesheet: it is one line, and a
	 * request would cost more than the bytes.
	 *
	 * @return void
	 */
	public static function site_wide_css() {
		if ( ! apply_filters( 'mwp_hide_back_to_top', true ) ) {
			return;
		}

		echo '<style id="mwp-inline">#inspiro-back-to-top{display:none!important;}</style>' . "\n";
	}

	/**
	 * Load assets only on pages that actually use them.
	 *
	 * @return void
	 */
	public static function assets() {
		if ( ! is_singular( 'page' ) ) {
			return;
		}

		$post = get_post();
		if ( ! $post ) {
			return;
		}

		$is_package = (bool) get_post_meta( $post->ID, MWP_META_ID, true );
		$content    = (string) $post->post_content;
		$source     = MWP_Sync::source_country_id( $post->ID );
		$has_ids    = (bool) MWP_Sync::get_package_ids( $source );

		// Offers may be placed by the shortcode or appended automatically, so
		// the presence of IDs counts too — otherwise auto-placed cards would
		// render unstyled.
		$has_catalogue = has_shortcode( $content, 'multiwander_catalogue' );
		$has_offers    = has_shortcode( $content, 'multiwander_offers' ) || $has_catalogue || $has_ids;

		if ( ! $is_package && ! $has_offers ) {
			return;
		}

		$layout = (string) get_post_meta( $source, MWP_META_LAYOUT, true );

		wp_enqueue_style(
			'mwp-front',
			MWP_URL . 'assets/front.css',
			array(),
			MWPP_asset_version( 'assets/front.css' )
		);

		// The "see more" expander only exists on package pages.
		if ( $is_package ) {
			wp_enqueue_script(
				'mwp-front',
				MWP_URL . 'assets/front.js',
				array(),
				MWPP_asset_version( 'assets/front.js' ),
				true
			);
		}

		if ( $has_catalogue ) {
			wp_enqueue_script(
				'mwp-catalogue',
				MWP_URL . 'assets/catalogue.js',
				array(),
				MWPP_asset_version( 'assets/catalogue.js' ),
				true
			);
		}

		// The slider script is only worth its bytes where a slider exists.
		// With the automatic layout the shape is only known at render time, so
		// load the tiny slider script whenever a slider is possible.
		$maybe_slider = ( '' === $layout || 'auto' === $layout || 'slider' === $layout )
			|| false !== strpos( $content, 'layout="slider"' );

		if ( $has_offers && $maybe_slider ) {
			wp_enqueue_script(
				'mwp-slider',
				MWP_URL . 'assets/slider.js',
				array(),
				MWPP_asset_version( 'assets/slider.js' ),
				true
			);
		}
	}

	/**
	 * Stop the theme printing the page title on a package page.
	 *
	 * The package layout prints its own H1 under the image collage. When the
	 * theme's template prints the title as well, the visitor sees the trip name
	 * twice and the page ships two H1 headings — which search engines read as a
	 * page that cannot decide what it is about.
	 *
	 * Removing it here takes it out of the HTML entirely, rather than hiding it
	 * with CSS and leaving the duplicate heading in the source.
	 *
	 * Deliberately narrow: only inside the main loop, only for the page being
	 * viewed. Navigation menus, breadcrumbs, admin lists and the document title
	 * all run outside the loop and keep their titles.
	 *
	 * @param string $title   Title.
	 * @param int    $post_id Post ID (absent in some legacy callers).
	 * @return string
	 */
	public static function suppress_theme_title( $title, $post_id = 0 ) {
		if ( is_admin() || ! in_the_loop() || ! is_main_query() || ! is_singular( 'page' ) ) {
			return $title;
		}

		$post_id = $post_id ? (int) $post_id : (int) get_the_ID();

		if ( $post_id !== (int) get_queried_object_id() ) {
			return $title;
		}

		if ( ! get_post_meta( $post_id, MWP_META_ID, true ) ) {
			return $title;
		}

		if ( ! apply_filters( 'mwp_suppress_theme_title', true, $post_id ) ) {
			return $title;
		}

		return '';
	}

	/**
	 * Mark package pages so the stylesheet can adjust theme chrome.
	 *
	 * @param array $classes Body classes.
	 * @return array
	 */
	public static function body_class( $classes ) {
		if ( is_singular( 'page' ) && get_post_meta( get_queried_object_id(), MWP_META_ID, true ) ) {
			$classes[] = 'mwp-package-page';
		}
		return $classes;
	}

	// -----------------------------------------------------------------
	// Teasers
	// -----------------------------------------------------------------

	/**
	 * [multiwander_offers] — teaser cards.
	 *
	 * Attributes:
	 *   layout   row (default) | slider | single
	 *   ids      explicit package IDs, overriding the page's own list
	 *   columns  2-4, row layout only
	 *   limit    maximum cards
	 *   heading  optional H2 above the cards
	 *
	 * Cards are built from the package pages themselves, so removing an ID
	 * from the meta box drops the card while leaving the page published and
	 * indexed. No dead URLs.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function offers_shortcode( $atts ) {
		// Settings live on the page, in the same box as the IDs. Shortcode
		// attributes are only an override for the odd case where one page
		// needs something different.
		$page   = get_post();
		$source = $page ? MWP_Sync::source_country_id( $page->ID ) : 0;

		$defaults = array(
			'layout'  => $source ? ( get_post_meta( $source, MWP_META_LAYOUT, true ) ?: 'auto' ) : 'auto',
			'ids'     => '',
			'latest'  => 0,
			'columns' => 3,
			'limit'   => 0,
			'heading' => $source ? (string) get_post_meta( $source, MWP_META_HEADING, true ) : '',
			'sub'     => $source ? (string) get_post_meta( $source, MWP_META_SUB, true ) : '',
		);

		$atts = shortcode_atts( $defaults, $atts, 'multiwander_offers' );

		$layout = in_array( $atts['layout'], array( 'auto', 'row', 'slider', 'single', 'duo' ), true )
			? $atts['layout']
			: 'auto';

		$lang  = mwp_current_lang();
		$pages = (int) $atts['latest'] > 0
			? MWP_Sync::latest_package_pages( $lang, (int) $atts['latest'] )
			: self::resolve_pages( $atts['ids'], $lang );

		if ( 'single' === $layout ) {
			$pages = array_slice( $pages, 0, 1 );
		} elseif ( $atts['limit'] > 0 ) {
			$pages = array_slice( $pages, 0, (int) $atts['limit'] );
		}

		// Let the number of offers choose the shape. One card centred and not
		// stretched across the page; two side by side; three as a full desktop
		// row; four or more as a scrollable track, because a fourth card would
		// otherwise squeeze the others below a readable width.
		if ( 'auto' === $layout ) {
			$count = count( $pages );
			if ( $count <= 1 ) {
				$layout = 'single';
			} elseif ( 2 === $count ) {
				$layout = 'duo';
			} elseif ( 3 === $count ) {
				$layout = 'row';
			} else {
				$layout = 'slider';
			}
		}

		if ( ! $pages ) {
			// Say nothing to visitors rather than showing a broken row.
			return current_user_can( 'edit_posts' )
				? '<p class="mwp mwp-empty">' . esc_html__( 'No travel packages yet — add package IDs in the box below the editor and update the page.', 'multiwander-packages' ) . '</p>'
				: '';
		}

		$columns = max( 2, min( 4, (int) $atts['columns'] ) );

		$classes = array( 'mwp', 'mwp-offers', 'mwp-' . $layout );
		if ( 'row' === $layout ) {
			$classes[] = 'mwp-cols-' . $columns;
		}

		ob_start();
		?>
		<section class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
			<?php if ( $atts['heading'] ) : ?>
				<h2 class="mwp-offers-heading"><?php echo esc_html( $atts['heading'] ); ?></h2>
			<?php endif; ?>

			<?php if ( $atts['sub'] ) : ?>
				<p class="mwp-offers-sub"><?php echo esc_html( $atts['sub'] ); ?></p>
			<?php endif; ?>

			<?php if ( 'slider' === $layout ) : ?>
				<button type="button" class="mwp-slider-nav mwp-prev" aria-label="<?php esc_attr_e( 'Previous', 'multiwander-packages' ); ?>">&#8249;</button>
				<button type="button" class="mwp-slider-nav mwp-next" aria-label="<?php esc_attr_e( 'Next', 'multiwander-packages' ); ?>">&#8250;</button>
			<?php endif; ?>

			<div class="mwp-grid">
				<?php foreach ( $pages as $page ) : ?>
					<?php self::render_card( $page, $lang ); ?>
				<?php endforeach; ?>
			</div>

			<?php if ( 'slider' === $layout ) : ?>
				<div class="mwp-dots" role="tablist" aria-label="<?php esc_attr_e( 'Choose slide', 'multiwander-packages' ); ?>"></div>
			<?php endif; ?>
		</section>
		<?php
		return ob_get_clean();
	}

	/**
	 * Work out which package pages a shortcode should show.
	 *
	 * @param string $ids  Explicit ids attribute, possibly empty.
	 * @param string $lang Language slug.
	 * @return WP_Post[]
	 */
	/**
	 * [multiwander_latest] — the newest packages on the site.
	 *
	 * A thin wrapper: it sets the one attribute the offers shortcode needed
	 * and hands over, so the cards, the layouts, the slider and every future
	 * change to them are shared rather than forked. Twelve by default, which
	 * fills four slider pages of three without a thirteenth card hanging off
	 * the end.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function latest_shortcode( $atts ) {
		$atts = is_array( $atts ) ? $atts : array();

		if ( empty( $atts['count'] ) && empty( $atts['latest'] ) ) {
			$atts['latest'] = 12;
		} elseif ( ! empty( $atts['count'] ) ) {
			$atts['latest'] = (int) $atts['count'];
			unset( $atts['count'] );
		}

		// A landing-page row has no ID list of its own to read a layout from,
		// and twelve cards in a static grid is a wall. The slider is the shape
		// that suits "here is what is new".
		if ( empty( $atts['layout'] ) ) {
			$atts['layout'] = 'slider';
		}

		return self::offers_shortcode( $atts );
	}

	protected static function resolve_pages( $ids, $lang ) {
		if ( $ids ) {
			$pages = array();
			foreach ( preg_split( '/[\s,]+/', $ids ) as $raw ) {
				$id = mwp_extract_id( $raw );
				if ( '' === $id ) {
					continue;
				}
				$found = MWP_Sync::find_package_page( $id, $lang );
				if ( $found && 'publish' === get_post_status( $found ) ) {
					$pages[] = get_post( $found );
				}
			}
			return $pages;
		}

		$post = get_post();
		if ( ! $post ) {
			return array();
		}

		// On an English page the IDs live on its Polish original.
		$source_id = $post->ID;
		if ( 'pl' !== $lang && function_exists( 'pll_get_post' ) ) {
			$pl = pll_get_post( $post->ID, 'pl' );
			if ( $pl ) {
				$source_id = $pl;
			}
		}

		return MWP_Sync::get_package_pages( $source_id, $lang );
	}

	/**
	 * One teaser card.
	 *
	 * @param WP_Post $page Package page.
	 * @param string  $lang Language slug.
	 * @return void
	 */
	public static function render_card( $page, $lang ) {
		$data = MWP_Sync::get_data( $page->ID );
		if ( ! $data ) {
			return;
		}

		$en    = ( 'en' === $lang );
		$price = mwp_format_price( $data['price'], $lang );
		$image = self::hero_url( $page->ID, $data );
		$url   = get_permalink( $page );
		$title = get_the_title( $page );

		// Small line above the title: the package's own first theme, falling
		// back to the ribbon so the slot is never empty.
		$kicker = ! empty( $data['themes'][0] ) ? $data['themes'][0] : $data['ribbon'];

		// One descriptive line: where you go, then what is in it.
		$stops = wp_list_pluck( $data['destinations'], 'name' );
		$route = $stops ? implode( ' · ', array_slice( $stops, 0, 4 ) ) : '';
		if ( count( $stops ) > 4 ) {
			$route .= ' …';
		}

		$bits = array();
		if ( $data['duration']['days'] ) {
			$bits[] = sprintf( $en ? '%d days' : '%d dni', $data['duration']['days'] );
		}

		$stars = 0;
		foreach ( $data['hotels'] as $hotel ) {
			$stars = max( $stars, (int) $hotel['stars'] );
		}
		if ( $stars ) {
			$bits[] = $stars . '★ ' . ( $en ? 'hotels' : 'hotele' );
		}
		if ( $data['flights'] ) {
			$bits[] = $en ? 'flights included' : 'z przelotem';
		}

		$summary = trim( $route . ( $bits ? ' — ' . implode( ', ', $bits ) : '' ) );
		?>
		<article class="mwp-card">
			<a class="mwp-card-link" href="<?php echo esc_url( $url ); ?>">

				<div class="mwp-card-media">
					<?php
					// A card is never wider than a third of the page, so the
					// browser is told that plainly and picks a small file.
					echo mwp_image_tag( // phpcs:ignore WordPress.Security.EscapeOutput
						$image,
						sprintf( $en ? 'Trip: %s' : 'Podróż: %s', $title ),
						array(
							'attachment_id' => (int) get_post_thumbnail_id( $page->ID ),
							'size'          => 'medium_large',
							'sizes'         => '(max-width: 620px) 92vw, (max-width: 1040px) 46vw, 31vw',
						)
					);
					?>
					<?php if ( $data['ribbon'] ) : ?>
						<span class="mwp-ribbon"><?php echo esc_html( $data['ribbon'] ); ?></span>
					<?php endif; ?>
				</div>

				<div class="mwp-card-body">
					<?php if ( $kicker ) : ?>
						<p class="mwp-kicker"><?php echo esc_html( $kicker ); ?></p>
					<?php endif; ?>

					<h3 class="mwp-card-title"><?php echo esc_html( $title ); ?></h3>

					<?php if ( $summary ) : ?>
						<p class="mwp-card-summary"><?php echo esc_html( $summary ); ?></p>
					<?php endif; ?>

					<div class="mwp-card-foot">
						<?php if ( $price['value'] ) : ?>
							<p class="mwp-price">
								<span class="mwp-price-from"><?php echo esc_html( $en ? 'from' : 'od' ); ?></span>
								<span class="mwp-price-amount"><?php echo esc_html( $price['value'] ); ?> <?php echo esc_html( $price['symbol'] ); ?></span>
								<span class="mwp-price-per"><?php echo esc_html( $en ? 'p. p.' : 'os.' ); ?></span>
							</p>
						<?php else : ?>
							<span></span>
						<?php endif; ?>

						<span class="mwp-pill"><?php echo esc_html( $en ? 'View' : 'Zobacz' ); ?></span>
					</div>
				</div>
			</a>
		</article>
		<?php
	}

	// -----------------------------------------------------------------
	// Package page
	// -----------------------------------------------------------------

	/**
	 * Append the package layout to the page content.
	 *
	 * Done through the_content rather than a bundled page template so the page
	 * keeps whatever theme template the rest of the site uses, and an editor
	 * can still write their own copy above it.
	 *
	 * @param string $content Existing content.
	 * @return string
	 */
	public static function package_content( $content ) {
		if ( ! is_singular( 'page' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$post_id = get_the_ID();

		if ( ! get_post_meta( $post_id, MWP_META_ID, true ) ) {
			// Not a package page — but it may be a country page whose offers
			// should be placed automatically. The shortcode is only needed
			// when the section has to sit at a particular spot in the content.
			return self::maybe_append_offers( $content, $post_id );
		}

		$data = MWP_Sync::get_data( $post_id );
		if ( ! $data ) {
			return $content;
		}

		ob_start();
		self::render_package( $post_id, $data, mwp_current_lang() );
		$package = ob_get_clean();

		// The package layout comes FIRST and whatever the editor writes in the
		// page follows it. That way anything added by hand — an FAQ block, a
		// note, an advisor card — lands underneath the trip details, which is
		// where extra content belongs on a product page.
		$extra = trim( $content );

		if ( '' !== $extra ) {
			$extra = '<div class="mwp mwp-extra">' . $content . '</div>';
		}

		return $package . $extra;
	}

	/**
	 * Place a country page's offers automatically.
	 *
	 * If the editor has entered package IDs but not placed the shortcode
	 * anywhere, the section is appended to the content so the offers appear
	 * without them having to touch a block. Adding the shortcode gives them
	 * control over exactly where it sits instead.
	 *
	 * @param string $content Page content.
	 * @param int    $post_id Page.
	 * @return string
	 */
	protected static function maybe_append_offers( $content, $post_id ) {
		/*
		 * Offers appear where [multiwander_offers] is written — and on a theme
		 * page, where the plugin put the IDs itself.
		 *
		 * The automatic placement was removed entirely once, because the test
		 * that was supposed to skip pages already carrying the shortcode could
		 * not work: WordPress runs do_shortcode on the_content at priority 11
		 * and this filter runs at 20, so by the time it looked, the shortcode
		 * had been replaced by its own output and there was nothing left to
		 * find. Every page with both got the row twice.
		 *
		 * The fix for that is to read the RAW post content, which still has the
		 * shortcode in it, rather than the filtered string — not to abandon
		 * automatic placement altogether. Abandoning it left the six theme
		 * pages in the worst possible state: the plugin adding IDs to them on
		 * every sync, and the pages showing nothing, with no hint as to why.
		 *
		 * So: a page the theme routing writes to renders its offers on its own.
		 * Everywhere else, the shortcode decides, exactly as before.
		 */
		$post = get_post( $post_id );
		$raw  = $post ? (string) $post->post_content : '';

		if ( has_shortcode( $raw, 'multiwander_offers' ) ) {
			return $content;
		}

		$source = MWP_Sync::source_country_id( $post_id );

		if ( ! MWP_Sync::get_package_ids( $source ) ) {
			return $content;
		}

		$is_theme_page = in_array( (int) $source, array_map( 'intval', MWP_Themes::pages() ), true );

		if ( ! apply_filters( 'mwp_auto_place_offers', $is_theme_page, $post_id ) ) {
			return $content;
		}

		return $content . self::offers_shortcode( array() );
	}

	/**
	 * The package layout.
	 *
	 * Heading order is deliberate: one H1 in the hero, H2 per section. If the
	 * active page template also prints the title there would be two H1s, which
	 * is why the sync applies the "no title" template chosen in settings.
	 *
	 * @param int    $post_id Post.
	 * @param array  $d       Payload.
	 * @param string $lang    Language slug.
	 * @return void
	 */
	protected static function render_package( $post_id, array $d, $lang ) {
		$en = ( 'en' === $lang );
		$t  = function ( $pl, $english ) use ( $en ) {
			return $en ? $english : $pl;
		};

		$price   = mwp_format_price( $d['price'], $lang );
		$hero    = self::hero_url( $post_id, $d );
		// Read the raw title: the_title is filtered above to stop the theme
		// printing it, and that filter must not blank our own heading.
		$post_obj = get_post( $post_id );
		$title    = $post_obj ? $post_obj->post_title : '';
		$parent   = wp_get_post_parent_id( $post_id );
		$booking = mwp_booking_url( $d, $lang );
		$items   = MWP_Timeline::build( $d, $lang );
		$adults  = max( 1, (int) $d['counters']['adults'] );
		$limits  = mwp_booking_limits();

		// A dynamic package has no fixed departures, so offer a sensible date
		// rather than today — nobody books a two-week trip starting tomorrow.
		$first_day = $d['departures']['is_empty']
			? gmdate( 'Y-m-d', time() + 21 * DAY_IN_SECONDS )
			: $d['departures']['first'];
		?>
		<div class="mwp mwp-package">

			<?php
			$shots = array();
			if ( $hero ) {
				$shots[] = $hero;
			}
			foreach ( $d['gallery'] as $g ) {
				if ( count( $shots ) >= 3 ) {
					break;
				}
				if ( ! in_array( $g, $shots, true ) ) {
					$shots[] = $g;
				}
			}
			?>

			<?php if ( $shots ) : ?>
				<div class="mwp-collage mwp-collage-<?php echo esc_attr( count( $shots ) ); ?>">
					<?php foreach ( $shots as $i => $shot ) : ?>
						<figure class="mwp-shot">
							<?php
							/*
							 * The first shot is the page's Largest Contentful
							 * Paint, so it is fetched at high priority and
							 * never lazy-loaded. It is also the one that was
							 * costing 1.3 MB: it is an attachment, so handing
							 * it to WordPress produces a srcset and the
							 * browser takes a file sized for the box.
							 */
							echo mwp_image_tag( // phpcs:ignore WordPress.Security.EscapeOutput
								$shot,
								$title,
								array(
									'attachment_id' => 0 === $i ? (int) get_post_thumbnail_id( $post_id ) : 0,
									'size'          => 'large',
									'sizes'         => 0 === $i
										? '(max-width: 779px) 100vw, 60vw'
										: '(max-width: 779px) 50vw, 30vw',
									'fetchpriority' => 0 === $i ? 'high' : '',
								)
							);
							?>
						</figure>
					<?php endforeach; ?>

					<?php if ( count( $d['gallery'] ) > 3 ) : ?>
						<a class="mwp-gallery-btn" href="#mwp-gallery">
							<?php echo esc_html( $t( 'Galeria zdjęć', 'Photo gallery' ) ); ?>
						</a>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<header class="mwp-head">
				<?php if ( $d['ribbon'] ) : ?>
					<span class="mwp-eyebrow"><?php echo esc_html( $d['ribbon'] ); ?></span>
				<?php endif; ?>

				<h1 class="mwp-title"><?php echo esc_html( $title ); ?></h1>

				<?php
				$summary = array();
				if ( $d['duration']['days'] ) {
					$summary[] = sprintf( $t( '%d dni', '%d days' ), $d['duration']['days'] );
				}
				if ( $d['destinations'] ) {
					$first = $d['destinations'][0]['name'];
					$last  = $d['destinations'][ count( $d['destinations'] ) - 1 ]['name'];
					$summary[] = $first === $last
						? $first
						: sprintf( $t( 'od %1$s do %2$s', 'from %1$s to %2$s' ), $first, $last );
				}
				?>
				<?php if ( $summary ) : ?>
					<p class="mwp-subline"><?php echo esc_html( implode( ', ', $summary ) ); ?></p>
				<?php endif; ?>
			</header>

			<div class="mwp-top">

				<aside class="mwp-aside">
					<div class="mwp-pricecard">
						<?php if ( $booking ) : ?>
							<div class="mwp-actions">
								<button type="button" class="mwp-btn mwp-btn-primary mwp-open-picker"
									data-target="mwp-picker-<?php echo esc_attr( $post_id ); ?>">
									<?php echo esc_html( $t( 'Dostosuj i zarezerwuj podróż', 'Customize & Book Your Trip' ) ); ?>
								</button>

								<?php if ( mwp_contact_form_id( $lang ) ) : ?>
									<a class="mwp-btn" href="#mwp-enquiry">
										<?php echo esc_html( $t( 'Kontakt', 'Contact us' ) ); ?>
									</a>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<?php if ( $price['value'] ) : ?>
							<p class="mwp-bar-amount">
								<span class="mwp-from-word"><?php echo esc_html( $t( 'od', 'from' ) ); ?></span>
								<?php echo esc_html( $price['value'] ); ?> <?php echo esc_html( $price['symbol'] ); ?>
							</p>
							<p class="mwp-price-basis">
								<?php
								echo esc_html( sprintf(
									$t( 'za osobę, przy %d osobach dorosłych', 'per person, based on %d adults' ),
									$adults
								) );
								?>
							</p>
						<?php endif; ?>

						<ul class="mwp-facts">
							<?php if ( $d['duration']['days'] ) : ?>
								<li class="mwp-fact"><b><?php echo esc_html( $d['duration']['days'] ); ?></b><span><?php echo esc_html( $t( 'dni', 'days' ) ); ?></span></li>
							<?php endif; ?>
							<?php if ( $d['duration']['nights'] ) : ?>
								<li class="mwp-fact"><b><?php echo esc_html( $d['duration']['nights'] ); ?></b><span><?php echo esc_html( $t( 'nocy', 'nights' ) ); ?></span></li>
							<?php endif; ?>
							<?php if ( $d['destinations'] ) : ?>
								<li class="mwp-fact"><b><?php echo esc_html( count( $d['destinations'] ) ); ?></b><span><?php echo esc_html( $t( 'miejsc', 'stops' ) ); ?></span></li>
							<?php endif; ?>
							<?php if ( $d['flights'] ) : ?>
								<li class="mwp-fact"><b><?php echo esc_html( count( $d['flights'] ) ); ?></b><span><?php echo esc_html( $t( 'przeloty', 'flights' ) ); ?></span></li>
							<?php endif; ?>
						</ul>

						<p class="mwp-note">
							<?php
							echo esc_html(
								$d['departures']['is_empty']
									? $t( 'Wylot w dowolnym terminie.', 'Departs any day you choose.' )
									: sprintf(
										$t( 'Najbliższy wylot: %s', 'Next departure: %s' ),
										date_i18n( get_option( 'date_format' ), strtotime( $d['departures']['first'] ) )
									)
							);
							?>
						</p>
					</div>
				</aside>

				<div class="mwp-main">

					<?php if ( $d['destinations'] ) : ?>
						<p class="mwp-dests">
							<b><?php echo esc_html( $t( 'Destynacje:', 'Destinations:' ) ); ?></b>
							<?php
							$labels = array();
							foreach ( $d['destinations'] as $dest ) {
								$labels[] = $dest['country']
									? $dest['name'] . ', ' . $dest['country']
									: $dest['name'];
							}
							echo esc_html( implode( ' · ', $labels ) );
							?>
						</p>
					<?php endif; ?>

					<?php if ( $d['themes'] ) : ?>
						<ul class="mwp-themes">
							<?php foreach ( $d['themes'] as $theme ) : ?>
								<li><?php echo esc_html( $theme ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>

					<?php if ( $d['description'] ) : ?>
						<section class="mwp-section">
							<h2><?php echo esc_html( $t( 'Opis podróży', 'About this trip' ) ); ?></h2>
							<div class="mwp-prose"><?php echo wp_kses_post( $d['description'] ); ?></div>
						</section>
					<?php endif; ?>

					<?php if ( $items ) : ?>
						<section class="mwp-section mwp-plan">
							<h2><?php echo esc_html( $t( 'Szczegółowy plan podróży', 'Your detailed trip plan' ) ); ?></h2>
							<p class="mwp-section-intro">
								<?php echo esc_html( $t( 'Przykładowy przebieg — każdy przelot, hotel i dzień możesz zmienić.', 'A suggested sequence — every flight, hotel and day can be changed.' ) ); ?>
							</p>

							<?php
							$counts = array_filter( array(
								$t( 'Destynacje', 'Destinations' )       => count( $d['destinations'] ),
								$t( 'Transport', 'Transport' )           => $d['counters']['transports'],
								$t( 'Zakwaterowanie', 'Accommodation' )  => count( $d['hotels'] ),
								$t( 'Transfery', 'Transfers' )           => $d['counters']['transfers'],
							) );
							?>
							<?php if ( $counts ) : ?>
								<ul class="mwp-includes">
									<?php foreach ( $counts as $label => $n ) : ?>
										<li><b><?php echo esc_html( $n ); ?></b><span><?php echo esc_html( $label ); ?></span></li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>

							<ol class="mwp-plan-list">
								<?php foreach ( $items as $item ) : ?>
									<?php if ( 'transport' === $item['kind'] ) : ?>
										<?php self::render_transport( $item, $t ); ?>
									<?php else : ?>
									<li class="mwp-item mwp-item-<?php echo esc_attr( $item['kind'] ); ?>">

										<div class="mwp-item-head">
											<span class="mwp-chip">
												<?php if ( $item['date'] ) : ?>
													<b><?php echo esc_html( date_i18n( 'd', $item['date'] ) ); ?></b>
													<span><?php echo esc_html( date_i18n( 'M', $item['date'] ) ); ?></span>
												<?php else : ?>
													<b><?php echo esc_html( $item['day'] ); ?></b>
													<span><?php echo esc_html( $t( 'dzień', 'day' ) ); ?></span>
												<?php endif; ?>
											</span>

											<h3 class="mwp-item-title"><?php echo esc_html( $item['title'] ); ?></h3>

											<span class="mwp-item-badge"><?php echo esc_html( $item['badge'] ); ?></span>
										</div>

										<div class="mwp-item-body">
											<?php if ( ! empty( $item['images'] ) ) : ?>
												<div class="mwp-item-gallery">
													<?php foreach ( $item['images'] as $img ) : ?>
														<?php
														echo mwp_image_tag( // phpcs:ignore WordPress.Security.EscapeOutput
															$img,
															$item['title'],
															array( 'size' => 'medium_large', 'sizes' => '(max-width: 779px) 92vw, 380px' )
														);
														?>
													<?php endforeach; ?>
												</div>
											<?php endif; ?>

											<div class="mwp-item-detail">
												<?php if ( $item['lead'] ) : ?>
													<p class="mwp-item-lead"><?php echo esc_html( $item['lead'] ); ?></p>
												<?php endif; ?>

												<?php if ( ! empty( $item['stars'] ) || ! empty( $item['score'] ) ) : ?>
													<p class="mwp-item-rating">
														<?php if ( ! empty( $item['stars'] ) ) : ?>
															<span class="mwp-stars"><?php echo esc_html( str_repeat( '★', (int) $item['stars'] ) ); ?></span>
														<?php endif; ?>
														<?php if ( ! empty( $item['score'] ) ) : ?>
															<span class="mwp-badge-score"><?php echo esc_html( number_format_i18n( $item['score']['score'], 1 ) ); ?></span>
															<span class="mwp-score-note">
																<?php echo esc_html( sprintf( $t( '%1$s · %2$s opinii', '%1$s · %2$s reviews' ), $item['score']['source'], number_format_i18n( $item['score']['reviews'] ) ) ); ?>
															</span>
														<?php endif; ?>
													</p>
												<?php endif; ?>

												<?php if ( ! empty( $item['meta'] ) ) : ?>
													<ul class="mwp-tags">
														<?php foreach ( $item['meta'] as $tag ) : ?>
															<li><?php echo esc_html( $tag ); ?></li>
														<?php endforeach; ?>
													</ul>
												<?php endif; ?>

												<?php if ( ! empty( $item['body'] ) ) : ?>
													<div class="mwp-item-text mwp-prose" data-mwp-more
														data-more="<?php echo esc_attr( $t( 'Zobacz więcej', 'See more' ) ); ?>"
														data-less="<?php echo esc_attr( $t( 'Zwiń', 'Show less' ) ); ?>"><?php echo wp_kses_post( $item['body'] ); ?></div>
												<?php endif; ?>
											</div>
										</div>
									</li>
									<?php endif; ?>
								<?php endforeach; ?>
							</ol>
						</section>
					<?php endif; ?>

					<?php foreach ( $d['tours'] as $tour ) : ?>
						<?php if ( ! $tour['included'] && ! $tour['not_included'] ) { continue; } ?>
						<section class="mwp-section">
							<h2><?php echo esc_html( $t( 'Co zawiera cena', 'What is included' ) ); ?></h2>
							<div class="mwp-inclusions">
								<?php if ( $tour['included'] ) : ?>
									<div class="mwp-inc">
										<h3><?php echo esc_html( $t( 'W cenie', 'Included' ) ); ?></h3>
										<?php echo wp_kses_post( $tour['included'] ); ?>
									</div>
								<?php endif; ?>
								<?php if ( $tour['not_included'] ) : ?>
									<div class="mwp-exc">
										<h3><?php echo esc_html( $t( 'Nie zawiera', 'Not included' ) ); ?></h3>
										<?php echo wp_kses_post( $tour['not_included'] ); ?>
									</div>
								<?php endif; ?>
							</div>
						</section>
					<?php endforeach; ?>

					<?php if ( count( $d['gallery'] ) > 3 ) : ?>
						<section class="mwp-section" id="mwp-gallery">
							<h2><?php echo esc_html( sprintf( $t( '%s w obrazach', '%s in pictures' ), $title ) ); ?></h2>
							<div class="mwp-gallery">
								<?php foreach ( array_slice( $d['gallery'], 0, 12 ) as $i => $url ) : ?>
									<?php
									echo mwp_image_tag( // phpcs:ignore WordPress.Security.EscapeOutput
										$url,
										sprintf( '%s — %d', $title, $i + 1 ),
										array( 'size' => 'medium_large', 'sizes' => '(max-width: 779px) 46vw, 300px' )
									);
									?>
								<?php endforeach; ?>
							</div>
						</section>
					<?php endif; ?>

					<?php $form_id = mwp_contact_form_id( $lang ); ?>
					<?php if ( $form_id ) : ?>
						<section class="mwp-section mwp-enquiry" id="mwp-enquiry">
							<h2><?php echo esc_html( $t( 'Zamów swój indywidualny plan podróży', 'Request your tailor-made plan' ) ); ?></h2>
							<p class="mwp-section-intro">
								<?php echo esc_html( $t( 'Napisz, czego szukasz — odpowiemy z propozycją dopasowaną do Ciebie.', 'Tell us what you are looking for and we will come back with a plan built around it.' ) ); ?>
							</p>
							<div class="mwp-form">
								<?php
								// The theme adds a hidden your-referrer field to every
								// CF7 form, so the enquiry arrives with the package
								// page it was sent from.
								echo do_shortcode( '[contact-form-7 id="' . esc_attr( $form_id ) . '"]' );
								?>
							</div>
						</section>
					<?php endif; ?>

					<section class="mwp-final">
						<h2><?php echo esc_html( $t( 'Ta podróż, po Twojemu', 'Make this trip yours' ) ); ?></h2>
						<p>
							<?php echo esc_html( $t( 'Zmień terminy, hotele, lotnisko wylotu i długość pobytu w każdym miejscu. Sprawdź aktualną cenę i dostępność w kilka sekund.', 'Change the dates, the hotels, your departure airport and how long you stay in each place. Check live pricing and availability in seconds.' ) ); ?>
						</p>
						<?php if ( $booking ) : ?>
							<a class="mwp-btn mwp-btn-primary mwp-btn-wide" href="<?php echo esc_url( $booking ); ?>" target="_blank" rel="noopener">
								<?php echo esc_html( $t( 'Zarezerwuj teraz', 'Book now' ) ); ?>
							</a>
						<?php endif; ?>
						<?php if ( $parent ) : ?>
							<br>
							<a class="mwp-back" href="<?php echo esc_url( get_permalink( $parent ) ); ?>">
								<?php echo esc_html( sprintf( $t( '← Więcej podróży: %s', '← More trips: %s' ), get_the_title( $parent ) ) ); ?>
							</a>
						<?php endif; ?>
					</section>

				</div>
			</div>

			<p class="mwp-ref">
				<?php echo esc_html( $t( 'Nr pakietu', 'Package ref' ) ); ?>
				<a href="<?php echo esc_url( mwp_booking_url( $d, $lang ) ); ?>" target="_blank" rel="noopener nofollow">
					<?php echo esc_html( $d['id'] ); ?>
				</a>
			</p>

			<?php if ( $booking ) : ?>
				<!--
					The same question the booking engine asks on arrival — start
					date and party size — asked here instead, and presented as an
					overlay so it reads as one continuous flow rather than a
					second form appearing after the visitor has already left.
				-->
				<div class="mwp-modal" id="mwp-picker-<?php echo esc_attr( $post_id ); ?>" hidden
					role="dialog" aria-modal="true"
					aria-label="<?php echo esc_attr( $t( 'Wybierz datę rozpoczęcia podróży', 'Choose your start date' ) ); ?>">

					<div class="mwp-modal-backdrop" data-mwp-close></div>

					<div class="mwp-modal-panel"
						data-mwp-picker
						data-url="<?php echo esc_url( $booking ); ?>"
						data-deeplink="<?php echo esc_url( mwp_deeplink_url( $d['id'] ) ); ?>"
						data-max-pax="<?php echo esc_attr( $limits['max_pax'] ); ?>"
						data-max-rooms="<?php echo esc_attr( $limits['max_rooms'] ); ?>"
						data-adults="<?php echo esc_attr( min( $limits['max_pax'], max( 1, $adults ) ) ); ?>">

						<button type="button" class="mwp-modal-close" data-mwp-close
							aria-label="<?php esc_attr_e( 'Close', 'multiwander-packages' ); ?>">&times;</button>

						<h2 class="mwp-modal-title">
							<?php echo esc_html( $t( 'Wybierz datę rozpoczęcia podróży', 'Choose your start date' ) ); ?>
						</h2>

						<div class="mwp-modal-row">
							<label class="mwp-field">
								<span><?php echo esc_html( $t( 'Data rozpoczęcia', 'Start date' ) ); ?></span>
								<?php
								/*
								 * The departures Travel Compositor actually sells.
								 *
								 * Most packages here are dynamic and depart any day,
								 * and for those this list is empty and the calendar
								 * stays fully open. But a Nile cruise sails once a
								 * week, and a calendar that accepts any of the other
								 * six days sends the visitor to the booking engine to
								 * be told no — the one thing this panel exists to
								 * prevent. Where Travel Compositor gives dates, they
								 * are the only dates offered.
								 */
								$departures = $d['departures']['is_empty']
									? array()
									: array_slice( (array) $d['departures']['dates'], 0, 500 );
								?>
								<input type="date" class="mwp-date"
									value="<?php echo esc_attr( $first_day ); ?>"
									<?php if ( $departures ) : ?>
										data-departures="<?php echo esc_attr( implode( ' ', $departures ) ); ?>"
									<?php endif; ?>
									min="<?php echo esc_attr( $departures ? $departures[0] : current_time( 'Y-m-d' ) ); ?>">
							</label>

							<div class="mwp-field">
								<span><?php echo esc_html( $t( 'Liczba: pasażerów i pokoi', 'Travellers & rooms' ) ); ?></span>

								<button type="button" class="mwp-party-toggle" aria-expanded="false">
									<span class="mwp-party-summary"></span>
									<span class="mwp-caret" aria-hidden="true">&#9662;</span>
								</button>

								<?php
								/*
								 * The booking engine asks room by room, not for a single
								 * headcount: each room carries its own adults, its own
								 * children, and an age for every child. Anything less and
								 * the engine re-asks on arrival, which is the whole thing
								 * this panel exists to avoid. The rooms are therefore
								 * built in JavaScript — they are added and removed — and
								 * every word they need is handed over here so the panel
								 * speaks the page's language.
								 */
								$strings = array(
									'room'     => $t( 'Pokój', 'Room' ),
									'remove'   => $t( 'Usunąć', 'Remove' ),
									'adults'   => $t( 'Dorośli', 'Adults' ),
									'adultsHint'   => $t( 'od 18 lat', '18 and over' ),
									'children' => $t( 'Dzieci', 'Children' ),
									'childrenHint' => $t( '0 – 17 lat', '0 – 17 years' ),
									'addRoom'  => $t( '+ Dodaj pokój', '+ Add room' ),
									'childAge' => $t( 'Wiek dziecka', 'Child age' ),
									'years'    => $t( 'lat', 'years' ),
									'under1'   => $t( 'do 1 roku', 'under 1' ),
									'ageNote'  => $t( '*Proszę podać wiek dziecka w ostatnim dniu podróży', '*Please give each child\'s age on the last day of travel' ),
									'roomWord' => array( $t( 'pokój', 'room' ), $t( 'pokoje', 'rooms' ) ),
									'adultWord'  => array( $t( 'dorosły', 'adult' ), $t( 'dorośli', 'adults' ) ),
									'childWord'  => array( $t( 'dziecko', 'child' ), $t( 'dzieci', 'children' ) ),
									'capacity' => sprintf( $t( 'Maksymalnie %1$d osób i %2$d pokoje.', 'Up to %1$d travellers and %2$d rooms.' ), $limits['max_pax'], $limits['max_rooms'] ),
								);
								?>
								<div class="mwp-party" hidden
									data-strings="<?php echo esc_attr( wp_json_encode( $strings ) ); ?>">

									<div class="mwp-rooms" data-mwp-rooms></div>

									<button type="button" class="mwp-addroom">
										<?php echo esc_html( $strings['addRoom'] ); ?>
									</button>

									<p class="mwp-party-note mwp-age-note" hidden>
										<?php echo esc_html( $strings['ageNote'] ); ?>
									</p>

									<p class="mwp-party-note">
										<?php echo esc_html( $strings['capacity'] ); ?>
									</p>

									<button type="button" class="mwp-btn mwp-btn-primary mwp-party-done">
										<?php echo esc_html( $t( 'Dostosuj i zarezerwuj podróż', 'Customize & Book Your Trip' ) ); ?>
									</button>
								</div>
							</div>

							<a class="mwp-btn mwp-btn-primary mwp-search"
								href="<?php echo esc_url( mwp_deeplink_url( $d['id'], $first_day, $adults, 0 ) ); ?>" target="_blank" rel="noopener">
								<?php echo esc_html( $t( 'Szukaj', 'Search' ) ); ?>
							</a>
						</div>

						<p class="mwp-modal-note">
							<?php echo esc_html( $t( 'Terminy, hotele i lotnisko wylotu możesz zmienić w kolejnym kroku.', 'Dates, hotels and departure airport can all be changed in the next step.' ) ); ?>
						</p>
					</div>
				</div>
			<?php endif; ?>

		</div>
		<?php
	}

	/**
	 * Hero image: manual override, then the imported featured image, then the
	 * Travel Compositor URL as a last resort.
	 *
	 * @param int   $post_id Post.
	 * @param array $data    Payload.
	 * @return string
	 */
	public static function hero_url( $post_id, array $data ) {
		$override = get_post_meta( $post_id, MWP_META_IMAGE, true );
		if ( $override ) {
			return $override;
		}

		if ( has_post_thumbnail( $post_id ) ) {
			$url = get_the_post_thumbnail_url( $post_id, 'large' );
			if ( $url ) {
				return $url;
			}
		}

		if ( ! empty( $data['hero_image'] ) ) {
			return $data['hero_image'];
		}

		// Last resort: the first gallery image, so a package without its own
		// hero still leads with a picture rather than a blank block.
		return ! empty( $data['gallery'][0] ) ? $data['gallery'][0] : '';
	}

	/**
	 * One transport leg in the timeline — a flight, train, bus or ferry that
	 * moves the traveller from one stop to the next.
	 *
	 * Styled as a connector card rather than a stay card: no gallery or rating,
	 * but a clear origin → duration → destination route with the carrier and
	 * baggage, so the journey between destinations reads as well as the stays
	 * themselves. Modelled on the booking engine's own transport cards.
	 *
	 * @param array    $item One timeline item with kind 'transport'.
	 * @param callable $t    PL/EN string picker from render_package().
	 * @return void
	 */
	protected static function render_transport( array $item, $t ) {
		$mode = isset( $item['mode'] ) ? $item['mode'] : 'transport';
		?>
		<li class="mwp-item mwp-item-transport mwp-mode-<?php echo esc_attr( $mode ); ?>">
			<div class="mwp-item-head">
				<span class="mwp-chip mwp-chip-transport">
					<?php if ( $item['date'] ) : ?>
						<b><?php echo esc_html( date_i18n( 'd', $item['date'] ) ); ?></b>
						<span><?php echo esc_html( date_i18n( 'M', $item['date'] ) ); ?></span>
					<?php else : ?>
						<b><?php echo esc_html( $item['day'] ); ?></b>
						<span><?php echo esc_html( $t( 'dzień', 'day' ) ); ?></span>
					<?php endif; ?>
				</span>

				<h3 class="mwp-item-title"><?php echo esc_html( $item['title'] ); ?></h3>

				<span class="mwp-item-badge mwp-badge-transport">
					<?php echo self::transport_icon( $mode ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<span><?php echo esc_html( $item['badge'] ); ?></span>
				</span>
			</div>

			<div class="mwp-transport">
				<div class="mwp-transport-top">
					<span class="mwp-transport-ico"><?php echo self::transport_icon( $mode ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
					<span class="mwp-transport-carrier">
						<?php if ( ! empty( $item['carrier'] ) ) : ?>
							<b><?php echo esc_html( $item['carrier'] ); ?></b>
						<?php endif; ?>
						<?php if ( ! empty( $item['stops_label'] ) ) : ?>
							<span class="mwp-transport-stops"><?php echo esc_html( $item['stops_label'] ); ?></span>
						<?php endif; ?>
					</span>
					<?php if ( ! empty( $item['baggage'] ) ) : ?>
						<span class="mwp-transport-bag"><?php echo esc_html( $item['baggage'] ); ?></span>
					<?php endif; ?>
				</div>

				<?php if ( ! empty( $item['from_label'] ) || ! empty( $item['to_label'] ) ) : ?>
				<div class="mwp-transport-route">
					<span class="mwp-route-end mwp-route-from">
						<?php if ( ! empty( $item['from_time'] ) ) : ?>
							<span class="mwp-route-time"><?php echo esc_html( $item['from_time'] ); ?></span>
						<?php endif; ?>
						<span class="mwp-route-place"><?php echo esc_html( $item['from_label'] ); ?></span>
					</span>

					<span class="mwp-route-line">
						<?php if ( ! empty( $item['duration'] ) ) : ?>
							<span class="mwp-route-dur"><?php echo esc_html( $item['duration'] ); ?></span>
						<?php endif; ?>
					</span>

					<span class="mwp-route-end mwp-route-to">
						<?php if ( ! empty( $item['to_time'] ) ) : ?>
							<span class="mwp-route-time"><?php echo esc_html( $item['to_time'] ); ?></span>
						<?php endif; ?>
						<span class="mwp-route-place"><?php echo esc_html( $item['to_label'] ); ?></span>
					</span>
				</div>
				<?php endif; ?>
			</div>
		</li>
		<?php
	}

	/**
	 * Inline SVG for a transport mode. Inlined rather than an icon font so the
	 * timeline carries no extra request and the mark inherits currentColor.
	 *
	 * @param string $mode flight|train|bus|ferry|transport.
	 * @return string SVG markup.
	 */
	protected static function transport_icon( $mode ) {
		$svg = array(
			'flight' => '<path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z"/>',
			'train'  => '<path d="M12 2c-4 0-8 .5-8 4v9.5A3.5 3.5 0 0 0 7.5 19L6 20.5V21h12v-.5L16.5 19a3.5 3.5 0 0 0 3.5-3.5V6c0-3.5-4-4-8-4zM7.5 17A1.5 1.5 0 1 1 9 15.5 1.5 1.5 0 0 1 7.5 17zm3.5-7H6V6h5zm2 0V6h5v4zm3.5 7a1.5 1.5 0 1 1 1.5-1.5 1.5 1.5 0 0 1-1.5 1.5z"/>',
			'bus'    => '<path d="M4 16c0 .88.39 1.67 1 2.22V20a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1h8v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1.78c.61-.55 1-1.34 1-2.22V6c0-3.5-3.58-4-8-4s-8 .5-8 4zm3.5 1A1.5 1.5 0 1 1 9 15.5 1.5 1.5 0 0 1 7.5 17zm9 0a1.5 1.5 0 1 1 1.5-1.5 1.5 1.5 0 0 1-1.5 1.5zM18 11H6V6h12z"/>',
			'ferry'  => '<path d="M20 21c-1.4 0-2.6-.7-3.5-1.5C15.6 20.3 14.4 21 13 21s-2.6-.7-3.5-1.5C8.6 20.3 7.4 21 6 21H4v-2h2c1.4 0 2.6-.9 3.5-1.9C10.4 18.1 11.6 19 13 19s2.6-.9 3.5-1.9C17.4 18.1 18.6 19 20 19h0v2zM5 15l1.5-5.5a2 2 0 0 1 1.9-1.5H11V5H8V3h8v2h-3v3h2.6a2 2 0 0 1 1.9 1.5L19 15a9 9 0 0 1-3.5-1.3A9 9 0 0 1 12 15a9 9 0 0 1-3.5-1.3A9 9 0 0 1 5 15z"/>',
		);
		$path = isset( $svg[ $mode ] ) ? $svg[ $mode ] : $svg['flight'];

		return '<svg class="mwp-mode-ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $path . '</svg>';
	}
}
