<?php
/**
 * Admin: the ID box on country pages, the settings/status screen, and a raw
 * JSON viewer for when a field needs checking against the real response.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Admin {

	const NOTICE_TRANSIENT = 'mwp_sync_notice_';

	public static function init() {
		add_action( 'add_meta_boxes_page', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post_page', array( __CLASS__, 'save_page' ), 20, 3 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'admin_post_mwp_resync', array( __CLASS__, 'handle_resync' ) );
		// Kept for anyone with a direct admin-post.php link already out in the
		// wild, but the Social Kit page itself now links to maybe_render_flyer()
		// below instead — see the comment there for why.
		add_action( 'admin_post_mwp_flyer', array( __CLASS__, 'render_flyer' ) );
		// admin-post.php is a different URL from the Social Kit page a travel
		// agent can already open, and on sites that lock wp-admin down to a
		// per-page allowlist (a security/membership plugin, or a reverse-proxy
		// rule) that difference is enough for admin-post.php to be silently
		// blocked for a role which was only ever granted the Social Kit page
		// itself — which looks exactly like "a new tab opens, nothing is in
		// it, and I'm back on Social Kit". Building the flyer from inside the
		// Social Kit page's own load sidesteps that entirely: it is the same
		// URL, the same page hook, the same allowlist entry.
		add_action( 'load-toplevel_page_mwp-social', array( __CLASS__, 'maybe_render_flyer' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'display_post_states', array( __CLASS__, 'post_state' ), 10, 2 );
	}

	/**
	 * Load the admin stylesheet only where it is used.
	 *
	 * @param string $hook Current screen.
	 * @return void
	 */
	public static function assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php', 'settings_page_mwp-settings' ), true ) ) {
			return;
		}
		wp_enqueue_style( 'mwp-admin', MWP_URL . 'assets/admin.css', array(), MWPP_asset_version( 'assets/admin.css' ) );

		// This was missing, and it is the whole reason the × next to an ID did
		// nothing: the script that removes a row, adds a row and strips a
		// pasted URL down to its digits was shipped but never loaded, so the
		// ID boxes were plain inputs with dead buttons beside them.
		wp_enqueue_script(
			'mwp-admin',
			MWP_URL . 'assets/admin.js',
			array(),
			MWPP_asset_version( 'assets/admin.js' ),
			true
		);
	}

	/**
	 * Mark generated pages in the Pages list so they are easy to spot.
	 *
	 * @param array   $states Existing states.
	 * @param WP_Post $post   Post.
	 * @return array
	 */
	public static function post_state( $states, $post ) {
		if ( get_post_meta( $post->ID, MWP_META_ID, true ) ) {
			$states['mwp'] = __( 'Travel package', 'multiwander-packages' );
		}
		return $states;
	}

	// -----------------------------------------------------------------
	// Meta boxes
	// -----------------------------------------------------------------

	public static function add_meta_boxes( $post ) {
		add_meta_box(
			'mwp-country-packages',
			__( 'Travel packages on this page', 'multiwander-packages' ),
			array( __CLASS__, 'render_country_box' ),
			'page',
			'normal',
			'high'
		);

		if ( get_post_meta( $post->ID, MWP_META_ID, true ) ) {
			add_meta_box(
				'mwp-package-info',
				__( 'Travel Compositor package', 'multiwander-packages' ),
				array( __CLASS__, 'render_package_box' ),
				'page',
				'side',
				'high'
			);
		}
	}

	/**
	 * The box where the editor pastes package IDs.
	 *
	 * @param WP_Post $post Country page.
	 * @return void
	 */
	public static function render_country_box( $post ) {
		wp_nonce_field( 'mwp_save_' . $post->ID, 'mwp_nonce' );

		$source = MWP_Sync::source_country_id( $post->ID );
		$raw    = get_post_meta( $source, MWP_META_IDS, true );
		$ids    = MWP_Sync::get_package_ids( $source );

		if ( $source !== $post->ID ) {
			echo '<div class="notice notice-info inline"><p>' .
				sprintf(
					/* translators: %s: link to the Polish page */
					esc_html__( 'Packages for this page are managed on its Polish version: %s', 'multiwander-packages' ),
					'<a href="' . esc_url( (string) get_edit_post_link( $source ) ) . '">' . esc_html( get_the_title( $source ) ) . '</a>'
				) .
				'</p></div>';
		}

		if ( ! MWP_Client::is_configured() ) {
			echo '<div class="notice notice-error inline"><p><strong>' .
				esc_html__( 'Travel Compositor credentials are missing.', 'multiwander-packages' ) .
				'</strong> <a href="' . esc_url( admin_url( 'options-general.php?page=mwp-settings' ) ) . '">' .
				esc_html__( 'Add them in Settings → MultiWander Packages', 'multiwander-packages' ) .
				'</a>.</p></div>';
		}
		?>
		<p class="mwp-help">
			<strong><?php esc_html_e( 'One Holiday Package ID per box — numbers only.', 'multiwander-packages' ); ?></strong>
			<?php esc_html_e( 'The order of the boxes is the order the offers appear on the page — use the ▲ ▼ arrows to reorder them, then update the page. Pasting a whole momira.travel or book.multiwander.com address works too — the ID is picked out of it.', 'multiwander-packages' ); ?>
		</p>

		<div class="mwp-ids" data-mwp-ids>
			<?php
			// One row per ID, plus a spare so there is always somewhere to type.
			$rows = $ids;
			$rows[] = '';

			foreach ( $rows as $index => $value ) :
				$page_id = $value ? MWP_Sync::find_package_page( $value, 'pl' ) : 0;
				?>
				<div class="mwp-id-row">
					<span class="mwp-id-num"><?php echo esc_html( $index + 1 ); ?>.</span>

					<input type="text"
						name="mwp_package_ids[]"
						value="<?php echo esc_attr( $value ); ?>"
						class="mwp-id-input"
						inputmode="numeric"
						autocomplete="off"
						spellcheck="false"
						maxlength="12"
						placeholder="59875907">

					<span class="mwp-id-note">
						<?php if ( $page_id ) : ?>
							<span class="mwp-ok">&#10003;</span>
							<a href="<?php echo esc_url( (string) get_edit_post_link( $page_id ) ); ?>"><?php echo esc_html( get_the_title( $page_id ) ); ?></a>
						<?php endif; ?>
					</span>

					<span class="mwp-id-move">
						<button type="button" class="button-link mwp-id-up" aria-label="<?php esc_attr_e( 'Move offer up', 'multiwander-packages' ); ?>" title="<?php esc_attr_e( 'Move up', 'multiwander-packages' ); ?>">&#9650;</button>
						<button type="button" class="button-link mwp-id-down" aria-label="<?php esc_attr_e( 'Move offer down', 'multiwander-packages' ); ?>" title="<?php esc_attr_e( 'Move down', 'multiwander-packages' ); ?>">&#9660;</button>
					</span>

					<button type="button" class="button-link mwp-id-remove" aria-label="<?php esc_attr_e( 'Remove this ID', 'multiwander-packages' ); ?>">&times;</button>
				</div>
			<?php endforeach; ?>
		</div>

		<p>
			<button type="button" class="button mwp-id-add"><?php esc_html_e( '+ Add another package', 'multiwander-packages' ); ?></button>
		</p>

		<?php
		$heading = get_post_meta( $source, MWP_META_HEADING, true );
		$sub     = get_post_meta( $source, MWP_META_SUB, true );
		$layout  = get_post_meta( $source, MWP_META_LAYOUT, true );
		$layout  = $layout ? $layout : 'auto';
		?>

		<table class="form-table mwp-form">
			<tr>
				<th><label for="mwp_offers_heading"><?php esc_html_e( 'Section title', 'multiwander-packages' ); ?></label></th>
				<td>
					<input type="text" id="mwp_offers_heading" name="mwp_offers_heading" class="large-text"
						value="<?php echo esc_attr( $heading ); ?>"
						placeholder="<?php esc_attr_e( 'Nasze wycieczki łączone po Kambodży', 'multiwander-packages' ); ?>">
					<span class="mwp-help"><?php esc_html_e( 'Shown above the offers as a heading. Leave empty for no title.', 'multiwander-packages' ); ?></span>
				</td>
			</tr>
			<tr>
				<th><label for="mwp_offers_sub"><?php esc_html_e( 'Subtitle', 'multiwander-packages' ); ?></label></th>
				<td>
					<input type="text" id="mwp_offers_sub" name="mwp_offers_sub" class="large-text"
						value="<?php echo esc_attr( $sub ); ?>"
						placeholder="<?php esc_attr_e( 'Zacznij od przykładowego pakietu – zmień loty, hotele i transfery.', 'multiwander-packages' ); ?>">
					<span class="mwp-help"><?php esc_html_e( 'Optional line under the title.', 'multiwander-packages' ); ?></span>
				</td>
			</tr>
			<tr>
				<th><label for="mwp_offers_layout"><?php esc_html_e( 'Layout', 'multiwander-packages' ); ?></label></th>
				<td>
					<select id="mwp_offers_layout" name="mwp_offers_layout">
						<option value="auto" <?php selected( $layout, 'auto' ); ?>><?php esc_html_e( 'Automatic — chosen by how many offers there are', 'multiwander-packages' ); ?></option>
						<option value="row" <?php selected( $layout, 'row' ); ?>><?php esc_html_e( 'Row — three side by side', 'multiwander-packages' ); ?></option>
						<option value="duo" <?php selected( $layout, 'duo' ); ?>><?php esc_html_e( 'Two — a pair of large cards', 'multiwander-packages' ); ?></option>
						<option value="slider" <?php selected( $layout, 'slider' ); ?>><?php esc_html_e( 'Slider — swipeable carousel', 'multiwander-packages' ); ?></option>
						<option value="single" <?php selected( $layout, 'single' ); ?>><?php esc_html_e( 'Single — one large offer', 'multiwander-packages' ); ?></option>
					</select>
					<span class="mwp-help"><?php esc_html_e( '1 offer → one centred card · 2 → a pair · 3 → a full row · 4 or more → a slider.', 'multiwander-packages' ); ?></span>
				</td>
			</tr>
		</table>

		<p class="mwp-help">
			<?php
			printf(
				/* translators: %s: shortcode */
				esc_html__( 'The offers appear only where you put %s in the page content instead — everything above still applies.', 'multiwander-packages' ),
				'<code>[multiwander_offers]</code>'
			);
			?>
		</p>

		<?php if ( $ids ) : ?>
			<table class="widefat striped mwp-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'ID', 'multiwander-packages' ); ?></th>
						<th><?php esc_html_e( 'Page', 'multiwander-packages' ); ?></th>
						<th><?php esc_html_e( 'Last synced', 'multiwander-packages' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $ids as $id ) : ?>
					<?php
					$pl     = MWP_Sync::find_package_page( $id, 'pl' );
					$synced = $pl ? get_post_meta( $pl, MWP_META_SYNCED, true ) : '';
					?>
					<tr>
						<td><code><?php echo esc_html( $id ); ?></code></td>
						<td>
							<?php if ( $pl ) : ?>
								<a href="<?php echo esc_url( get_edit_post_link( $pl ) ); ?>"><?php echo esc_html( get_the_title( $pl ) ); ?></a><br>
								<a href="<?php echo esc_url( get_permalink( $pl ) ); ?>" target="_blank" rel="noopener" class="mwp-permalink"><?php echo esc_html( wp_make_link_relative( get_permalink( $pl ) ) ); ?></a>
							<?php else : ?>
								<em><?php esc_html_e( 'Not created yet — update the page to sync.', 'multiwander-packages' ); ?></em>
							<?php endif; ?>
						</td>
						<td><?php echo $synced ? esc_html( $synced ) : '—'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<p>
				<a class="button" href="<?php echo esc_url( self::resync_url( $source ) ); ?>">
					<?php esc_html_e( 'Re-sync now', 'multiwander-packages' ); ?>
				</a>
				<span class="mwp-help"><?php esc_html_e( 'Refreshes prices and content without editing the page.', 'multiwander-packages' ); ?></span>
			</p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Sidebar box on a generated package page.
	 *
	 * @param WP_Post $post Package page.
	 * @return void
	 */
	public static function render_package_box( $post ) {
		$id     = get_post_meta( $post->ID, MWP_META_ID, true );
		$data   = MWP_Sync::get_data( $post->ID );
		$locked = get_post_meta( $post->ID, MWP_META_LOCKED, true );

		wp_nonce_field( 'mwp_save_' . $post->ID, 'mwp_nonce' );

		echo '<p><strong>' . esc_html__( 'Package ID', 'multiwander-packages' ) . ':</strong> <code>' . esc_html( $id ) . '</code></p>';

		if ( $data ) {
			$price = mwp_format_price( $data['price'], 'pl' );
			echo '<p><strong>' . esc_html__( 'Price from', 'multiwander-packages' ) . ':</strong> ' .
				esc_html( $price['value'] . ' ' . $price['symbol'] );
			if ( ! empty( $price['converted'] ) ) {
				echo ' <span class="mwp-help">' . esc_html__( '(converted from EUR)', 'multiwander-packages' ) . '</span>';
			}
			echo '</p>';

			echo '<p><strong>' . esc_html__( 'Trip', 'multiwander-packages' ) . ':</strong> ' .
				esc_html( sprintf( '%d dni / %d nocy', $data['duration']['days'], $data['duration']['nights'] ) ) . '</p>';

			if ( ! empty( $data['booking_url'] ) ) {
				echo '<p><a href="' . esc_url( $data['booking_url'] ) . '" target="_blank" rel="noopener">' .
					esc_html__( 'Open in Travel Compositor', 'multiwander-packages' ) . '</a></p>';
			}
		}

		echo '<p><label><input type="checkbox" name="mwp_slug_locked" value="1" ' . checked( $locked, '1', false ) . '> ' .
			esc_html__( 'Keep this URL — do not regenerate the slug from the title', 'multiwander-packages' ) .
			'</label></p>';

		$override = get_post_meta( $post->ID, MWP_META_IMAGE, true );
		echo '<p><label for="mwp_image_override"><strong>' . esc_html__( 'Hero image override', 'multiwander-packages' ) . '</strong></label>';
		echo '<input type="url" id="mwp_image_override" name="mwp_image_override" class="widefat" value="' . esc_attr( $override ) . '" placeholder="https://multiwander.com/wp-content/uploads/...">';
		echo '<span class="mwp-help">' . esc_html__( 'Leave empty to use the image from Travel Compositor.', 'multiwander-packages' ) . '</span></p>';

		echo '<p><a class="button" href="' . esc_url( self::debug_url( $id ) ) . '">' .
			esc_html__( 'View raw API response', 'multiwander-packages' ) . '</a></p>';
	}

	// -----------------------------------------------------------------
	// Saving
	// -----------------------------------------------------------------

	/**
	 * Persist the meta box fields, then sync.
	 *
	 * @param int     $post_id Post.
	 * @param WP_Post $post    Post object.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public static function save_page( $post_id, $post, $update ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( ! isset( $_POST['mwp_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mwp_nonce'] ) ), 'mwp_save_' . $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Fields on a generated package page.
		if ( get_post_meta( $post_id, MWP_META_ID, true ) ) {
			update_post_meta( $post_id, MWP_META_LOCKED, isset( $_POST['mwp_slug_locked'] ) ? '1' : '' );

			$override = isset( $_POST['mwp_image_override'] ) ? esc_url_raw( wp_unslash( $_POST['mwp_image_override'] ) ) : '';
			update_post_meta( $post_id, MWP_META_IMAGE, $override );
		}

		// Fields on a country page.
		if ( ! isset( $_POST['mwp_package_ids'] ) ) {
			return;
		}

		// Always store and sync against the Polish original: Polish is the
		// source language and the Polish country page is the parent the
		// package pages hang off. Editing the English page must not build the
		// tree under the English parent.
		$submitted = wp_unslash( $_POST['mwp_package_ids'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		// The box is now one field per package. A plain string may still arrive
		// from an older saved layout or a programmatic save, so handle both.
		$lines = is_array( $submitted )
			? array_map( 'sanitize_text_field', $submitted )
			: preg_split( '/[\r\n]+/', sanitize_textarea_field( $submitted ) );

		$source = MWP_Sync::source_country_id( $post_id );

		// Normalise to bare numeric IDs and say plainly which entries could not
		// be read, rather than dropping them in silence.
		$clean    = array();
		$rejected = array();

		foreach ( (array) $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$id = mwp_extract_id( $line );
			if ( '' === $id ) {
				$rejected[] = $line;
			} elseif ( ! in_array( $id, $clean, true ) ) {
				$clean[] = $id;
			}
		}

		update_post_meta( $source, MWP_META_IDS, implode( "\n", $clean ) );

		if ( isset( $_POST['mwp_offers_heading'] ) ) {
			update_post_meta( $source, MWP_META_HEADING, sanitize_text_field( wp_unslash( $_POST['mwp_offers_heading'] ) ) );
		}
		if ( isset( $_POST['mwp_offers_sub'] ) ) {
			update_post_meta( $source, MWP_META_SUB, sanitize_text_field( wp_unslash( $_POST['mwp_offers_sub'] ) ) );
		}
		if ( isset( $_POST['mwp_offers_layout'] ) ) {
			$layout = sanitize_key( wp_unslash( $_POST['mwp_offers_layout'] ) );
			update_post_meta( $source, MWP_META_LAYOUT, in_array( $layout, array( 'auto', 'row', 'duo', 'slider', 'single' ), true ) ? $layout : 'auto' );
		}

		// Whichever language the editor was working in, both country pages end
		// up carrying the same list.
		MWP_Sync::mirror_settings( $source );

		if ( $rejected ) {
			set_transient(
				self::NOTICE_TRANSIENT . 'bad_' . get_current_user_id(),
				$rejected,
				60
			);
		}

		if ( ! $clean || ! MWP_Client::is_configured() ) {
			return;
		}

		// Pressing Update means "go and look now". Without dropping the cached
		// responses first, a sync started from here could rewrite the page with
		// an hour-old price and look like it had done nothing.
		MWP_Client::flush_cache();

		// Avoid recursion: sync_package writes pages, which fires save_post.
		remove_action( 'save_post_page', array( __CLASS__, 'save_page' ), 20 );
		$sync   = new MWP_Sync();
		$result = $sync->sync_country_page( $source );
		add_action( 'save_post_page', array( __CLASS__, 'save_page' ), 20, 3 );

		self::store_notice( $source, $result );
	}

	// -----------------------------------------------------------------
	// Manual re-sync
	// -----------------------------------------------------------------

	public static function resync_url( $country_id ) {
		return wp_nonce_url(
			admin_url( 'admin-post.php?action=mwp_resync&post=' . (int) $country_id ),
			'mwp_resync_' . (int) $country_id
		);
	}

	public static function debug_url( $package_id ) {
		return admin_url( 'options-general.php?page=mwp-settings&mwp_debug=' . rawurlencode( $package_id ) );
	}

	public static function handle_resync() {
		$country_id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;

		if ( ! $country_id || ! current_user_can( 'edit_post', $country_id ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'multiwander-packages' ) );
		}
		check_admin_referer( 'mwp_resync_' . $country_id );

		MWP_Client::flush_cache();

		$sync   = new MWP_Sync();
		$result = $sync->sync_country_page( $country_id );
		self::store_notice( $country_id, $result );

		wp_safe_redirect( get_edit_post_link( $country_id, 'raw' ) );
		exit;
	}

	// -----------------------------------------------------------------
	// Notices
	// -----------------------------------------------------------------

	protected static function store_notice( $post_id, array $result ) {
		set_transient( self::NOTICE_TRANSIENT . get_current_user_id(), array(
			'post'   => $post_id,
			'result' => $result,
		), 60 );
	}

	public static function notices() {
		$bad_key  = self::NOTICE_TRANSIENT . 'bad_' . get_current_user_id();
		$rejected = get_transient( $bad_key );
		if ( $rejected ) {
			delete_transient( $bad_key );
			echo '<div class="notice notice-warning is-dismissible"><p><strong>' .
				esc_html__( 'These entries were not a package ID and have been removed:', 'multiwander-packages' ) .
				'</strong></p><ul style="margin-left:1.5em;list-style:disc">';
			foreach ( (array) $rejected as $line ) {
				echo '<li><code>' . esc_html( $line ) . '</code></li>';
			}
			echo '</ul><p>' . esc_html__( 'A package ID is a number, for example 59875907. One per box.', 'multiwander-packages' ) . '</p></div>';
		}

		$key    = self::NOTICE_TRANSIENT . get_current_user_id();
		$notice = get_transient( $key );
		if ( ! $notice ) {
			return;
		}
		delete_transient( $key );

		$r = $notice['result'];

		if ( ! empty( $r['synced'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>';
			printf(
				esc_html(
					/* translators: %d: number of packages */
					_n( '%d travel package synced.', '%d travel packages synced.', count( $r['synced'] ), 'multiwander-packages' )
				),
				count( $r['synced'] )
			);
			echo '</p><ul style="margin-left:1.5em;list-style:disc">';
			foreach ( $r['synced'] as $id => $one ) {
				echo '<li><a href="' . esc_url( $one['url'] ) . '" target="_blank" rel="noopener">' .
					esc_html( $one['title'] ) . '</a> <code>' . esc_html( $id ) . '</code></li>';
			}
			echo '</ul></div>';
		}

		foreach ( (array) $r['warnings'] as $id => $messages ) {
			foreach ( (array) $messages as $message ) {
				echo '<div class="notice notice-warning is-dismissible"><p><code>' .
					esc_html( $id ) . '</code> — ' . esc_html( $message ) . '</p></div>';
			}
		}

		foreach ( (array) $r['errors'] as $id => $message ) {
			echo '<div class="notice notice-error is-dismissible"><p><code>' .
				esc_html( $id ) . '</code> — ' . esc_html( $message ) . '</p></div>';
		}
	}

	// -----------------------------------------------------------------
	// Settings / status screen
	// -----------------------------------------------------------------

	public static function menu() {
		add_options_page(
			__( 'MultiWander Packages', 'multiwander-packages' ),
			__( 'MultiWander Packages', 'multiwander-packages' ),
			'manage_options',
			'mwp-settings',
			array( __CLASS__, 'render_settings' )
		);

		/*
		 * Its own top-level entry rather than a tab under Settings, because
		 * this is the one screen somebody who is not an administrator will use
		 * every week — whoever writes the posts. An editor can reach it;
		 * Settings they cannot.
		 */
		add_menu_page(
			__( 'Social kit', 'multiwander-packages' ),
			__( 'Social kit', 'multiwander-packages' ),
			'edit_posts',
			'mwp-social',
			array( __CLASS__, 'render_social' ),
			'dashicons-share',
			26
		);
	}

	/**
	 * Paste an ID, get a post.
	 *
	 * Everything on this screen is already in the database — no call goes out
	 * to Travel Compositor — so it answers instantly and works on a package
	 * whose feed is down.
	 *
	 * @return void
	 */
	public static function render_social() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		$id       = isset( $_GET['id'] ) ? mwp_extract_id( sanitize_text_field( wp_unslash( $_GET['id'] ) ) ) : '';
		$lang     = ( isset( $_GET['lang'] ) && 'en' === $_GET['lang'] ) ? 'en' : 'pl';
		// Currency the agent wants to advertise in. Defaults to what the
		// language implies the first time (Polish → złoty, English → euro),
		// but an explicit choice always wins once one has been made.
		$currency = ( isset( $_GET['currency'] ) && in_array( $_GET['currency'], array( 'eur', 'pln' ), true ) )
			? $_GET['currency']
			: ( 'en' === $lang ? 'eur' : 'pln' );
		$page = $id ? MWP_Sync::find_package_page( $id, $lang ) : 0;
		// If no page found in the chosen language, try the other.
		if ( $id && ! $page ) {
			$page = MWP_Sync::find_package_page( $id, 'en' === $lang ? 'pl' : 'en' );
		}
		$data = $page ? MWP_Sync::get_data( $page ) : null;

		// No local page — fetch live from Travel Compositor so any valid package
		// ID works, whether it was first created for Momira Travel, MultiWander
		// or any other brand on the same microsite.
		$live_fetch_error = null;
		if ( $id && ! $data && MWP_Client::is_configured() ) {
			$client   = new MWP_Client();
			$info     = $client->get_info( $id, 'PL' );
			if ( is_wp_error( $info ) ) {
				$live_fetch_error = $info;
			} else {
				$detail   = $client->get_detail( $id, 'PL' );
				$calendar = $client->get_calendar( $id, 'PL' );
				$data     = MWP_Parser::normalise(
					$info,
					is_wp_error( $detail ) ? array() : $detail,
					is_wp_error( $calendar ) ? array() : $calendar
				);
			}
		}
		?>
		<div class="wrap mwp-social-wrap">
			<h1><?php esc_html_e( 'Social kit', 'multiwander-packages' ); ?></h1>

			<p class="description" style="max-width:70ch">
				<?php esc_html_e( 'Enter any Holiday Package ID. The captions are written from the package\'s own facts — route, length, price and the real departure dates — and the photographs are cropped to the exact frame each network wants.', 'multiwander-packages' ); ?>
			</p>

			<form method="get" style="margin:18px 0 26px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
				<input type="hidden" name="page" value="mwp-social">
				<input type="text" name="id" class="regular-text" value="<?php echo esc_attr( $id ); ?>"
					placeholder="63989764" autofocus>
				<fieldset style="margin:0;padding:0;border:none;display:flex;align-items:center;gap:10px">
					<label style="font-weight:500;display:flex;align-items:center;gap:4px;cursor:pointer">
						<input type="radio" name="lang" value="pl" <?php checked( 'pl', $lang ); ?>>
						🇵🇱 <?php esc_html_e( 'Polish', 'multiwander-packages' ); ?>
					</label>
					<label style="font-weight:500;display:flex;align-items:center;gap:4px;cursor:pointer">
						<input type="radio" name="lang" value="en" <?php checked( 'en', $lang ); ?>>
						🇬🇧 <?php esc_html_e( 'English', 'multiwander-packages' ); ?>
					</label>
				</fieldset>
				<fieldset style="margin:0;padding:0;border:none;display:flex;align-items:center;gap:10px">
					<label style="font-weight:500;display:flex;align-items:center;gap:4px;cursor:pointer">
						<input type="radio" name="currency" value="pln" <?php checked( 'pln', $currency ); ?>>
						<?php esc_html_e( 'Złoty (zł)', 'multiwander-packages' ); ?>
					</label>
					<label style="font-weight:500;display:flex;align-items:center;gap:4px;cursor:pointer">
						<input type="radio" name="currency" value="eur" <?php checked( 'eur', $currency ); ?>>
						<?php esc_html_e( 'Euro (€)', 'multiwander-packages' ); ?>
					</label>
				</fieldset>
				<?php submit_button( __( 'Build the post', 'multiwander-packages' ), 'primary', '', false ); ?>
			</form>

			<?php if ( $live_fetch_error ) : ?>
				<div class="notice notice-error"><p>
					<?php echo esc_html(
						sprintf(
							/* translators: %s: error message */
							__( 'Could not fetch that package: %s', 'multiwander-packages' ),
							$live_fetch_error->get_error_message()
						)
					); ?>
				</p></div>
			<?php elseif ( $id && ! $data ) : ?>
				<div class="notice notice-warning"><p>
					<?php esc_html_e( 'Nothing was found for that ID — check that it is a published package.', 'multiwander-packages' ); ?>
				</p></div>
			<?php endif; ?>

			<?php
			// No title = TC returned an empty shell; treat as not found.
			if ( ! $data || empty( $data['title'] ) ) {
				echo '</div>';
				return;
			}

			// Use the local page URL when it exists; fall back to book.multiwander.com
			// so the post link always goes somewhere valid even for packages that
			// have not been imported to this site yet.
			$url = $page
				? get_permalink( $page )
				: MWP_BOOKING_BASE . '/' . $lang . '/idea/' . rawurlencode( $id ) . '/' . sanitize_title( $data['title'] );

			$variants = array(
				'inspiracja' => __( 'Version 1 — Inspiration (feed)', 'multiwander-packages' ),
				'konkret'    => __( 'Version 2 — The offer (converts)', 'multiwander-packages' ),
				'gbp'        => __( 'Google Business Profile', 'multiwander-packages' ),
			);
			?>

			<?php if ( $id && ! $page ) : ?>
				<div class="notice notice-info inline"><p>
					<?php esc_html_e( 'This package is not on multiwander.com yet. The post link points to book.multiwander.com. Add the ID to a country or theme page whenever you\'re ready to publish it.', 'multiwander-packages' ); ?>
				</p></div>
			<?php endif; ?>

			<h2 style="margin-top:6px"><?php echo esc_html( $data['title'] ); ?></h2>

			<?php
			// ── Travel Flyer: pick a style, open a print-ready A4 flyer ──────
			// Same page, same allowlist entry as the Social Kit screen the
			// agent is already looking at — not admin-post.php, which can be
			// a different, unapproved URL on sites that lock wp-admin down
			// to specific pages per role (see the comment in init()).
			$flyer_args = array( 'page' => 'mwp-social', 'mwp_flyer' => 1, 'id' => $id, 'lang' => $lang, 'currency' => $currency );
			if ( isset( $_GET['ribbon'] ) ) { $flyer_args['ribbon'] = sanitize_text_field( wp_unslash( $_GET['ribbon'] ) ); }
			if ( isset( $_GET['photo'] ) )  { $flyer_args['photo']  = absint( $_GET['photo'] ); }
			$flyer_url = function ( $style ) use ( $flyer_args ) {
				return add_query_arg( array_merge( $flyer_args, array( 'style' => $style ) ), admin_url( 'admin.php' ) );
			};
			?>
			<div class="mwp-flyer-panel" style="background:#fff;border:1px solid #e6e8ec;border-radius:12px;padding:20px 22px;margin:18px 0 26px;box-shadow:0 4px 14px rgba(0,0,0,.05)">
				<h2 style="margin:0 0 4px">📄 <?php esc_html_e( 'Travel Flyer — A4, print-ready', 'multiwander-packages' ); ?></h2>
				<p class="description" style="margin:0 0 16px;max-width:70ch">
					<?php esc_html_e( 'Pick a style and open a ready-to-print A4 flyer built from this package. Use the Download PDF button on the flyer to save it.', 'multiwander-packages' ); ?>
				</p>
				<div style="display:flex;gap:18px;flex-wrap:wrap">
					<div style="flex:1 1 300px;max-width:360px;border:1px solid #e6e8ec;border-radius:10px;overflow:hidden">
						<div style="height:120px;background:linear-gradient(135deg,#1f6f54,#2fa37a 55%,#6fd3a8);position:relative">
							<span style="position:absolute;left:10px;bottom:10px;color:#fff;font-weight:700;text-shadow:0 1px 6px rgba(0,0,0,.4)"><?php esc_html_e( 'Style 1 — Photo Hero', 'multiwander-packages' ); ?></span>
						</div>
						<div style="padding:14px">
							<p class="description" style="margin:0 0 12px"><?php esc_html_e( 'Big hero photo with the title over it and the price in the corner. Bold and visual.', 'multiwander-packages' ); ?></p>
							<a class="button button-primary" target="_blank" rel="noopener" href="<?php echo esc_url( $flyer_url( 1 ) ); ?>"><?php esc_html_e( 'Build flyer →', 'multiwander-packages' ); ?></a>
						</div>
					</div>
					<div style="flex:1 1 300px;max-width:360px;border:1px solid #e6e8ec;border-radius:10px;overflow:hidden">
						<div style="height:120px;background:#f4f6fa;border-bottom:3px solid #3a86ff;position:relative">
							<span style="position:absolute;left:10px;bottom:10px;color:#1a1a1a;font-weight:700"><?php esc_html_e( 'Style 2 — Editorial', 'multiwander-packages' ); ?></span>
						</div>
						<div style="padding:14px">
							<p class="description" style="margin:0 0 12px"><?php esc_html_e( 'Clean two-column layout: description and highlights on the left, facts and price on the right.', 'multiwander-packages' ); ?></p>
							<a class="button button-primary" target="_blank" rel="noopener" href="<?php echo esc_url( $flyer_url( 2 ) ); ?>"><?php esc_html_e( 'Build flyer →', 'multiwander-packages' ); ?></a>
						</div>
					</div>
				</div>
			</div>

			<div class="mwp-social-grid">
				<?php foreach ( $variants as $key => $label ) : ?>
					<?php $text = MWP_Social::caption( $data, $key, $url, $lang, $currency ); ?>
					<div class="mwp-social-box">
						<h3><?php echo esc_html( $label ); ?></h3>
						<textarea rows="16" readonly class="mwp-social-text"><?php echo esc_textarea( $text ); ?></textarea>
						<p>
							<button type="button" class="button mwp-copy"><?php esc_html_e( 'Copy', 'multiwander-packages' ); ?></button>
							<span class="description"><?php
								printf(
									/* translators: %d: character count */
									esc_html__( '%d characters', 'multiwander-packages' ),
									(int) mb_strlen( $text )
								);
							?></span>
						</p>
					</div>
				<?php endforeach; ?>
			</div>

			<h2><?php esc_html_e( 'The post', 'multiwander-packages' ); ?></h2>

			<?php
			$photos  = MWP_Social::photos( $page, $data, 6 );
			$formats = MWP_Social::formats();
			$styles  = MWP_Poster::styles();

			$chosen = isset( $_GET['photo'] ) ? absint( $_GET['photo'] ) : 0;
			$chosen = isset( $photos[ $chosen ] ) ? $chosen : 0;
			?>

			<?php if ( ! MWP_Poster::available() ) : ?>
				<div class="notice notice-error"><p>
					<?php esc_html_e( 'This server\'s PHP has no GD/FreeType support, so the finished images cannot be drawn here. Ask your host to enable the GD extension with FreeType — it is a standard part of PHP and needs no licence.', 'multiwander-packages' ); ?>
				</p></div>
			<?php else : ?>

				<p class="description" style="max-width:74ch">
					<?php esc_html_e( 'Finished JPGs at the exact size each network wants. Pick the photograph, then download the one you need — nothing else to do before posting.', 'multiwander-packages' ); ?>
				</p>

				<?php
				$focus = isset( $_GET['focus'] ) ? sanitize_key( wp_unslash( $_GET['focus'] ) ) : 'center';
				$focus = array_key_exists( $focus, MWP_Social::focal_points() ) ? $focus : 'center';

				$zoom  = isset( $_GET['zoom'] ) ? (float) $_GET['zoom'] : 1.0;
				$zoom  = max( 1.0, min( 2.0, $zoom ) );

				$ribbon_val = isset( $_GET['ribbon'] ) ? sanitize_text_field( wp_unslash( $_GET['ribbon'] ) ) : '';

				$link_to = function ( $args ) use ( $id, $lang, $currency, $chosen, $focus, $zoom, $ribbon_val ) {
					return add_query_arg(
						array_merge(
							array(
								'page'     => 'mwp-social',
								'id'       => $id,
								'lang'     => $lang,
								'currency' => $currency,
								'photo'    => $chosen,
								'focus'    => $focus,
								'zoom'     => $zoom,
								'ribbon'   => $ribbon_val,
							),
							$args
						),
						admin_url( 'admin.php' )
					);
				};
				?>

				<p class="mwp-social-picker">
					<?php foreach ( $photos as $i => $src ) : ?>
						<a href="<?php echo esc_url( $link_to( array( 'photo' => $i ) ) ); ?>"
							class="<?php echo $i === $chosen ? 'is-on' : ''; ?>">
							<img src="<?php echo esc_url( $src ); ?>" alt="">
						</a>
					<?php endforeach; ?>
				</p>

				<?php
				/*
				 * Framing.
				 *
				 * Travel Compositor's photographs are about 900 × 720 —
				 * measured, and there is no larger original behind them. A
				 * 1080 × 1920 story therefore cannot be filled without
				 * enlarging the picture two and a half times and throwing away
				 * two thirds of its width, which is how a cruise ship becomes
				 * three cabin windows. These two controls are the answer: keep
				 * the part that matters, and only zoom as far as the picture
				 * can stand.
				 */
				?>
				<p class="mwp-social-frame">
					<strong><?php esc_html_e( 'Keep:', 'multiwander-packages' ); ?></strong>
					<?php foreach ( MWP_Social::focal_points() as $key => $label ) : ?>
						<a class="button <?php echo $key === $focus ? 'button-primary' : ''; ?>"
							href="<?php echo esc_url( $link_to( array( 'focus' => $key ) ) ); ?>"><?php echo esc_html( $label ); ?></a>
					<?php endforeach; ?>

					<strong style="margin-left:18px"><?php esc_html_e( 'Zoom:', 'multiwander-packages' ); ?></strong>
					<?php foreach ( array( '1' => '100%', '1.25' => '125%', '1.5' => '150%', '2' => '200%' ) as $value => $label ) : ?>
						<a class="button <?php echo abs( (float) $value - $zoom ) < 0.01 ? 'button-primary' : ''; ?>"
							href="<?php echo esc_url( $link_to( array( 'zoom' => $value ) ) ); ?>"><?php echo esc_html( $label ); ?></a>
					<?php endforeach; ?>
				</p>

				<form method="get" class="mwp-social-ribbon-form" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:12px 0 4px">
					<input type="hidden" name="page" value="mwp-social">
					<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
					<input type="hidden" name="lang" value="<?php echo esc_attr( $lang ); ?>">
					<input type="hidden" name="currency" value="<?php echo esc_attr( $currency ); ?>">
					<input type="hidden" name="photo" value="<?php echo esc_attr( $chosen ); ?>">
					<input type="hidden" name="focus" value="<?php echo esc_attr( $focus ); ?>">
					<input type="hidden" name="zoom" value="<?php echo esc_attr( $zoom ); ?>">
					<label for="mwp_ribbon" style="font-weight:600;white-space:nowrap"><?php esc_html_e( 'Ribbon text:', 'multiwander-packages' ); ?></label>
					<input type="text" id="mwp_ribbon" name="ribbon"
						value="<?php echo esc_attr( $ribbon_val ); ?>"
						placeholder="LAST MINUTE"
						style="width:200px">
					<?php submit_button( __( 'Apply', 'multiwander-packages' ), 'secondary', '', false, array( 'style' => 'margin:0' ) ); ?>
					<span class="description"><?php esc_html_e( 'Optional — adds a diagonal corner ribbon to the poster. Leave empty for none.', 'multiwander-packages' ); ?></span>
				</form>

				<p class="description" style="max-width:74ch">
					<?php esc_html_e( 'These photographs supply at roughly 900 × 720 pixels, and there is no larger version behind them. Where a frame cannot be filled without stretching the picture too far — a vertical story, usually — the photograph is shown whole over a blurred copy of itself rather than enlarged past what it can carry. Zoom beyond 125% on a vertical frame will start to soften.', 'multiwander-packages' ); ?>
				</p>

				<?php foreach ( $styles as $style => $style_label ) : ?>
					<h3><?php echo esc_html( $style_label ); ?></h3>
					<div class="mwp-social-posts">
						<?php foreach ( $formats as $key => $spec ) : ?>
							<?php $made = MWP_Poster::build( $data, $key, $style, $photos[ $chosen ], $focus, $zoom, $ribbon_val, $currency ); ?>
							<figure class="mwp-social-post">
								<?php if ( $made ) : ?>
									<img src="<?php echo esc_url( $made ); ?>" alt="">
									<figcaption>
										<strong><?php echo esc_html( $spec['label'] ); ?></strong><br>
										<span class="description"><?php echo esc_html( $spec['note'] ); ?></span><br>
										<a class="button button-primary" style="margin-top:8px"
											href="<?php echo esc_url( $made ); ?>"
											download="<?php echo esc_attr( self::social_filename( $data['title'], $spec['label'] ) . '.jpg' ); ?>">
											<?php esc_html_e( 'Download JPG', 'multiwander-packages' ); ?>
										</a>
									</figcaption>
								<?php else : ?>
									<figcaption><span class="description"><?php esc_html_e( 'could not be drawn', 'multiwander-packages' ); ?></span></figcaption>
								<?php endif; ?>
							</figure>
						<?php endforeach; ?>
					</div>
				<?php endforeach; ?>

			<?php endif; ?>

			<h2><?php esc_html_e( 'For the Reel or TikTok', 'multiwander-packages' ); ?></h2>
			<p class="description" style="max-width:74ch">
				<?php esc_html_e( 'Canva Pro has no Autofill API, so the video is still assembled by hand — but the 1080×1920 images above are already the frames. In Canva: new 1080×1920 design, drop them in route order, two seconds each, and put the link in the caption rather than on screen. Upgrading to Canva Teams would let this screen fill and export your Brand Template automatically.', 'multiwander-packages' ); ?>
			</p>

			<style>
				.mwp-social-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px; margin: 16px 0 34px; }
				.mwp-social-box { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 16px 18px; }
				.mwp-social-box h3 { margin-top: 0; }
				.mwp-social-text { width: 100%; font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 12px; line-height: 1.55; }
				.mwp-social-picker { display: flex; gap: 10px; flex-wrap: wrap; margin: 14px 0 22px; }
				.mwp-social-picker a { display: block; border: 3px solid transparent; border-radius: 8px; overflow: hidden; line-height: 0; }
				.mwp-social-picker a.is-on { border-color: #17a398; }
				.mwp-social-picker img { width: 96px; height: 72px; object-fit: cover; }
				.mwp-social-posts { display: flex; gap: 22px; flex-wrap: wrap; align-items: flex-start; margin: 10px 0 30px; }
				.mwp-social-post { margin: 0; background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 12px; text-align: center; }
				.mwp-social-post img { max-width: 240px; max-height: 320px; border-radius: 4px; display: block; margin: 0 auto 10px; }
				.mwp-social-post figcaption { font-size: 13px; line-height: 1.5; }
			</style>

			<script>
				document.querySelectorAll( '.mwp-copy' ).forEach( function ( b ) {
					b.addEventListener( 'click', function () {
						var box = b.closest( '.mwp-social-box' ).querySelector( 'textarea' );
						box.select();
						document.execCommand( 'copy' );
						b.textContent = '<?php echo esc_js( __( 'Copied', 'multiwander-packages' ) ); ?>';
						window.setTimeout( function () { b.textContent = '<?php echo esc_js( __( 'Copy', 'multiwander-packages' ) ); ?>'; }, 1600 );
					} );
				} );
			</script>
		</div>
		<?php
	}

	public static function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['mwp_flush'] ) && check_admin_referer( 'mwp_flush' ) ) {
			$n = MWP_Client::flush_cache();
			delete_transient( MWP_Client::TOKEN_TRANSIENT );
			echo '<div class="notice notice-success"><p>' .
				sprintf( esc_html__( 'Cleared %d cached responses.', 'multiwander-packages' ), (int) $n ) .
				'</p></div>';
		}

		if ( isset( $_POST['mwp_save_sync'] ) && check_admin_referer( 'mwp_sync_settings' ) ) {
			update_option( MWP_Cron::OPT_ENABLED, isset( $_POST['mwp_cron_enabled'] ) ? 1 : 0, false );
			update_option( 'mwp_cf7_pl', sanitize_text_field( wp_unslash( $_POST['mwp_cf7_pl'] ?? '' ) ), false );
			update_option( 'mwp_cf7_en', sanitize_text_field( wp_unslash( $_POST['mwp_cf7_en'] ?? '' ) ), false );

			$theme_map     = array();
			$theme_unknown = array();

			foreach ( (array) ( $_POST['mwp_theme_pages'] ?? array() ) as $key => $address ) {
				$key     = sanitize_key( $key );
				$address = sanitize_text_field( wp_unslash( $address ) );

				if ( '' === trim( $address ) ) {
					continue;
				}

				$page_id = MWP_Themes::resolve_page( $address );

				if ( $page_id ) {
					$theme_map[ $key ] = $page_id;
				} else {
					// Say which address did not land rather than dropping it
					// silently and leaving the theme quietly doing nothing.
					$theme_unknown[] = $address;
				}
			}

			update_option( MWP_Themes::OPTION, $theme_map, false );

			if ( $theme_unknown ) {
				echo '<div class="notice notice-warning"><p>' .
					esc_html__( 'These theme addresses do not match a page on this site, so they were not saved:', 'multiwander-packages' ) .
					' ' . esc_html( implode( ', ', $theme_unknown ) ) .
					'</p></div>';
			}

			// Take the new schedule setting into account immediately.
			MWP_Cron::clear();
			MWP_Cron::ensure_schedule();

			echo '<div class="notice notice-success"><p>' .
				esc_html__( 'Saved.', 'multiwander-packages' ) . '</p></div>';
		}

		if ( isset( $_POST['mwp_optimise_images'] ) && check_admin_referer( 'mwp_sync_settings' ) ) {
			$done = MWP_Images::optimise_batch( 25 );

			echo '<div class="notice notice-success"><p>' .
				sprintf(
					/* translators: 1: images processed, 2: images changed, 3: megabytes saved, 4: images remaining */
					esc_html__( 'Processed %1$d images, rewrote %2$d, saved %3$s MB. %4$d still to do.', 'multiwander-packages' ),
					(int) $done['done'],
					(int) $done['changed'],
					esc_html( number_format_i18n( $done['saved'] / 1048576, 1 ) ),
					(int) $done['left']
				) .
				'</p></div>';
		}

		if ( isset( $_POST['mwp_route_all'] ) && check_admin_referer( 'mwp_sync_settings' ) ) {
			$routed = MWP_Themes::route_all();

			echo '<div class="notice notice-success"><p>' .
				sprintf(
					/* translators: 1: packages checked, 2: theme-page entries added */
					esc_html__( 'Checked %1$d package pages and made %2$d new theme-page entries.', 'multiwander-packages' ),
					(int) $routed['checked'],
					(int) $routed['added']
				) .
				'</p></div>';
		}

		if ( isset( $_GET['mwp_synced'] ) ) {
			$report = get_option( MWP_Cron::OPT_REPORT, array() );
			echo '<div class="notice notice-success"><p>' .
				sprintf(
					/* translators: 1: country pages, 2: packages */
					esc_html__( 'Synced %1$d country pages and %2$d packages.', 'multiwander-packages' ),
					isset( $report['pages'] ) ? (int) $report['pages'] : 0,
					isset( $report['packages'] ) ? (int) $report['packages'] : 0
				) .
				'</p></div>';
		}

		if ( isset( $_POST['mwp_save_template'] ) && check_admin_referer( 'mwp_template' ) ) {
			update_option( 'mwp_page_template', sanitize_text_field( wp_unslash( $_POST['mwp_page_template'] ?? '' ) ) );
			echo '<div class="notice notice-success"><p>' .
				esc_html__( 'Saved. Re-sync a country page to apply the template to its package pages.', 'multiwander-packages' ) .
				'</p></div>';
		}

		if ( isset( $_POST['mwp_save_credentials'] ) && check_admin_referer( 'mwp_credentials' ) ) {
			MWP_Client::save_settings( array(
				'user'      => isset( $_POST['mwp_user'] ) ? wp_unslash( $_POST['mwp_user'] ) : '',
				'pass'      => isset( $_POST['mwp_pass'] ) ? wp_unslash( $_POST['mwp_pass'] ) : '',
				'microsite' => isset( $_POST['mwp_microsite'] ) ? wp_unslash( $_POST['mwp_microsite'] ) : '',
				'base'      => isset( $_POST['mwp_base'] ) ? wp_unslash( $_POST['mwp_base'] ) : '',
			) );
			echo '<div class="notice notice-success"><p>' .
				esc_html__( 'Credentials saved.', 'multiwander-packages' ) . '</p></div>';
		}

		$c            = MWP_Client::config();
		$from_config  = ( 'wp-config.php' === $c['source'] );
		$has_password = MWP_Client::has_stored_password();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'MultiWander Packages', 'multiwander-packages' ); ?></h1>

			<h2><?php esc_html_e( 'Connection', 'multiwander-packages' ); ?></h2>
			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Status', 'multiwander-packages' ); ?></th>
					<td><?php self::render_connection_status(); ?></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Credentials from', 'multiwander-packages' ); ?></th>
					<td>
						<?php if ( $from_config ) : ?>
							<code>wp-config.php</code>
							<span class="mwp-help"><?php esc_html_e( 'The safest option — the fields below are ignored while these constants are set.', 'multiwander-packages' ); ?></span>
						<?php else : ?>
							<?php esc_html_e( 'the fields below', 'multiwander-packages' ); ?>
							<span class="mwp-help"><?php esc_html_e( 'Stored in the database, encrypted with this site\'s salts. Moving them into wp-config.php later is more secure and takes priority automatically.', 'multiwander-packages' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			</table>

			<form method="post">
				<?php wp_nonce_field( 'mwp_credentials' ); ?>
				<table class="form-table">
					<tr>
						<th><label for="mwp_user"><?php esc_html_e( 'Username', 'multiwander-packages' ); ?></label></th>
						<td>
							<input type="text" id="mwp_user" name="mwp_user" class="regular-text"
								value="<?php echo esc_attr( $from_config ? '' : get_option( MWP_Client::OPT_USER, '' ) ); ?>"
								autocomplete="off" <?php disabled( $from_config ); ?>>
							<span class="mwp-help"><?php esc_html_e( 'This username contains spaces. That is correct.', 'multiwander-packages' ); ?></span>
						</td>
					</tr>
					<tr>
						<th><label for="mwp_pass"><?php esc_html_e( 'Password', 'multiwander-packages' ); ?></label></th>
						<td>
							<input type="password" id="mwp_pass" name="mwp_pass" class="regular-text"
								value="" autocomplete="new-password"
								placeholder="<?php echo esc_attr( $has_password ? __( 'stored — leave empty to keep it', 'multiwander-packages' ) : '' ); ?>"
								<?php disabled( $from_config ); ?>>
							<span class="mwp-help"><?php esc_html_e( 'Never shown again once saved. Leave empty when changing the other fields.', 'multiwander-packages' ); ?></span>
						</td>
					</tr>
					<tr>
						<th><label for="mwp_microsite"><?php esc_html_e( 'Microsite', 'multiwander-packages' ); ?></label></th>
						<td><input type="text" id="mwp_microsite" name="mwp_microsite" class="regular-text"
							value="<?php echo esc_attr( $c['microsite'] ); ?>" <?php disabled( $from_config ); ?>></td>
					</tr>
					<tr>
						<th><label for="mwp_base"><?php esc_html_e( 'Base URL', 'multiwander-packages' ); ?></label></th>
						<td><input type="url" id="mwp_base" name="mwp_base" class="large-text"
							value="<?php echo esc_attr( $c['base'] ); ?>" <?php disabled( $from_config ); ?>></td>
					</tr>
				</table>
				<?php if ( ! $from_config ) : ?>
					<p><button class="button button-primary" name="mwp_save_credentials" value="1"><?php esc_html_e( 'Save credentials', 'multiwander-packages' ); ?></button></p>
				<?php endif; ?>
			</form>

			<hr>

			<h2><?php esc_html_e( 'Keeping packages up to date', 'multiwander-packages' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Prices and content change in Travel Compositor without anyone touching the WordPress page. A scheduled refresh keeps the site from advertising figures that no longer exist.', 'multiwander-packages' ); ?>
			</p>

			<form method="post">
				<?php wp_nonce_field( 'mwp_sync_settings' ); ?>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Automatic refresh', 'multiwander-packages' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="mwp_cron_enabled" value="1" <?php checked( MWP_Cron::enabled() ); ?>>
								<?php esc_html_e( 'Refresh packages from Travel Compositor daily', 'multiwander-packages' ); ?>
							</label>
							<span class="mwp-help">
								<?php
								$last = get_option( MWP_Cron::OPT_LAST, '' );
								$next = wp_next_scheduled( MWP_Cron::HOOK );

								if ( $last ) {
									printf(
										/* translators: %s: date */
										esc_html__( 'Last run: %s.', 'multiwander-packages' ),
										esc_html( $last )
									);
									echo ' ';
								}
								if ( $next ) {
									printf(
										/* translators: %s: date */
										esc_html__( 'Next run: %s.', 'multiwander-packages' ),
										esc_html( date_i18n( 'Y-m-d H:i', $next ) )
									);
								}
								?>
								<br>
								<?php esc_html_e( 'A few country pages are refreshed on each run rather than all at once, so a large site never exceeds the PHP time limit. Over a few days every page comes round.', 'multiwander-packages' ); ?>
							</span>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Theme pages', 'multiwander-packages' ); ?></th>
						<td>
							<?php
							$theme_pages = MWP_Themes::pages();
							?>
							<?php foreach ( MWP_Themes::catalogue() as $key => $theme ) : ?>
								<?php
								$mapped = isset( $theme_pages[ $key ] ) ? (int) $theme_pages[ $key ] : 0;
								$value  = $mapped ? (string) get_permalink( $mapped ) : '';
								?>
								<p class="mwp-theme-row">
									<label for="mwp_theme_<?php echo esc_attr( $key ); ?>" class="mwp-theme-label">
										<?php echo esc_html( $theme['label'] ); ?>
									</label>
									<input type="url" class="regular-text"
										id="mwp_theme_<?php echo esc_attr( $key ); ?>"
										name="mwp_theme_pages[<?php echo esc_attr( $key ); ?>]"
										value="<?php echo esc_attr( $value ); ?>"
										placeholder="https://multiwander.com/...">
									<span class="mwp-theme-found">
										<?php if ( $mapped ) : ?>
											<?php $on_page = count( MWP_Sync::get_package_ids( $mapped ) ); ?>
											<span class="mwp-ok">&#10003;</span>
											<a href="<?php echo esc_url( (string) get_edit_post_link( $mapped ) ); ?>">
												<?php echo esc_html( get_the_title( $mapped ) ); ?>
											</a>
											<?php
											// How many packages have actually landed there. A theme
											// that is mapped but empty looks identical to one that
											// is broken unless this number is on the screen.
											printf(
												' — <strong>%s</strong>',
												esc_html( sprintf(
													/* translators: %d: number of packages */
													_n( '%d package', '%d packages', $on_page, 'multiwander-packages' ),
													$on_page
												) )
											);
											?>
										<?php endif; ?>
									</span>
								</p>
							<?php endforeach; ?>
														<p class="mwp-theme-route">
								<button type="submit" name="mwp_route_all" value="1" class="button">
									<?php esc_html_e( 'Re-check every package now', 'multiwander-packages' ); ?>
								</button>
								<span class="mwp-help">
									<?php esc_html_e( 'Routing normally happens when a package is synced, so a change here reaches the rest of the site over the following days. This applies it to every package already on the site at once, using the themes it has already stored — no calls to Travel Compositor, and nothing is ever removed.', 'multiwander-packages' ); ?>
								</span>
							</p>

							<span class="mwp-help">
								<?php esc_html_e( 'Paste the address of each theme\'s landing page. The English address works too — it resolves to its Polish original, which is where the ID list lives. When a package carries that theme in Travel Compositor, its ID is added to the page automatically on the next sync. Adding only: a theme disappearing in Travel Compositor never removes an ID somebody may have put there on purpose.', 'multiwander-packages' ); ?>
							</span>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Imported images', 'multiwander-packages' ); ?></th>
						<td>
							<?php $left = MWP_Images::remaining(); ?>
							<button type="submit" name="mwp_optimise_images" value="1" class="button"
								<?php disabled( 0, $left ); ?>>
								<?php esc_html_e( 'Optimise the next 25', 'multiwander-packages' ); ?>
							</button>
							<span class="mwp-help">
								<?php
								if ( $left ) {
									printf(
										/* translators: %d: images waiting */
										esc_html__( '%d imported images have not been optimised yet. Each is resized to a sensible maximum and a PNG photograph is re-encoded as WebP — measured on this site, one hero image alone was 1.3 MB. Press once per batch; new images are optimised automatically as they are imported.', 'multiwander-packages' ),
										(int) $left
									);
								} else {
									esc_html_e( 'Every imported image has been optimised. New ones are handled automatically as they arrive.', 'multiwander-packages' );
								}
								?>
							</span>
						</td>
					</tr>
					<tr>
						<th><label for="mwp_cf7_pl"><?php esc_html_e( 'Enquiry form (Polish)', 'multiwander-packages' ); ?></label></th>
						<td>
							<input type="text" id="mwp_cf7_pl" name="mwp_cf7_pl" class="regular-text"
								value="<?php echo esc_attr( get_option( 'mwp_cf7_pl', '24390f0' ) ); ?>">
							<span class="mwp-help"><?php esc_html_e( 'Contact Form 7 ID shown on Polish package pages.', 'multiwander-packages' ); ?></span>
						</td>
					</tr>
					<tr>
						<th><label for="mwp_cf7_en"><?php esc_html_e( 'Enquiry form (English)', 'multiwander-packages' ); ?></label></th>
						<td>
							<input type="text" id="mwp_cf7_en" name="mwp_cf7_en" class="regular-text"
								value="<?php echo esc_attr( get_option( 'mwp_cf7_en', '4033794' ) ); ?>">
							<span class="mwp-help"><?php esc_html_e( 'Contact Form 7 ID shown on English package pages.', 'multiwander-packages' ); ?></span>
						</td>
					</tr>
				</table>
				<p>
					<button class="button button-primary" name="mwp_save_sync" value="1"><?php esc_html_e( 'Save', 'multiwander-packages' ); ?></button>
				</p>
			</form>

			<p>
				<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mwp_sync_all' ), 'mwp_sync_all' ) ); ?>">
					<?php esc_html_e( 'Refresh packages now', 'multiwander-packages' ); ?>
				</a>
				<span class="mwp-help"><?php esc_html_e( 'Runs one batch immediately, starting from the first country page.', 'multiwander-packages' ); ?></span>
			</p>

			<hr>

			<h2><?php esc_html_e( 'Package pages', 'multiwander-packages' ); ?></h2>
			<form method="post">
				<?php wp_nonce_field( 'mwp_template' ); ?>
				<table class="form-table">
					<tr>
						<th><label for="mwp_page_template"><?php esc_html_e( 'Page template', 'multiwander-packages' ); ?></label></th>
						<td>
							<?php $current = (string) get_option( 'mwp_page_template', '' ); ?>
							<select id="mwp_page_template" name="mwp_page_template">
								<option value=""><?php esc_html_e( '— same as the country page (recommended) —', 'multiwander-packages' ); ?></option>
								<option value="default" <?php selected( $current, 'default' ); ?>><?php esc_html_e( 'Default template', 'multiwander-packages' ); ?></option>
								<?php foreach ( wp_get_theme()->get_page_templates( null, 'page' ) as $file => $name ) : ?>
									<option value="<?php echo esc_attr( $file ); ?>" <?php selected( $current, $file ); ?>>
										<?php echo esc_html( $name ); ?>
									</option>
								<?php endforeach; ?>
							</select>
							<span class="mwp-help">
								<?php esc_html_e( 'Package pages print their own title and images. A template that ALSO prints the theme\'s featured-image banner shows the same photo twice and produces two H1 headings, which weakens the page in search. Left on the default setting, each package page simply copies its country page\'s template, which is usually what you want.', 'multiwander-packages' ); ?>
							</span>
						</td>
					</tr>
				</table>
				<p><button class="button button-primary" name="mwp_save_template" value="1"><?php esc_html_e( 'Save', 'multiwander-packages' ); ?></button></p>
			</form>

			<form method="post">
				<?php wp_nonce_field( 'mwp_flush' ); ?>
				<p><button class="button" name="mwp_flush" value="1"><?php esc_html_e( 'Clear cached API responses', 'multiwander-packages' ); ?></button></p>
			</form>

			<hr>

			<h2><?php esc_html_e( 'Inspect a package', 'multiwander-packages' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Shows the raw Travel Compositor response next to what the plugin made of it. Use this when a field on a page looks wrong.', 'multiwander-packages' ); ?>
			</p>
			<form method="get">
				<input type="hidden" name="page" value="mwp-settings">
				<input type="text" name="mwp_debug" class="regular-text" placeholder="59875907"
					value="<?php echo isset( $_GET['mwp_debug'] ) ? esc_attr( sanitize_text_field( wp_unslash( $_GET['mwp_debug'] ) ) ) : ''; ?>">
				<button class="button"><?php esc_html_e( 'Fetch', 'multiwander-packages' ); ?></button>
			</form>

			<?php self::render_debug(); ?>
		</div>
		<?php
	}

	protected static function render_connection_status() {
		if ( ! MWP_Client::is_configured() ) {
			echo '<span class="mwp-bad">&#10007;</span> ' . esc_html__( 'Not configured', 'multiwander-packages' );
			return;
		}

		$client = new MWP_Client();
		$token  = $client->authenticate();

		if ( is_wp_error( $token ) ) {
			echo '<span class="mwp-bad">&#10007;</span> ' . esc_html( $token->get_error_message() );
			return;
		}

		echo '<span class="mwp-ok">&#10003;</span> ' . esc_html__( 'Connected', 'multiwander-packages' );
	}

	protected static function render_debug() {
		if ( empty( $_GET['mwp_debug'] ) ) {
			return;
		}

		$id = mwp_extract_id( sanitize_text_field( wp_unslash( $_GET['mwp_debug'] ) ) );
		if ( '' === $id ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'That is not a package ID.', 'multiwander-packages' ) . '</p></div>';
			return;
		}

		$client   = new MWP_Client();
		$info     = $client->get_info( $id, 'PL' );
		$detail   = $client->get_detail( $id, 'PL' );
		$calendar = $client->get_calendar( $id, 'PL' );

		foreach ( array( 'info' => $info, 'detail' => $detail, 'calendar' => $calendar ) as $label => $response ) {
			if ( is_wp_error( $response ) ) {
				echo '<div class="notice notice-error"><p><strong>' . esc_html( $label ) . '</strong>: ' .
					esc_html( $response->get_error_message() ) . '</p></div>';
			}
		}

		if ( is_wp_error( $info ) ) {
			return;
		}

		$parsed = MWP_Parser::normalise(
			$info,
			is_wp_error( $detail ) ? array() : $detail,
			is_wp_error( $calendar ) ? array() : $calendar
		);

		echo '<h3>' . esc_html__( 'What the plugin read', 'multiwander-packages' ) . '</h3>';
		echo '<table class="widefat striped"><tbody>';
		$summary = array(
			__( 'Title (PL)', 'multiwander-packages' )   => $parsed['title'],
			__( 'Slug', 'multiwander-packages' )         => mwp_slug( $parsed['title'] ),
			__( 'Price', 'multiwander-packages' )        => $parsed['price']['amount'] . ' ' . $parsed['price']['currency'],
			__( 'Duration', 'multiwander-packages' )     => $parsed['duration']['days'] . ' / ' . $parsed['duration']['nights'],
			__( 'Destinations', 'multiwander-packages' ) => implode( ' → ', wp_list_pluck( $parsed['destinations'], 'name' ) ),
			__( 'Flights', 'multiwander-packages' )      => count( $parsed['flights'] ),
			__( 'Hotels', 'multiwander-packages' )       => count( $parsed['hotels'] ),
			__( 'Activities', 'multiwander-packages' )   => count( $parsed['activities'] ),
			__( 'Gallery', 'multiwander-packages' )      => count( $parsed['gallery'] ),
			__( 'Departures', 'multiwander-packages' )   => $parsed['departures']['is_empty']
				? __( 'none listed (departs any day)', 'multiwander-packages' )
				: count( $parsed['departures']['dates'] ) . ' — ' . $parsed['departures']['first'],
		);
		foreach ( $summary as $label => $value ) {
			echo '<tr><th style="width:180px">' . esc_html( $label ) . '</th><td>' . esc_html( (string) $value ) . '</td></tr>';
		}
		echo '</tbody></table>';

		echo '<h3>' . esc_html__( 'Raw response', 'multiwander-packages' ) . '</h3>';
		echo '<textarea class="widefat code" rows="20" readonly>' .
			esc_textarea( wp_json_encode(
				array(
					'info'     => $info,
					'detail'   => is_wp_error( $detail ) ? null : $detail,
					'calendar' => is_wp_error( $calendar ) ? null : $calendar,
				),
	
			JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
			) ) .
			'</textarea>';
	}

	// ===============================================================
	// Travel Flyer — A4 print-ready flyer from a Holiday Package
	// ===============================================================

	/**
	 * Fetch normalised package data by ID: local page first, then live TC.
	 *
	 * @param string $id   Holiday Package ID.
	 * @param string $lang 'pl' | 'en'.
	 * @return array{0:?array,1:int,2:?WP_Error} [ $data, $page_id, $error ]
	 */
	public static function load_package( $id, $lang ) {
		$page = $id ? MWP_Sync::find_package_page( $id, $lang ) : 0;
		if ( $id && ! $page ) {
			$page = MWP_Sync::find_package_page( $id, 'en' === $lang ? 'pl' : 'en' );
		}
		$data  = $page ? MWP_Sync::get_data( $page ) : null;
		$error = null;
		if ( $id && ! $data && MWP_Client::is_configured() ) {
			$client = new MWP_Client();
			$info   = $client->get_info( $id, strtoupper( $lang ) );
			if ( is_wp_error( $info ) ) {
				$error = $info;
			} else {
				$detail   = $client->get_detail( $id, strtoupper( $lang ) );
				$calendar = $client->get_calendar( $id, strtoupper( $lang ) );
				$data     = MWP_Parser::normalise(
					$info,
					is_wp_error( $detail ) ? array() : $detail,
					is_wp_error( $calendar ) ? array() : $calendar
				);
			}
		}
		return array( $data, (int) $page, $error );
	}

	/**
	 * Fires on every load of the Social Kit page itself, before any HTML is
	 * sent — the earliest point where we can still take over the response.
	 * When the "Build flyer" link was clicked, that link now points back at
	 * this same page (admin.php?page=mwp-social&mwp_flyer=1&…) rather than
	 * admin-post.php, specifically so the flyer is served from a URL the
	 * agent already has access to. See the comment in init().
	 *
	 * @return void
	 */
	/**
	 * SEO-strong download filename: "Multiwander - <tour title>[ - <variant>]".
	 *
	 * Used for the Social Kit JPG downloads (and matches the flyer PDF title)
	 * so every file an agent saves already carries the brand and the real
	 * name of the advertised tour, instead of a random poster hash.
	 *
	 * @param string $title  The Holiday Package title.
	 * @param string $suffix Optional variant label (e.g. the format name) to
	 *                        keep several downloads from the same tour distinct.
	 * @return string A clean base name (no extension), safe for a filename.
	 */
	protected static function social_filename( $title, $suffix = '' ) {
		$clean = function ( $s ) {
			$s = wp_strip_all_tags( (string) $s );
			$s = str_replace( array( '/', '\\', ':', '*', '?', '"', '<', '>', '|' ), ' ', $s );
			return trim( preg_replace( '/\s+/', ' ', $s ) );
		};
		$base = 'Multiwander - ' . $clean( $title );
		$suf  = $clean( $suffix );
		if ( '' !== $suf ) {
			$base .= ' - ' . $suf;
		}
		return $base;
	}

	public static function maybe_render_flyer() {
		if ( empty( $_GET['mwp_flyer'] ) ) {
			return;
		}
		self::render_flyer();
	}

	/**
	 * Builds and outputs the standalone A4 flyer, then exits. Reached either
	 * from the Social Kit page itself (maybe_render_flyer(), the normal
	 * path) or directly via admin-post.php?action=mwp_flyer (kept for any
	 * link already out in the wild).
	 *
	 * @return void
	 */
	public static function render_flyer() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'multiwander-packages' ) );
		}

		$id       = isset( $_GET['id'] ) ? mwp_extract_id( sanitize_text_field( wp_unslash( $_GET['id'] ) ) ) : '';
		$lang     = ( isset( $_GET['lang'] ) && 'en' === $_GET['lang'] ) ? 'en' : 'pl';
		$style    = ( isset( $_GET['style'] ) && '2' === (string) $_GET['style'] ) ? 2 : 1;
		$ribbon   = isset( $_GET['ribbon'] ) ? sanitize_text_field( wp_unslash( $_GET['ribbon'] ) ) : '';
		$photo_i  = isset( $_GET['photo'] ) ? absint( $_GET['photo'] ) : 0;
		$currency = ( isset( $_GET['currency'] ) && in_array( $_GET['currency'], array( 'eur', 'pln' ), true ) )
			? $_GET['currency']
			: ( 'en' === $lang ? 'eur' : 'pln' );

		list( $data, $page, $error ) = self::load_package( $id, $lang );
		if ( ! $data || empty( $data['title'] ) ) {
			wp_die( esc_html__( 'Could not load that package — check the ID.', 'multiwander-packages' ) );
		}

		$title = ( ! empty( $data['large_title'] ) ) ? $data['large_title'] : $data['title'];

		$stops = array();
		foreach ( (array) ( isset( $data['destinations'] ) ? $data['destinations'] : array() ) as $d ) {
			if ( ! empty( $d['name'] ) ) { $stops[] = $d['name']; }
		}
		$location = $stops ? $stops[0] : '';
		$route    = implode( ' - ', array_slice( $stops, 0, 5 ) );

		$nights = isset( $data['duration']['nights'] ) ? (int) $data['duration']['nights'] : 0;
		$days   = isset( $data['duration']['days'] ) ? (int) $data['duration']['days'] : 0;
		if ( 'en' === $lang ) {
			$dur = $days ? sprintf( '%d days / %d nights', $days, $nights ) : '';
		} else {
			$dur = $days ? sprintf( '%d dni / %d nocy', $days, $nights ) : '';
		}

		$pf    = mwp_format_price( (array) ( isset( $data['price'] ) ? $data['price'] : array() ), $lang, $currency );
		$price = ! empty( $pf['value'] ) ? trim( $pf['value'] . ' ' . $pf['symbol'] ) : '';

		$desc = wp_strip_all_tags( (string) ( isset( $data['description'] ) ? $data['description'] : '' ) );
		$desc = wp_trim_words( $desc, 70, '…' );

		if ( '' === $ribbon ) { $ribbon = (string) ( isset( $data['ribbon'] ) ? $data['ribbon'] : '' ); }

		$gallery = array();
		if ( ! empty( $data['hero_image'] ) ) { $gallery[] = (string) $data['hero_image']; }
		foreach ( (array) ( isset( $data['gallery'] ) ? $data['gallery'] : array() ) as $g ) {
			if ( is_string( $g ) && '' !== $g ) { $gallery[] = $g; }
		}
		$gallery = array_values( array_unique( array_filter( $gallery ) ) );
		$hero    = isset( $gallery[ $photo_i ] ) ? $gallery[ $photo_i ] : ( isset( $gallery[0] ) ? $gallery[0] : '' );
		$strip   = array();
		foreach ( $gallery as $g ) {
			if ( $g !== $hero && count( $strip ) < 3 ) { $strip[] = $g; }
		}

		// Counters → the icon stats + "what's included".
		$c          = ( isset( $data['counters'] ) && is_array( $data['counters'] ) ) ? $data['counters'] : array();
		$transfers  = isset( $c['transfers'] ) ? (int) $c['transfers'] : 0;
		$hotels_n   = isset( $c['hotels'] ) ? (int) $c['hotels'] : 0;
		$hotel_nts  = isset( $c['hotelNights'] ) ? (int) $c['hotelNights'] : $nights;
		$acts_n     = isset( $c['tickets'] ) ? (int) $c['tickets'] : 0;
		$transports_n = count( (array) ( isset( $data['transports'] ) ? $data['transports'] : array() ) )
			+ count( (array) ( isset( $data['flights'] ) ? $data['flights'] : array() ) );

		// Every hotel on the itinerary, with its board basis — not just the
		// first one — so the flyer actually shows where the traveller sleeps
		// each leg of the trip.
		$meal_labels = array(
			'pl' => array(
				'RO' => 'bez wyżywienia', 'BB' => 'śniadanie', 'HB' => 'śniadanie i kolacja',
				'FB' => 'pełne wyżywienie', 'AI' => 'all inclusive', 'UAI' => 'ultra all inclusive',
			),
			'en' => array(
				'RO' => 'room only', 'BB' => 'breakfast', 'HB' => 'half board',
				'FB' => 'full board', 'AI' => 'all inclusive', 'UAI' => 'ultra all inclusive',
			),
		);
		$meal_map = $meal_labels[ $lang ];
		$hotels_list = array();
		foreach ( (array) ( isset( $data['hotels'] ) ? $data['hotels'] : array() ) as $h ) {
			if ( empty( $h['name'] ) ) {
				continue;
			}
			$code = strtoupper( trim( (string) ( isset( $h['meal_plan'] ) ? $h['meal_plan'] : '' ) ) );
			$meal = isset( $meal_map[ $code ] ) ? $meal_map[ $code ] : ( '' !== $code ? $code : '' );
			$hotels_list[] = array(
				'name'   => (string) $h['name'],
				'nights' => isset( $h['nights'] ) ? (int) $h['nights'] : 0,
				'meal'   => $meal,
			);
		}

		// First hotel name + nights, kept for anything still reading the old
		// single-hotel fields.
		$hotel_name       = $hotels_list ? $hotels_list[0]['name'] : '';
		$hotel_one_nights = $hotels_list ? $hotels_list[0]['nights'] : $hotel_nts;

		// Round trips (multi-day closed tours) listed on their own — a bus
		// tour or cruise itinerary is not the same thing as a single-day
		// excursion and travellers look for it separately.
		$tours_list = array();
		foreach ( (array) ( isset( $data['tours'] ) ? $data['tours'] : array() ) as $tr ) {
			if ( empty( $tr['name'] ) ) {
				continue;
			}
			$from = isset( $tr['day_from'] ) ? (int) $tr['day_from'] : 0;
			$to   = isset( $tr['day_to'] ) ? (int) $tr['day_to'] : 0;
			$span = ( $to > $from ) ? ( $to - $from + 1 ) : 0;
			$tours_list[] = array(
				'name'  => (string) $tr['name'],
				'days'  => $span,
			);
		}

		// Single-day excursions.
		$experiences = array();
		foreach ( (array) ( isset( $data['activities'] ) ? $data['activities'] : array() ) as $a ) {
			if ( ! empty( $a['name'] ) ) { $experiences[] = (string) $a['name']; }
		}
		$experiences = array_values( array_unique( $experiences ) );

		// Eyebrow (region/theme) above the title.
		$eyebrow = '';
		foreach ( (array) ( isset( $data['themes'] ) ? $data['themes'] : array() ) as $t ) {
			if ( is_string( $t ) && '' !== trim( $t ) ) { $eyebrow = trim( $t ); break; }
		}
		if ( '' === $eyebrow ) { $eyebrow = $location; }

		// Whoever is generating this flyer — their contact details, so the
		// person reading it knows who to reach, not a generic site address.
		// The agent profile's own email/phone win when set; the WP account
		// email is the fallback so this is never blank just because the
		// agent hasn't filled in that one extra profile field.
		$uid   = get_current_user_id();
		$email = (string) get_user_meta( $uid, MWP_Agent::META . 'email', true );
		if ( '' === $email ) {
			$user_obj = get_userdata( $uid );
			$email    = ( $user_obj && ! empty( $user_obj->user_email ) ) ? (string) $user_obj->user_email : '';
		}
		$phone = (string) get_user_meta( $uid, MWP_Agent::META . 'phone', true );

		$site_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$site_host = preg_replace( '/^www\./', '', (string) $site_host );
		if ( '' === $site_host ) { $site_host = 'multiwander.com'; }

		$f = array(
			'title' => $title, 'location' => $location, 'eyebrow' => $eyebrow, 'route' => $route,
			'dur' => $dur, 'days' => $days, 'nights' => $nights, 'price' => $price,
			'desc' => $desc, 'ribbon' => $ribbon, 'hero' => $hero, 'strip' => $strip,
			'transfers' => $transfers, 'hotels_n' => $hotels_n, 'hotel_nts' => $hotel_nts,
			'acts_n' => $acts_n, 'transports_n' => $transports_n,
			'hotel_name' => $hotel_name, 'hotel_one_nights' => $hotel_one_nights,
			'hotels' => $hotels_list, 'tours' => $tours_list,
			'experiences' => $experiences, 'ref' => $id, 'brand' => 'MultiWander',
			'email' => $email, 'phone' => $phone, 'site' => $site_host, 'lang' => $lang,
		);

		self::flyer_page( $style, $f );
		exit;
	}

	/**
	 * Echo the full flyer HTML document — a premium flowing brochure.
	 *
	 * Style 1 = full brochure (hero, stats, description, photos, what's
	 * included, stay + experiences, callout, trust badges, footer).
	 * Style 2 = a compact one-screen variant in the same design language.
	 *
	 * @param int   $style 1 | 2.
	 * @param array $f     Prepared, unescaped fields.
	 * @return void
	 */
	protected static function flyer_page( $style, $f ) {
		$en = ( 'en' === $f['lang'] );
		$L  = function ( $pl, $enS ) use ( $en ) { return $en ? $enS : $pl; };

		$title   = esc_html( $f['title'] );
		$loc     = esc_html( $f['location'] );
		$eyebrow = esc_html( mb_strtoupper( (string) $f['eyebrow'], 'UTF-8' ) );
		$desc    = esc_html( $f['desc'] );
		$brand   = esc_html( $f['brand'] );
		$email   = esc_html( $f['email'] );
		$phone   = esc_html( $f['phone'] );
		$site    = esc_html( $f['site'] );
		$hero    = esc_url( $f['hero'] );
		$price   = esc_html( $f['price'] );
		$ref     = esc_html( $f['ref'] );
		$dur     = esc_html( $f['dur'] );

		$dl      = $L( 'Pobierz PDF', 'Download PDF' );
		$fromL   = $L( 'od', 'FROM' );
		$perL    = $L( 'za osobę', 'per person' );
		$inclH   = $L( 'W pakiecie', "What's included" );
		$stayH   = $L( 'Gdzie zamieszkasz', "Where you'll stay" );
		$expH    = $L( 'Atrakcje', 'Experiences' );
		$toursH  = $L( 'Wycieczki objazdowe', 'Round trips' );
		$ready   = $L( 'Gotów na tę podróż?', 'Ready for this trip?' );
		$refL    = $L( 'Nr ref.', 'Ref' );
		$nightsW = $L( 'nocy', 'nights' );

		// Icon stats (transfers / hotel / activities)
		$stats = array();
		if ( (int) $f['transfers'] > 0 ) { $stats[] = array( '&#8646;', (int) $f['transfers'] . '&times; ' . $L( 'Transfer', 'Transfer' ) ); }
		if ( (int) $f['hotels_n'] > 0 )  { $stats[] = array( '&#8962;', (int) $f['hotels_n'] . ' ' . $L( 'hotel', 'hotel' ) ); }
		if ( (int) $f['acts_n'] > 0 )    { $stats[] = array( '&#9670;', (int) $f['acts_n'] . ' ' . $L( 'atrakcje', 'activities' ) ); }

		// What's included (derived) — every service bucket the package
		// actually carries, not just a fixed set of bullets.
		$incl = array();
		if ( (int) $f['transfers'] > 0 )    { $incl[] = (int) $f['transfers'] . '&times; ' . $L( 'transfer', 'transfer' ); }
		if ( (int) $f['transports_n'] > 0 ) { $incl[] = (int) $f['transports_n'] . ' ' . $L( 'przejazd/przelot', 'transport leg(s)' ); }
		if ( (int) $f['acts_n'] > 0 )        { $incl[] = (int) $f['acts_n'] . ' ' . $L( 'atrakcje z przewodnikiem', 'guided activities' ); }
		if ( ! empty( $f['tours'] ) )        { $incl[] = count( $f['tours'] ) . ' ' . $L( 'wycieczka objazdowa', 'round trip' ); }
		if ( (int) $f['hotels_n'] > 0 )      { $incl[] = (int) $f['hotels_n'] . ' ' . $L( 'hotel', 'hotel' ) . ' &middot; ' . (int) $f['hotel_nts'] . ' ' . $nightsW; }
		$incl[] = $L( 'Wsparcie przed, w trakcie i po podróży', 'Support before, during and after your trip' );
		$incl[] = $L( 'Osobisty doradca podróży', 'Personal travel expert' );
		$incl[] = $L( 'W pełni elastyczny i dopasowany do Ciebie program', 'A fully flexible program, tailored to you' );

		// strip photos html
		$strip_html = '';
		foreach ( (array) $f['strip'] as $su ) {
			$strip_html .= '<div class="ph" style="background-image:url(\'' . esc_url( $su ) . '\')"></div>';
		}

		// experiences html
		$exp_html = '';
		foreach ( (array) $f['experiences'] as $e ) {
			$exp_html .= '<div class="exp-li"><span class="dia">&#9670;</span><span>' . esc_html( $e ) . '</span></div>';
		}

		// round trips html (closed, multi-day tours)
		$tours_html = '';
		foreach ( (array) $f['tours'] as $tr ) {
			$days_note = ( (int) $tr['days'] > 0 ) ? ' <span class="exp-days">(' . (int) $tr['days'] . ' ' . esc_html( $L( 'dni', 'days' ) ) . ')</span>' : '';
			$tours_html .= '<div class="exp-li"><span class="dia">&#9670;</span><span>' . esc_html( $tr['name'] ) . $days_note . '</span></div>';
		}

		// every hotel on the itinerary, with its board basis
		$hotels_html = '';
		foreach ( (array) $f['hotels'] as $h ) {
			$meta = array();
			if ( (int) $h['nights'] > 0 ) { $meta[] = (int) $h['nights'] . ' ' . esc_html( $nightsW ); }
			if ( '' !== $h['meal'] )       { $meta[] = esc_html( $h['meal'] ); }
			$hotels_html .= '<div class="stay-item"><div class="name">' . esc_html( $h['name'] ) . '</div>';
			if ( $meta ) { $hotels_html .= '<div class="nts">' . implode( ' &middot; ', $meta ) . '</div>'; }
			$hotels_html .= '</div>';
		}

		// included two columns
		$incl_html = '';
		foreach ( $incl as $it ) {
			$incl_html .= '<div class="inc-li"><span class="ck">&#10003;</span><span>' . $it . '</span></div>';
		}

		$hero_bg = $hero ? "background-image:linear-gradient(180deg,rgba(0,0,0,.12) 35%,rgba(0,0,0,.70) 100%),url('{$hero}');" : 'background:#2c4a4f;';

		header( 'Content-Type: text/html; charset=utf-8' );

		$css = '
		@page { size: A4; margin: 0; }
		* { box-sizing:border-box; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
		:root{ --cream:#faf7f1; --ink:#1f3a42; --teal:#15756a; --teal-soft:#e7f1ee; --gold:#c99a3f; --navy:#15303a; --muted:#7a8a8d; --line:#e4ddd0; }
		body{ margin:0; background:#c9ccd1; font-family:"Source Serif 4",Georgia,serif; color:var(--ink); }
		.bar{ position:sticky; top:0; z-index:50; background:var(--navy); color:#fff; padding:12px; display:flex; gap:14px; align-items:center; justify-content:center; }
		.bar button{ background:var(--teal); color:#fff; border:none; border-radius:8px; padding:11px 24px; font:600 15px "Source Serif 4",serif; cursor:pointer; }
		.bar span{ font-size:13px; opacity:.85; }
		.doc{ width:820px; margin:22px auto; background:var(--cream); box-shadow:0 12px 44px rgba(0,0,0,.25); overflow:hidden; }
		@media print{ body{background:#fff;} .bar{display:none;} .doc{margin:0;width:100%;box-shadow:none;transform-origin:top left;} }
		h2.sec{ font-family:"Fraunces",Georgia,serif; font-weight:600; font-size:24px; margin:0 0 16px; display:flex; align-items:center; gap:16px; color:var(--ink); }
		h2.sec::after{ content:""; flex:1; height:1px; background:var(--line); }

		.hd{ display:flex; align-items:center; padding:24px 40px; background:#fff; }
		.hd .brand{ font-family:"Fraunces",Georgia,serif; font-weight:600; font-size:26px; color:var(--ink); }

		.hero{ height:420px; background-size:cover; background-position:center; position:relative; display:flex; flex-direction:column; justify-content:flex-end; padding:40px; color:#fff; }
		.hero .eyb{ font-size:14px; letter-spacing:.2em; color:#bfe6dd; margin-bottom:12px; }
		.hero h1{ font-family:"Fraunces",Georgia,serif; font-weight:600; font-size:52px; line-height:1.04; margin:0; text-shadow:0 2px 18px rgba(0,0,0,.35); }
		.hero .loc{ display:flex; align-items:center; gap:12px; margin-top:16px; font-size:19px; }
		.hero .loc::before{ content:""; width:28px; height:2px; background:var(--gold); display:inline-block; }

		.stats{ display:flex; justify-content:space-between; align-items:center; padding:24px 40px; background:#fff; border-bottom:1px solid var(--line); }
		.stats .left{ display:flex; gap:28px; }
		.stats .st{ display:flex; align-items:center; gap:9px; font-size:16px; color:var(--ink); }
		.stats .st .i{ color:var(--teal); font-size:20px; }
		.stats .price .fl{ font-size:13px; letter-spacing:.16em; color:var(--muted); margin-right:8px; vertical-align:middle; }
		.stats .price .amt{ font-family:"Fraunces",Georgia,serif; font-weight:600; font-size:38px; color:var(--teal); }
		.stats .price .pp{ font-size:14px; color:var(--muted); margin-left:6px; }

		.body{ padding:30px 40px 0; }
		.desc{ font-size:18px; line-height:1.68; color:var(--ink); margin:0 0 26px; }
		.photos{ display:flex; gap:12px; margin-bottom:30px; }
		.photos .ph{ flex:1; height:150px; border-radius:6px; background-size:cover; background-position:center; background-color:#d7cfc0; }

		.incl-grid{ display:grid; grid-template-columns:1fr 1fr; gap:4px 34px; margin-bottom:30px; }
		.inc-li{ display:flex; gap:11px; font-size:16.5px; padding:7px 0; color:var(--ink); }
		.inc-li .ck{ color:var(--teal); font-weight:700; }

		.two{ display:flex; gap:40px; margin-bottom:30px; flex-wrap:wrap; }
		.two > div{ flex:1; min-width:220px; }
		.stay-item{ margin-bottom:14px; }
		.stay-item:last-child{ margin-bottom:0; }
		.stay-item .name{ font-weight:700; font-size:17px; }
		.stay-item .nts{ color:var(--muted); font-style:italic; font-size:15px; margin-top:2px; }
		.exp-li{ display:flex; gap:11px; font-size:16px; padding:6px 0; line-height:1.4; }
		.exp-li .dia{ color:var(--gold); }
		.exp-li .exp-days{ color:var(--muted); font-style:italic; font-size:14px; }

		.callout{ display:flex; gap:20px; align-items:flex-start; background:var(--teal-soft); border-radius:12px; padding:22px 24px; margin-bottom:30px; }
		.callout .ic{ flex:0 0 52px; width:52px; height:52px; border-radius:50%; background:var(--teal); color:#fff; display:flex; align-items:center; justify-content:center; font-size:24px; }
		.callout h3{ font-family:"Fraunces",Georgia,serif; font-weight:600; font-size:20px; margin:0 0 6px; color:var(--ink); }
		.callout p{ margin:0; font-size:15.5px; line-height:1.55; color:#45565a; }

		.trust{ display:flex; justify-content:space-between; padding:6px 10px 24px; }
		.trust .t{ text-align:center; flex:1; }
		.trust .t .i{ font-size:22px; }
		.trust .t .l{ font-size:12px; letter-spacing:.1em; color:var(--teal); font-weight:600; margin-top:6px; }

		.disc{ text-align:center; font-style:italic; font-size:13.5px; color:var(--muted); padding:0 40px 26px; }

		.foot{ background:var(--navy); color:#fff; padding:34px 40px; display:flex; justify-content:space-between; align-items:center; }
		.foot .ready{ font-family:"Fraunces",Georgia,serif; font-weight:600; font-size:30px; margin:0 0 8px; }
		.foot .fb{ color:var(--gold); font-weight:600; font-size:17px; }
		.foot .ref{ color:#bfe6dd; font-size:14px; margin-top:8px; }
		.foot .fc{ color:#9fb8bd; font-size:13px; margin-top:6px; }
		.foot .rp .fl{ font-size:12px; letter-spacing:.16em; color:#8fb0b6; display:block; text-align:right; }
		.foot .rp .amt{ font-family:"Fraunces",Georgia,serif; font-weight:600; font-size:34px; }
		.foot .rp .pp{ font-size:13px; color:#9fb8bd; display:block; text-align:right; }
		';

		echo "<!doctype html><html lang=\"" . esc_attr( $f['lang'] ) . "\"><head><meta charset=\"utf-8\">";
		echo "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">";
		// SEO-strong filename: when the agent prints this flyer to PDF, the
		// browser uses the document <title> as the default file name, so we
		// lead with the brand and the tour's own name.
		echo "<title>Multiwander - " . $title . "</title>";
		echo "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\"><link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>";
		echo "<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Source+Serif+4:ital,wght@0,400;0,600;0,700;1,400&display=swap\">";
		echo "<style>" . $css . "</style></head><body>";
		echo "<div class=\"bar\"><button onclick=\"window.print()\">&#11015; " . esc_html( $dl ) . "</button><span>" . ( 1 === $style ? 'Brochure' : 'Compact' ) . "</span></div>";

		echo "<div class=\"doc\">";

		// Header — just the brand; a second "Holiday Package" pill next to it
		// only repeated what the page already says.
		echo "<div class=\"hd\"><div class=\"brand\">" . $brand . "</div></div>";

		// Hero
		echo "<div class=\"hero\" style=\"{$hero_bg}\">";
		if ( '' !== $eyebrow ) { echo "<div class=\"eyb\">" . $eyebrow . "</div>"; }
		echo "<h1>" . $title . "</h1>";
		if ( '' !== $loc ) { echo "<div class=\"loc\">" . $loc . "</div>"; }
		echo "</div>";

		// Stats bar
		echo "<div class=\"stats\"><div class=\"left\">";
		foreach ( $stats as $st ) { echo "<div class=\"st\"><span class=\"i\">" . $st[0] . "</span><span>" . $st[1] . "</span></div>"; }
		echo "</div>";
		if ( '' !== $price ) { echo "<div class=\"price\"><span class=\"fl\">" . esc_html( mb_strtoupper( $fromL, 'UTF-8' ) ) . "</span><span class=\"amt\">" . $price . "</span><span class=\"pp\">/ " . esc_html( $en ? 'person' : 'os.' ) . "</span></div>"; }
		echo "</div>";

		echo "<div class=\"body\">";
		if ( '' !== $desc ) { echo "<p class=\"desc\">" . $desc . "</p>"; }
		if ( '' !== $strip_html ) { echo "<div class=\"photos\">" . $strip_html . "</div>"; }

		if ( 1 === $style ) {
			// What's included
			echo "<h2 class=\"sec\">" . esc_html( $inclH ) . "</h2><div class=\"incl-grid\">" . $incl_html . "</div>";

			// Stay (every hotel) + Experiences (single-day excursions)
			if ( '' !== $hotels_html || '' !== $exp_html ) {
				echo "<div class=\"two\">";
				if ( '' !== $hotels_html ) {
					echo "<div class=\"stay\"><h2 class=\"sec\">" . esc_html( $stayH ) . "</h2>" . $hotels_html . "</div>";
				}
				if ( '' !== $exp_html ) {
					echo "<div class=\"exps\"><h2 class=\"sec\">" . esc_html( $expH ) . "</h2>" . $exp_html . "</div>";
				}
				echo "</div>";
			}

			// Round trips (multi-day closed tours) — listed on their own,
			// since a guided bus or Nile cruise itinerary is a different thing
			// from a single-day excursion.
			if ( '' !== $tours_html ) {
				echo "<h2 class=\"sec\">" . esc_html( $toursH ) . "</h2><div class=\"exps\" style=\"margin-bottom:30px\">" . $tours_html . "</div>";
			}

			// Callout
			echo "<div class=\"callout\"><div class=\"ic\">&#10022;</div><div><h3>" . esc_html( $L( 'W pełni elastyczne', 'Fully Customisable' ) ) . "</h3><p>" . esc_html( $L( 'Zainspiruj się, a potem dopasuj wszystko do siebie. Każdą podróż projektujemy pod Twoje indywidualne pomysły i preferencje.', 'Get inspired, then make it yours. We tailor every journey to your individual travel ideas and preferences.' ) ) . "</p></div></div>";

			// Trust badges
			$badges = array(
				array( '&#10024;', $L( 'NA MIARĘ', 'TAILOR-MADE' ) ),
				array( '&#128274;', $L( 'BEZPIECZNA REZERWACJA', 'SECURE BOOKING' ) ),
				array( '&#128172;', $L( 'ZAWSZE DLA CIEBIE', 'ALWAYS HERE FOR YOU' ) ),
				array( '&#129517;', $L( 'EKSPERCKA RADA', 'EXPERT ADVICE' ) ),
			);
			echo "<div class=\"trust\">";
			foreach ( $badges as $b ) { echo "<div class=\"t\"><div class=\"i\">" . $b[0] . "</div><div class=\"l\">" . esc_html( $b[1] ) . "</div></div>"; }
			echo "</div>";
		}

		echo "</div>"; // .body

		// Disclaimer
		echo "<div class=\"disc\">" . esc_html( $L( 'Ceny są dynamiczne i zależą od dostępności — mogą ulec zmianie i nie są gwarantowane.', 'Prices are dynamic and subject to availability, so they may change and cannot be guaranteed.' ) ) . "</div>";

		// Footer
		echo "<div class=\"foot\"><div><div class=\"ready\">" . esc_html( $ready ) . "</div><div class=\"fb\">" . $brand . "</div>";
		echo "<div class=\"ref\">&#9638; " . esc_html( $refL ) . ": " . $ref . "</div>";
		$fc = array();
		if ( '' !== $email ) { $fc[] = $email; }
		if ( '' !== $phone ) { $fc[] = $phone; }
		$fc[] = $site;
		echo "<div class=\"fc\">" . implode( ' &middot; ', $fc ) . "</div></div>";
		if ( '' !== $price ) { echo "<div class=\"rp\"><span class=\"fl\">" . esc_html( mb_strtoupper( $fromL, 'UTF-8' ) ) . "</span><span class=\"amt\">" . $price . "</span><span class=\"pp\">" . esc_html( $perL ) . "</span></div>"; }
		echo "</div>";

		echo "</div>"; // .doc

		// Shrink the whole page to fit one A4 sheet on print/PDF, whatever
		// the package's own content runs to (more hotels, more round trips,
		// a longer description all make the page taller). zoom reflows the
		// box itself, so the printed page is genuinely shorter — not just
		// visually smaller — which is what keeps it to one sheet. Firefox
		// has no zoom, so there the content is scaled visually and the box
		// height is capped to match, accepting a clipped tail there rather
		// than spilling onto a blank second page.
		echo '<script>(function(){
			function px(mm){ return mm * 96 / 25.4; }
			var PAGE_H = px(297) - 8;
			function fit(){
				var doc = document.querySelector(".doc");
				if (!doc) return;
				doc.style.zoom = "";
				doc.style.transform = "";
				doc.style.height = "";
				doc.style.overflow = "";
				var h = doc.scrollHeight;
				if (h <= PAGE_H) return;
				var scale = PAGE_H / h;
				if ("zoom" in document.body.style) {
					doc.style.zoom = scale;
				} else {
					doc.style.transform = "scale(" + scale + ")";
					doc.style.transformOrigin = "top left";
					doc.style.width = (100 / scale) + "%";
					doc.style.height = h + "px";
					doc.style.overflow = "hidden";
				}
			}
			function reset(){
				var doc = document.querySelector(".doc");
				if (!doc) return;
				doc.style.zoom = "";
				doc.style.transform = "";
				doc.style.width = "";
				doc.style.height = "";
				doc.style.overflow = "";
			}
			window.addEventListener("beforeprint", fit);
			window.addEventListener("afterprint", reset);
		})();</script>';

		echo "</body></html>";
	}
}

/**
 * Cache-busting version for a bundled asset.
 *
 * @param string $relative Path relative to the plugin root.
 * @return string
 */
function MWPP_asset_version( $relative ) { // phpcs:ignore WordPress.NamingConventions
	$path = MWP_DIR . $relative;
	return file_exists( $path ) ? (string) filemtime( $path ) : MWP_VERSION;
}
