<?php
/**
 * Drawing the finished post.
 *
 * Not a cropped photograph for someone to finish in Canva — the actual image
 * that goes out: photo, headline, route, price, the brand mark and a call to
 * action, at the exact pixel size each network wants.
 *
 * Done with GD on the server rather than in a browser, so it is the same every
 * time, needs nothing installed, and a scheduled job could one day produce a
 * week of posts without anyone watching. The type is Carlito, subset to Latin
 * and Latin Extended-A and bundled with the plugin — it carries every Polish
 * diacritic, it is OFL licensed, and at 110 KB it costs less than one of the
 * photographs it sits on. Drop a Poppins TTF in assets/fonts/ and the brand
 * face takes over; see font().
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Poster {

	/** Brand colours, as GD wants them. */
	const BRAND = array( 23, 163, 152 );
	const INK   = array( 17, 24, 39 );

	/** Logo source URL and transient key. */
	const LOGO_URL       = 'https://multiwander.com/wp-content/uploads/2026/05/png-multiwander-logo-social-media.png';
	const LOGO_TRANSIENT = 'mwp_poster_logo_v3';

	/**
	 * Where a typeface comes from.
	 *
	 * The bundled subset is the default so this works on a fresh install with
	 * nothing configured. Poppins is the site's own face, so if a file called
	 * poppins-bold.ttf / poppins-regular.ttf is dropped beside the bundled
	 * ones it wins — no setting to find, no code to change.
	 *
	 * @param string $weight bold|regular
	 * @return string Absolute path.
	 */
	public static function font( $weight = 'bold' ) {
		$dir = MWP_DIR . 'assets/fonts/';

		$preferred = $dir . 'poppins-' . $weight . '.ttf';

		$path = file_exists( $preferred ) ? $preferred : $dir . 'mw-' . $weight . '.ttf';

		return (string) apply_filters( 'mwp_poster_font', $path, $weight );
	}

	/**
	 * Can this server draw at all?
	 *
	 * imagettftext needs GD compiled with FreeType, which is usual but not
	 * universal. Better to say so on the screen than to hand somebody a blank
	 * rectangle.
	 *
	 * @return bool
	 */
	public static function available() {
		return function_exists( 'imagecreatetruecolor' ) && function_exists( 'imagettftext' );
	}

	/**
	 * The two templates.
	 *
	 * @return array<string,string>
	 */
	public static function styles() {
		return array(
			'photo' => __( 'Template 1 — photo-first', 'multiwander-packages' ),
			'band'  => __( 'Template 2 — brand band', 'multiwander-packages' ),
		);
	}

	/* ===================================================================
	   Drawing helpers
	   =================================================================== */

	/**
	 * Allocate a colour.
	 *
	 * @param resource|GdImage $im    Canvas.
	 * @param array            $rgb   Colour.
	 * @param int              $alpha 0 opaque … 127 invisible.
	 * @return int
	 */
	protected static function col( $im, array $rgb, $alpha = 0 ) {
		return imagecolorallocatealpha( $im, $rgb[0], $rgb[1], $rgb[2], $alpha );
	}

	/**
	 * Break a line of text to a width, in the font it will be drawn in.
	 *
	 * Measured with the real font at the real size rather than counted in
	 * characters, because "Mövenpick" and "iii" are not the same width and a
	 * headline that overruns its box is the one mistake that makes a
	 * generated post look generated.
	 *
	 * @param string $text Text.
	 * @param string $font Font path.
	 * @param int    $size Point size.
	 * @param int    $max  Pixel width.
	 * @param int    $lines Maximum lines; the last one is ellipsised.
	 * @return string[]
	 */
	protected static function wrap( $text, $font, $size, $max, $lines = 3 ) {
		$words = preg_split( '/\s+/u', trim( $text ) );
		$out   = array();
		$line  = '';
		$used  = 0;

		foreach ( $words as $i => $word ) {
			$try = '' === $line ? $word : $line . ' ' . $word;
			$box = imagettfbbox( $size, 0, $font, $try );

			if ( abs( $box[2] - $box[0] ) <= $max || '' === $line ) {
				$line = $try;
				$used = $i + 1;
				continue;
			}

			$out[] = $line;
			$line  = $word;
			$used  = $i + 1;

			if ( count( $out ) >= $lines ) {
				$line = '';
				$used = $i;
				break;
			}
		}

		if ( count( $out ) < $lines && '' !== $line ) {
			$out[] = $line;
		}

		/*
		 * Only ellipsise when words were genuinely left over.
		 *
		 * The count of CONSUMED WORDS decides that, not a comparison of string
		 * lengths: the words are rejoined with single spaces, so a route
		 * written "Asuan  ·  Luksor" comes back shorter than it went in and a
		 * length test declares an overflow that never happened. That is how
		 * "Asuan → Luksor" became "Asuan → Luksor…" on a line with room to
		 * spare.
		 */
		if ( $used < count( $words ) && $out ) {
			$last = end( $out );

			while ( $last && abs( imagettfbbox( $size, 0, $font, $last . '…' )[2] ) > $max ) {
				$last = mb_substr( $last, 0, -1 );
			}

			$out[ count( $out ) - 1 ] = rtrim( $last ) . '…';
		}

		return $out;
	}

	/**
	 * A soft dark gradient, so white type stays readable over any photograph.
	 *
	 * Drawn as a stack of one-pixel bars with rising alpha. Crude, and exactly
	 * right: it costs nothing, it needs no image filter, and the eye reads it
	 * as a smooth fade.
	 *
	 * @param resource|GdImage $im     Canvas.
	 * @param int              $top    Where the fade starts.
	 * @param int              $bottom Where it ends (fully dark).
	 * @param int              $width  Canvas width.
	 * @param float            $peak   Strongest opacity, 0..1.
	 * @return void
	 */
	protected static function scrim( $im, $top, $bottom, $width, $peak = 0.88 ) {
		$height = max( 1, $bottom - $top );

		for ( $y = 0; $y < $height; $y++ ) {
			$t = $y / $height;

			// Cubed rather than squared: the fade stays almost invisible over
			// the top half of its run and does its darkening close to the
			// type, which is the only place it is needed.
			$alpha = (int) round( 127 - ( 127 * $peak * ( $t * $t * $t ) ) );
			$c     = imagecolorallocatealpha( $im, 8, 20, 26, max( 0, min( 127, $alpha ) ) );
			imagefilledrectangle( $im, 0, $top + $y, $width, $top + $y + 1, $c );
		}
	}

	/**
	 * A pill, of the kind the site uses everywhere.
	 *
	 * @param resource|GdImage $im    Canvas.
	 * @param int              $x     Left.
	 * @param int              $y     Top.
	 * @param string           $text  Label.
	 * @param int              $size  Point size.
	 * @param array            $bg    Background colour.
	 * @param array            $fg    Text colour.
	 * @param int              $padX  Horizontal padding.
	 * @return int[] [width, height]
	 */
	protected static function pill( $im, $x, $y, $text, $size, array $bg, array $fg, $padX = 26 ) {
		$font = self::font( 'bold' );
		$box  = imagettfbbox( $size, 0, $font, $text );
		$w    = abs( $box[2] - $box[0] ) + ( $padX * 2 );
		$h    = (int) round( $size * 2.4 );
		$r    = (int) round( $h / 2 );

		$c = self::col( $im, $bg );

		imagefilledrectangle( $im, $x + $r, $y, $x + $w - $r, $y + $h, $c );
		imagefilledellipse( $im, $x + $r, $y + $r, $h, $h, $c );
		imagefilledellipse( $im, $x + $w - $r, $y + $r, $h, $h, $c );

		imagettftext(
			$im,
			$size,
			0,
			(int) ( $x + $padX ),
			(int) ( $y + $h / 2 + $size * 0.38 ),
			self::col( $im, $fg ),
			$font,
			$text
		);

		return array( $w, $h );
	}

	/**
	 * Fetch and scale the MultiWander logo PNG.
	 *
	 * The raw PNG bytes are cached in a one-day transient so poster
	 * generation never makes more than one outbound request per day.
	 * Returns null on any failure — network error, bad PNG, or a host
	 * without imagecreatefromstring — so callers silently skip the logo
	 * rather than aborting the poster.
	 *
	 * @param int $height Target height in pixels.
	 * @return resource|GdImage|null
	 */
	protected static function logo_gd( $height ) {
		$body = get_transient( self::LOGO_TRANSIENT );

		if ( false === $body ) {
			$resp = wp_remote_get( self::LOGO_URL, array( 'timeout' => 10 ) );
			if ( is_wp_error( $resp ) || 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) {
				return null;
			}
			$body = wp_remote_retrieve_body( $resp );
			set_transient( self::LOGO_TRANSIENT, $body, DAY_IN_SECONDS );
		}

		if ( ! $body ) {
			return null;
		}

		$src = @imagecreatefromstring( $body ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! $src ) {
			return null;
		}

		$sw     = imagesx( $src );
		$sh     = imagesy( $src );
		$height = max( 1, (int) round( $height ) );
		$width  = max( 1, (int) round( $height * $sw / $sh ) );

		// Create the scaled copy with a transparent background so the PNG
		// alpha channel survives the resize.
		$dst = imagecreatetruecolor( $width, $height );
		imagealphablending( $dst, false );
		imagesavealpha( $dst, true );
		imagefilledrectangle( $dst, 0, 0, $width, $height, imagecolorallocatealpha( $dst, 0, 0, 0, 127 ) );
		imagealphablending( $dst, true );
		imagecopyresampled( $dst, $src, 0, 0, 0, 0, $width, $height, $sw, $sh );
		imagedestroy( $src );

		return $dst;
	}

	/**
	 * Composite the MultiWander logo onto the canvas at the given position.
	 *
	 * A broken or missing logo is silently skipped — the poster is still
	 * complete and correct without it.
	 *
	 * @param resource|GdImage $im     Canvas.
	 * @param int              $x      Left edge.
	 * @param int              $y      Top edge.
	 * @param int              $height Target height in pixels.
	 * @return void
	 */
	protected static function draw_logo( $im, $x, $y, $height ) {
		$logo = self::logo_gd( $height );
		if ( ! $logo ) {
			return;
		}
		imagealphablending( $im, true );
		imagecopy( $im, $logo, $x, $y, 0, 0, imagesx( $logo ), imagesy( $logo ) );
		imagedestroy( $logo );
	}

	/**
	 * A straight diagonal band across the top-right corner of the canvas.
	 *
	 * Only drawn when $text is non-empty. Brand-teal with white text rotated
	 * −45° to run along the band. It is a true straight strip — a rotated
	 * rectangle of constant width — rather than a shape pieced together from
	 * where a diagonal meets the canvas edges, which is what previously made
	 * it look like a bow instead of a plain ribbon band. Running it well past
	 * both edges of the canvas and letting GD clip it there means the ends
	 * are simply cut off square, never tapered to a point.
	 *
	 * Sized and placed off the SHORTER side of the canvas, not $W. A 1200×900
	 * landscape format has plenty of width to spare but a title that starts
	 * well up into that shorter 900px height — sizing off $W alone (as a
	 * first pass here did) drew a band long enough to reach down into the
	 * headline text. Keeping it compact and anchored to min(W,H) keeps it a
	 * small corner badge on every format, square, landscape or story alike.
	 *
	 * @param resource|GdImage $im   Canvas.
	 * @param int              $W    Canvas width.
	 * @param int              $H    Canvas height.
	 * @param float            $u    Unused — kept for a stable call signature; sizing is derived from min($W,$H) instead.
	 * @param string           $text Ribbon copy.
	 * @return void
	 */
	protected static function draw_ribbon( $im, $W, $H, $u, $text ) {
		$text = trim( $text );
		if ( '' === $text ) {
			return;
		}

		$u2 = min( $W, $H ) / 1080;

		$font = self::font( 'bold' );
		$size = (int) round( 26 * $u2 );

		$band_w = (int) round( 46 * $u2 );  // constant width of the strip
		$length = (int) round( 260 * $u2 ); // just long enough to clear the corner, not the whole canvas
		$cx     = $W - (int) round( 90 * $u2 );
		$cy     = (int) round( 90 * $u2 );

		$angle = -45 * M_PI / 180;
		$cos_a = cos( $angle );
		$sin_a = sin( $angle );

		$hl = $length / 2;
		$hw = $band_w / 2;

		// Rectangle corners, centred on the origin, then rotated and
		// translated to (cx, cy) — a proper parallelogram band, never a
		// self-crossing or tapering shape.
		$corners = array(
			array( -$hl, -$hw ),
			array( $hl, -$hw ),
			array( $hl, $hw ),
			array( -$hl, $hw ),
		);

		$points = array();
		foreach ( $corners as $c ) {
			$points[] = (int) round( $cx + ( $c[0] * $cos_a - $c[1] * $sin_a ) );
			$points[] = (int) round( $cy + ( $c[0] * $sin_a + $c[1] * $cos_a ) );
		}

		imagealphablending( $im, true );
		imagefilledpolygon( $im, $points, 4, self::col( $im, self::BRAND ) );

		$box = imagettfbbox( $size, -45, $font, $text );
		if ( $box ) {
			$ox = $cx - (int) round( ( $box[0] + $box[4] ) / 2 );
			$oy = $cy - (int) round( ( $box[1] + $box[5] ) / 2 );
			imagettftext( $im, $size, -45, $ox, $oy, self::col( $im, array( 255, 255, 255 ) ), $font, $text );
		}
	}

	/* ===================================================================
	   The poster
	   =================================================================== */

	/**
	 * Place the photograph on the canvas at the requested size.
	 *
	 * Travel Compositor's photographs are about 900 × 720 — measured, not
	 * assumed; there is no larger original hiding behind them. A 9:16 story is
	 * 1080 × 1920, so filling it means enlarging a 900px picture two and a
	 * half times and cutting away two thirds of its width. That is how a
	 * cruise ship ends up as a close-up of three cabin windows.
	 *
	 * So the frame is filled the honest way when the photograph can stand it,
	 * and when it cannot the picture is shown whole over a blurred, darkened
	 * copy of itself. That is the treatment Instagram itself uses for exactly
	 * this problem: it looks deliberate, nothing is stretched, and the subject
	 * survives.
	 *
	 * @param string $file  Source image path.
	 * @param int    $W     Canvas width.
	 * @param int    $H     Canvas height.
	 * @param string $focus top|center|bottom — which part to keep.
	 * @param float  $zoom  1.0 = as much of the photograph as fits.
	 * @return resource|GdImage|null
	 */
	protected static function canvas( $file, $W, $H, $focus = 'center', $zoom = 1.0 ) {
		$src = @imagecreatefromstring( (string) file_get_contents( $file ) ); // phpcs:ignore

		if ( ! $src ) {
			return null;
		}

		$sw = imagesx( $src );
		$sh = imagesy( $src );

		$im = imagecreatetruecolor( $W, $H );
		imagealphablending( $im, true );

		$zoom = max( 1.0, min( 3.0, (float) $zoom ) );

		// How far the photograph must be stretched to cover the frame.
		$cover = max( $W / $sw, $H / $sh ) * $zoom;

		$limit = (float) apply_filters( 'mwp_poster_max_upscale', 1.45 );

		if ( $cover <= $limit ) {
			// Straight cover crop: take the largest rectangle of the right
			// shape, from the chosen part of the picture.
			$cw = min( $sw, (int) round( ( $W / $cover ) ) );
			$ch = min( $sh, (int) round( ( $H / $cover ) ) );

			$x = (int) round( ( $sw - $cw ) / 2 );

			if ( 'top' === $focus ) {
				$y = 0;
			} elseif ( 'bottom' === $focus ) {
				$y = $sh - $ch;
			} else {
				$y = (int) round( ( $sh - $ch ) / 2 );
			}

			imagecopyresampled( $im, $src, 0, 0, $x, max( 0, $y ), $W, $H, $cw, $ch );
			imagedestroy( $src );

			return $im;
		}

		/*
		 * Backdrop treatment. The blur is done on a small copy and enlarged,
		 * which is both far faster than blurring at full size and blurrier
		 * than repeated filter passes could make it.
		 */
		$small = imagecreatetruecolor( 60, (int) max( 1, round( 60 * $sh / $sw ) ) );
		imagecopyresampled( $small, $src, 0, 0, 0, 0, imagesx( $small ), imagesy( $small ), $sw, $sh );

		for ( $i = 0; $i < 3; $i++ ) {
			imagefilter( $small, IMG_FILTER_GAUSSIAN_BLUR );
		}

		$bw = max( $W / imagesx( $small ), $H / imagesy( $small ) );
		imagecopyresampled(
			$im,
			$small,
			(int) round( ( $W - imagesx( $small ) * $bw ) / 2 ),
			(int) round( ( $H - imagesy( $small ) * $bw ) / 2 ),
			0,
			0,
			(int) round( imagesx( $small ) * $bw ),
			(int) round( imagesy( $small ) * $bw ),
			imagesx( $small ),
			imagesy( $small )
		);
		imagedestroy( $small );

		// Darkened, so the sharp picture and the white type both separate
		// from it.
		imagefilledrectangle( $im, 0, 0, $W, $H, imagecolorallocatealpha( $im, 8, 20, 26, 78 ) );

		// The photograph itself: full width, zoom applied, sitting in the
		// upper half where the type is not.
		$pw = (int) round( $W * min( 1.0, $zoom ) );
		$ph = (int) round( $pw * $sh / $sw );
		$px = (int) round( ( $W - $pw ) / 2 );
		$py = 'top' === $focus
			? (int) round( $H * 0.06 )
			: ( 'bottom' === $focus ? (int) round( $H * 0.34 ) : (int) round( $H * 0.20 ) );

		imagecopyresampled( $im, $src, $px, $py, 0, 0, $pw, $ph, $sw, $sh );
		imagedestroy( $src );

		return $im;
	}

	/**
	 * Build one post image.
	 *
	 * @param array  $d       Package payload.
	 * @param string $format  Key from MWP_Social::formats().
	 * @param string $style   Key from styles().
	 * @param string $photo   Source photograph URL.
	 * @param string      $focus    top|center|bottom.
	 * @param float       $zoom     Framing scale.
	 * @param string      $ribbon   Optional corner-ribbon text.
	 * @param string|null $currency 'eur'|'pln'|null — null keeps the old PLN-by-default behaviour.
	 * @return string URL of the finished image, or '' on failure.
	 */
	public static function build( array $d, $format, $style, $photo, $focus = 'center', $zoom = 1.0, $ribbon = '', $currency = null ) {
		if ( ! self::available() ) {
			return '';
		}

		$formats = MWP_Social::formats();

		if ( ! isset( $formats[ $format ] ) || ! $photo ) {
			return '';
		}

		$spec = $formats[ $format ];

		$upload = wp_upload_dir();
		$name   = 'post-' . md5(
			$photo . '|' . $format . '|' . $style . '|' . $focus . '|' . $zoom . '|' . $currency . '|' . MWP_VERSION . '|' .
			wp_json_encode( array( $d['title'] ?? '', $d['price'] ?? array(), $ribbon ) )
		) . '.jpg';
		$dir    = trailingslashit( $upload['basedir'] ) . MWP_Social::DIR;
		$path   = trailingslashit( $dir ) . $name;
		$link   = trailingslashit( $upload['baseurl'] ) . MWP_Social::DIR . '/' . $name;

		if ( file_exists( $path ) ) {
			return $link;
		}

		$source = MWP_Social::source_path( $photo );

		if ( ! $source ) {
			return '';
		}

		/*
		 * Template 2 only shows the photograph in the top part of the frame,
		 * so that is the shape the photograph is fitted to. Fitting it to the
		 * whole canvas and then covering a third of it with the brand band
		 * would crop away a third of the picture for nothing — and on a 9:16
		 * frame it would trigger the blurred backdrop when the actual photo
		 * area is a comfortable 1080 × 1270.
		 */
		if ( 'band' === $style ) {
			$im = self::canvas(
				$source,
				(int) $spec['w'],
				(int) $spec['h'] - self::band_height( (int) $spec['w'], (int) $spec['h'] ),
				$focus,
				$zoom
			);

			if ( $im ) {
				$full = imagecreatetruecolor( (int) $spec['w'], (int) $spec['h'] );
				imagefilledrectangle( $full, 0, 0, (int) $spec['w'], (int) $spec['h'], imagecolorallocate( $full, 255, 255, 255 ) );
				imagecopy( $full, $im, 0, 0, 0, 0, imagesx( $im ), imagesy( $im ) );
				imagedestroy( $im );
				$im = $full;
				imagealphablending( $im, true );
			}
		} else {
			$im = self::canvas( $source, (int) $spec['w'], (int) $spec['h'], $focus, $zoom );
		}

		if ( ! $im ) {
			return '';
		}

		/*
		 * The layout measures the canvas rather than trusting the format.
		 *
		 * Belt and braces after the crop bug: text printed past the edge of
		 * the canvas is silently discarded by GD, which is why the first
		 * version looked like a photograph with a logo and nothing else.
		 */
		$W = imagesx( $im );
		$H = imagesy( $im );

		$bold    = self::font( 'bold' );
		$regular = self::font( 'regular' );

		// Everything scales off the canvas width, so one set of numbers draws
		// a square, a story and a 4:3 without a special case for each.
		$u    = $W / 1080;
		$pad  = (int) round( 72 * $u );
		$white = array( 255, 255, 255 );

		$title    = trim( (string) ( $d['title'] ?? '' ) );
		$price    = self::price_line( $d, $currency );
		$route    = self::route_line( $d );
		$kicker   = self::kicker_line( $d );
		$duration = self::duration_line( $d );

		if ( 'band' === $style ) {
			self::draw_band( $im, compact( 'W', 'H', 'u', 'pad', 'title', 'price', 'route', 'kicker', 'duration', 'bold', 'regular' ) );
		} else {
			self::draw_photo( $im, compact( 'W', 'H', 'u', 'pad', 'title', 'price', 'route', 'kicker', 'duration', 'bold', 'regular' ) );
		}

		// Ribbon is drawn last — on top of both templates — so it is never
		// occluded by type or the gradient.
		if ( '' !== trim( $ribbon ) ) {
			self::draw_ribbon( $im, $W, $H, $u, $ribbon );
		}

		if ( ! wp_mkdir_p( $dir ) ) {
			imagedestroy( $im );
			return '';
		}

		imagejpeg( $im, $path, 88 );
		imagedestroy( $im );

		return file_exists( $path ) ? $link : '';
	}

	/**
	 * Template 1 — the photograph carries the post.
	 *
	 * Type sits on a gradient at the foot of the frame. It is the layout that
	 * stops a scroll, because at thumbnail size the picture is the whole
	 * message and the words are a caption to it.
	 *
	 * @param resource|GdImage $im   Canvas.
	 * @param array            $a    Drawing context.
	 * @return void
	 */
	protected static function draw_photo( $im, array $a ) {
		extract( $a ); // phpcs:ignore WordPress.PHP.DontExtract

		$white = array( 255, 255, 255 );

		// Starts high and rises gently: a fade that reaches full strength
		// halfway up reads as a black bar stuck to the bottom of a photograph,
		// which is what it looked like at 0.42 with a squared curve.
		self::scrim( $im, (int) ( $H * 0.30 ), $H, $W, 0.9 );

		$titleSize = (int) round( ( $H > $W ? 54 : 52 ) * $u );
		$smallSize = (int) round( 26 * $u );

		$lines = self::wrap( $title, $bold, $titleSize, $W - ( $pad * 2 ), 3 );
		$lead  = (int) round( $titleSize * 1.26 );

		/*
		 * Laid out from the bottom up: the call to action is pinned to the
		 * foot of the frame and the headline grows upwards, so a long title
		 * never pushes the price off the image.
		 *
		 * A 9:16 frame keeps a deeper margin, because Instagram and TikTok
		 * both paint their own furniture over the bottom of a story — the
		 * reply bar, the username, the sound strip. Type placed at the same
		 * inset as a square post disappears underneath it.
		 */
		$safe = ( $H / $W > 1.5 ) ? (int) round( 200 * $u ) : 0;
		$y    = $H - $pad - $safe;

		$y -= (int) round( 18 * $u );

		// The brand is already named once, in the pill top-left — printing
		// "multiwander.com" again down here just repeats it, so only the call
		// to action sits on this line.
		$cta = 'Wybierz swój termin →';
		$box = imagettfbbox( $smallSize, 0, $bold, $cta );
		imagettftext( $im, $smallSize, 0, $W - $pad - abs( $box[2] - $box[0] ), $y, self::col( $im, array( 127, 227, 216 ) ), $bold, $cta );

		$y -= (int) round( 58 * $u );

		if ( $price ) {
			$priceSize = (int) round( 44 * $u );
			imagettftext( $im, $priceSize, 0, $pad, $y, self::col( $im, $white ), $bold, $price );
			$y -= (int) round( 62 * $u );
		}

		$meta = trim( implode( '  ·  ', array_filter( array( $duration, $route ) ) ) );

		if ( $meta ) {
			$metaLines = self::wrap( $meta, $regular, $smallSize, $W - ( $pad * 2 ), 1 );
			imagettftext( $im, $smallSize, 0, $pad, $y, self::col( $im, array( 226, 232, 236 ) ), $regular, $metaLines[0] );
			$y -= (int) round( 56 * $u );
		}

		foreach ( array_reverse( $lines ) as $line ) {
			imagettftext( $im, $titleSize, 0, $pad, $y, self::col( $im, $white ), $bold, $line );
			$y -= $lead;
		}

		if ( $kicker ) {
			$y -= (int) round( 10 * $u );
			imagettftext( $im, $smallSize, 0, $pad, $y, self::col( $im, array( 127, 227, 216 ) ), $bold, mb_strtoupper( $kicker ) );
		}

		// Brand pill at top-left — "multiwander.com" in the brand colour.
		self::pill( $im, $pad, $pad, 'multiwander.com', (int) round( 20 * $u ), self::BRAND, array( 255, 255, 255 ) );
	}

	/**
	 * How deep the brand band is.
	 *
	 * One place, because build() has to fit the photograph to the space above
	 * it and draw_band() has to paint it — and the two disagreeing by a few
	 * pixels shows as a seam.
	 *
	 * @param int $W Canvas width.
	 * @param int $H Canvas height.
	 * @return int
	 */
	protected static function band_height( $W, $H ) {
		return (int) round( $H * ( $H > $W ? 0.34 : 0.4 ) );
	}

	/**
	 * Template 2 — photograph above, brand band below.
	 *
	 * Type on a solid colour, which is the safe layout: it reads at any size,
	 * over any photograph, in any light. Less arresting than template 1 and
	 * considerably harder to get wrong — the one to use when the picture is
	 * busy or pale.
	 *
	 * @param resource|GdImage $im Canvas.
	 * @param array            $a  Drawing context.
	 * @return void
	 */
	protected static function draw_band( $im, array $a ) {
		extract( $a ); // phpcs:ignore WordPress.PHP.DontExtract

		/*
		 * Re-calibrate $u to the shorter dimension.
		 *
		 * The parent passes $u = $W / 1080 (correct for template 1, which fills
		 * the full canvas). For template 2 the text lives in the band — whose
		 * height is fixed at 40 % of $H — so font sizes must scale to the
		 * shorter side, not the wider one. On square and story frames this is
		 * identical to the parent value; on GBP (1200 × 900) it drops from
		 * 1.111 to 0.833, which is what lets the kicker + two-line title + meta
		 * + price/CTA footer all coexist inside 360 px without overflowing.
		 */
		$u = min( $W, $H ) / 1080;

		$white = array( 255, 255, 255 );
		$band  = self::band_height( $W, $H );
		$top   = $H - $band;

		imagefilledrectangle( $im, 0, $top, $W, $H, self::col( $im, array( 255, 255, 255 ) ) );

		// A brand rule along the seam, so the band belongs to the photograph
		// rather than looking like a crop that went wrong.
		imagefilledrectangle( $im, 0, $top, $W, $top + (int) round( 8 * $u ), self::col( $im, self::BRAND ) );

		// Brand pill at top-left — same as draw_photo(); $W/1080 because $u has
		// been overridden to min($W,$H)/1080 for band-text sizing.
		self::pill( $im, $pad, $pad, 'multiwander.com', (int) round( 20 * $W / 1080 ), self::BRAND, array( 255, 255, 255 ) );

		$y = $top + (int) round( 62 * $u );

		if ( $kicker ) {
			imagettftext( $im, (int) round( 24 * $u ), 0, $pad, $y, self::col( $im, array( 18, 138, 129 ) ), $bold, mb_strtoupper( $kicker ) );
			$y += (int) round( 48 * $u );
		}

		$titleSize = (int) round( 48 * $u );
		$lines     = self::wrap( $title, $bold, $titleSize, $W - ( $pad * 2 ), 2 );

		foreach ( $lines as $line ) {
			imagettftext( $im, $titleSize, 0, $pad, $y, self::col( $im, self::INK ), $bold, $line );
			$y += (int) round( $titleSize * 1.24 );
		}

		$meta = trim( implode( '  ·  ', array_filter( array( $duration, $route ) ) ) );

		if ( $meta ) {
			$metaLines = self::wrap( $meta, $regular, (int) round( 26 * $u ), $W - ( $pad * 2 ), 1 );
			$y        += (int) round( 8 * $u );
			imagettftext( $im, (int) round( 26 * $u ), 0, $pad, $y, self::col( $im, array( 91, 100, 112 ) ), $regular, $metaLines[0] );
		}

		// The price and the call to action share the last line of the band,
		// lifted clear of the story furniture on a 9:16 frame.
		$safe  = ( $H / $W > 1.5 ) ? (int) round( 200 * $u ) : 0;
		$footY = $H - $pad - $safe + (int) round( 6 * $u );

		if ( $price ) {
			imagettftext( $im, (int) round( 42 * $u ), 0, $pad, $footY, self::col( $im, self::INK ), $bold, $price );
		}

		$cta  = 'Wybierz termin →';
		$size = (int) round( 26 * $u );
		$box  = imagettfbbox( $size, 0, $bold, $cta );
		$w    = abs( $box[2] - $box[0] ) + (int) round( 56 * $u );
		$h    = (int) round( $size * 2.5 );

		self::pill(
			$im,
			$W - $pad - $w,
			$footY - $h + (int) round( $size * 0.6 ),
			$cta,
			$size,
			self::BRAND,
			$white,
			(int) round( 28 * $u )
		);
	}

	/* ===================================================================
	   The words on the picture
	   =================================================================== */

	/**
	 * @param array $d Payload.
	 * @return string
	 */
	protected static function price_line( array $d, $currency = null ) {
		$price = mwp_format_price( isset( $d['price'] ) ? (array) $d['price'] : array(), 'pl', $currency );

		if ( empty( $price['value'] ) ) {
			return '';
		}

		return 'od ' . $price['value'] . ' ' . $price['symbol'];
	}

	/**
	 * @param array $d Payload.
	 * @return string
	 */
	protected static function duration_line( array $d ) {
		$days = (int) ( $d['duration']['days'] ?? 0 );

		return $days ? $days . ' dni' : '';
	}

	/**
	 * @param array $d Payload.
	 * @return string
	 */
	protected static function route_line( array $d ) {
		$stops = array();

		foreach ( (array) ( $d['destinations'] ?? array() ) as $stop ) {
			if ( ! empty( $stop['name'] ) ) {
				$stops[] = $stop['name'];
			}
		}

		$stops = array_values( array_unique( $stops ) );

		if ( count( $stops ) > 3 ) {
			$stops = array_slice( $stops, 0, 3 );
		}

		return implode( ' → ', $stops );
	}

	/**
	 * @param array $d Payload.
	 * @return string
	 */
	protected static function kicker_line( array $d ) {
		foreach ( (array) ( $d['destinations'] ?? array() ) as $stop ) {
			if ( ! empty( $stop['country'] ) ) {
				return (string) $stop['country'];
			}
		}

		return isset( $d['themes'][0] ) ? (string) $d['themes'][0] : '';
	}
}
