<?php
/**
 * The social kit: everything one package needs to become a post.
 *
 * The brief was "add an ID, get a great post", with Canva for the video. Canva
 * Pro has no Autofill API — that is a Teams feature — so nothing here tries to
 * drive a Canva template automatically. Which turns out to be the better split
 * of labour anyway:
 *
 *   - the plugin does the part a machine is genuinely better at: pulling the
 *     facts together, writing them into Polish captions that are already the
 *     right length, building the hashtag set, and cropping the photographs to
 *     the exact frames each network wants;
 *   - Canva does the part it is better at: the brand template, the typography,
 *     the motion. The human drops in a photo that is already the right shape
 *     and exports.
 *
 * The plugin deliberately does NOT burn the title onto the photograph. It
 * could — but it would mean bundling a font, and text baked on by a script
 * looks like text baked on by a script next to a Canva template built by
 * someone with taste. The crops are the useful part; the styling belongs where
 * the brand lives.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Social {

	/** Where generated crops live, under uploads. */
	const DIR = 'mwp-social';

	/**
	 * The frames each network wants.
	 *
	 * @return array<string,array{w:int,h:int,label:string,note:string}>
	 */
	public static function formats() {
		return array(
			'square' => array(
				'w'     => 1080,
				'h'     => 1080,
				'label' => __( 'Instagram / Facebook feed', 'multiwander-packages' ),
				'note'  => __( '1080 × 1080', 'multiwander-packages' ),
			),
			'story'  => array(
				'w'     => 1080,
				'h'     => 1920,
				'label' => __( 'Story / Reel / TikTok', 'multiwander-packages' ),
				'note'  => __( '1080 × 1920', 'multiwander-packages' ),
			),
			'gbp'    => array(
				'w'     => 1200,
				'h'     => 900,
				'label' => __( 'Google Business Profile', 'multiwander-packages' ),
				'note'  => __( '1200 × 900 (4:3)', 'multiwander-packages' ),
			),
		);
	}

	/* ===================================================================
	   The words
	   =================================================================== */

	/**
	 * A line that sounds like a person rather than a brochure.
	 *
	 * Keyed on the trip's own theme, because the opening line is the only part
	 * of a caption most people read and a generic one wastes it. Where no
	 * theme matches, the destination carries it — still specific, never
	 * "Odkryj niezwykłe miejsca".
	 *
	 * @param array  $d    Payload.
	 * @param string $lang 'pl' (default) or 'en'.
	 * @return string
	 */
	protected static function hook( array $d, $lang = 'pl' ) {
		$themes = array();
		foreach ( (array) ( $d['themes'] ?? array() ) as $theme ) {
			$themes[] = MWP_Themes::key_for_label( $theme );
		}

		$lines = 'en' === $lang
			? array(
				'safari'           => 'The morning on the savannah starts with sounds, not an alarm clock.',
				'island_hopping'   => 'A different island every morning — a new beach, a new view from the deck.',
				'car_rental'       => 'Your own car, your own pace — stop wherever you want.',
				'city_beach'       => 'City first, then the sea. One trip, two completely different weeks.',
				'city_break'       => 'A few days is all it takes to feel a city — everything else is just excuses.',
				'around_the_world' => 'One journey, several continents, and a ticket that closes the circle.',
			)
			: array(
				'safari'           => 'Poranek na sawannie zaczyna się dźwiękiem, nie budzikiem.',
				'island_hopping'   => 'Każdego ranka inna wyspa, inna plaża i inny widok z pokładu.',
				'car_rental'       => 'Własne auto, własne tempo — zatrzymujesz się tam, gdzie chcesz.',
				'city_beach'       => 'Najpierw miasto, potem morze. Jeden wyjazd, dwa zupełnie różne tygodnie.',
				'city_break'       => 'Kilka dni wystarczy, żeby poczuć miasto — reszta to tylko wymówki.',
				'around_the_world' => 'Jedna podróż, kilka kontynentów i bilet, który zamyka koło.',
			);

		foreach ( $lines as $key => $line ) {
			if ( in_array( $key, $themes, true ) ) {
				return $line;
			}
		}

		$first = isset( $d['destinations'][0]['name'] ) ? $d['destinations'][0]['name'] : '';

		if ( 'en' === $lang ) {
			return $first
				? sprintf( '%s — and a few more places you won\'t find in the brochures.', $first )
				: 'A journey designed from start to finish — and still entirely yours.';
		}

		return $first
			? sprintf( '%s — i jeszcze kilka miejsc, o których nie mówi się w folderach.', $first )
			: 'Podróż ułożona od początku do końca — i wciąż w pełni Twoja.';
	}

	/**
	 * The route, as one readable line.
	 *
	 * @param array $d Payload.
	 * @param int   $max Stops to name before giving up.
	 * @return string
	 */
	protected static function route( array $d, $max = 5 ) {
		$stops = array();

		foreach ( (array) ( $d['destinations'] ?? array() ) as $stop ) {
			if ( ! empty( $stop['name'] ) ) {
				$stops[] = $stop['name'];
			}
		}

		$stops = array_values( array_unique( $stops ) );

		if ( count( $stops ) > $max ) {
			$stops = array_slice( $stops, 0, $max );
			$stops[] = '…';
		}

		return implode( ' → ', $stops );
	}

	/**
	 * The departures line — the single most useful fact a travel post can
	 * carry, and the one nobody bothers to include.
	 *
	 * @param array  $d    Payload.
	 * @param string $lang 'pl' (default) or 'en'.
	 * @return string
	 */
	protected static function dates( array $d, $lang = 'pl' ) {
		if ( ! empty( $d['departures']['is_empty'] ) || empty( $d['departures']['dates'] ) ) {
			return 'en' === $lang
				? 'Flexible departure — you choose the date.'
				: 'Wylot w dowolnym terminie — Ty wybierasz datę.';
		}

		$dates = (array) $d['departures']['dates'];
		$first = strtotime( (string) reset( $dates ) );

		if ( ! $first ) {
			return 'en' === $lang
				? 'Fixed dates — check availability on the website.'
				: 'Terminy stałe — sprawdź dostępność na stronie.';
		}

		return 'en' === $lang
			? sprintf(
				'Next departure: %s. Limited availability (%d dates in the calendar).',
				date_i18n( 'j F Y', $first ),
				count( $dates )
			)
			: sprintf(
				'Najbliższy termin: %s. Liczba terminów ograniczona (%d w kalendarzu).',
				date_i18n( 'j F Y', $first ),
				count( $dates )
			);
	}

	/**
	 * The line that turns a poster into an enquiry.
	 *
	 * Every package on the site is a STARTING POINT, not a fixed departure
	 * somebody either buys or scrolls past — the length, the departure
	 * airport, the hotels and the order of the stops can all be changed. A
	 * reader who does not know that treats the post as an advertisement for
	 * somebody else's holiday and keeps scrolling. A reader who does knows
	 * there is a conversation to be had, and that is the click worth having:
	 * it arrives as an enquiry rather than as a bounce off a price.
	 *
	 * @param string $variant inspiracja|konkret|gbp
	 * @param string $lang    'pl' (default) or 'en'.
	 * @return string[] Lines.
	 */
	protected static function customisable( $variant, $lang = 'pl' ) {
		if ( 'gbp' === $variant ) {
			return 'en' === $lang
				? array( 'We tailor every trip to you: length of stay, departure airport, hotels and order of stops can all be changed. Write to us and we\'ll prepare a version just for you.' )
				: array( 'Każdą podróż układamy pod Ciebie: długość pobytu, lotnisko wylotu, hotele i kolejność miejsc możesz zmienić. Napisz, a przygotujemy wersję dla Ciebie.' );
		}

		return 'en' === $lang
			? array(
				'✏️ This is a proposal, not a fixed package:',
				'• adjust the length of stay',
				'• choose your departure airport',
				'• select hotels and the order of stops',
			)
			: array(
				'✏️ To propozycja, nie sztywny pakiet:',
				'• zmienisz długość pobytu',
				'• wybierzesz lotnisko wylotu',
				'• dobierzesz hotele i kolejność miejsc',
			);
	}

	/**
	 * Price, already formatted the way the site formats it.
	 *
	 * @param array $d Payload.
	 * @return string
	 */
	protected static function price( array $d, $lang = 'pl', $currency = null ) {
		$price = mwp_format_price( isset( $d['price'] ) ? (array) $d['price'] : array(), $lang, $currency );

		if ( empty( $price['value'] ) ) {
			return '';
		}

		return trim( $price['value'] . ' ' . $price['symbol'] );
	}

	/**
	 * Hashtags: destination, theme, then the steady brand set.
	 *
	 * Instagram and TikTok both search caption text now, so these are as much
	 * keywords as decoration — which is why the country and the theme come
	 * first and the generic ones last, and why there are a dozen rather than
	 * thirty. A wall of tags reads as spam to a person and adds nothing for
	 * the algorithm.
	 *
	 * @param array $d Payload.
	 * @return string[]
	 */
	public static function hashtags( array $d, $lang = 'pl' ) {
		$tags = array();

		$clean = function ( $text ) {
			$text = remove_accents( (string) $text );
			$text = preg_replace( '/[^A-Za-z0-9 ]/', '', $text );
			$text = str_replace( ' ', '', ucwords( strtolower( trim( $text ) ) ) );

			return $text ? '#' . $text : '';
		};

		$countries = array();
		foreach ( (array) ( $d['destinations'] ?? array() ) as $stop ) {
			if ( ! empty( $stop['country'] ) ) {
				$countries[ $stop['country'] ] = true;
			}
		}

		foreach ( array_keys( $countries ) as $country ) {
			$tag = $clean( $country );
			if ( $tag ) {
				$tags[] = $tag;
			}
		}

		foreach ( array_slice( (array) ( $d['themes'] ?? array() ), 0, 3 ) as $theme ) {
			$tag = $clean( $theme );
			if ( $tag ) {
				$tags[] = $tag;
			}
		}

		$brand = 'en' === $lang
			? array( '#MultiWander', '#TailoredTravel', '#DreamVacation', '#TravelSmart' )
			: array( '#MultiWander', '#PodrozeSzyteNaMiare', '#WakacjeMarzen', '#PodrozujMadrzej' );

		$tags = array_merge( $tags, $brand );

		return array_values( array_unique( array_filter( $tags ) ) );
	}

	/**
	 * The two caption templates.
	 *
	 * Two, because they do different jobs. "Inspiracja" is for the feed, where
	 * a post competes with holiday photographs and has to earn the read.
	 * "Konkret" is for the audience already shopping — it leads with the
	 * number, and it converts better than a poem to the people closest to
	 * booking. Both end with the same link, which is the only thing that
	 * actually has to survive being copied.
	 *
	 * @param array  $d       Payload.
	 * @param string $variant inspiracja|konkret|gbp
	 * @param string $url     The package's permanent Polish URL.
	 * @return string
	 */
	public static function caption( array $d, $variant, $url, $lang = 'pl', $currency = null ) {
		$lang   = ( 'en' === $lang ) ? 'en' : 'pl';
		$title  = trim( (string) ( $d['title'] ?? '' ) );
		$days   = (int) ( $d['duration']['days'] ?? 0 );
		$nights = (int) ( $d['duration']['nights'] ?? 0 );
		$price  = self::price( $d, $lang, $currency );
		$route  = self::route( $d );
		$dates  = self::dates( $d, $lang );

		if ( 'en' === $lang ) {
			$duration = $days
				? sprintf( '%d day%s%s', $days, 1 === $days ? '' : 's', $nights ? sprintf( ' / %d night%s', $nights, 1 === $nights ? '' : 's' ) : '' )
				: '';
		} else {
			$duration = $days
				? sprintf( '%d dni%s', $days, $nights ? sprintf( ' / %d nocy', $nights ) : '' )
				: '';
		}

		if ( 'gbp' === $variant ) {
			/*
			 * Google Business Profile is not social media and should not be
			 * written like it: no hashtags, no emoji wall, and a hard 1500
			 * characters. It behaves like a short local advert, so it gets
			 * plain sentences and the facts in the first line, which is all
			 * that shows before "read more".
			 */
			$out = array();

			if ( 'en' === $lang ) {
				$out[] = sprintf(
					'%s — %s%s.',
					$title,
					$duration ? $duration : 'trip',
					$price ? sprintf( ', from %s per person', $price ) : ''
				);
				if ( $route ) {
					$out[] = 'Itinerary: ' . $route . '.';
				}
			} else {
				$out[] = sprintf(
					'%s — %s%s.',
					$title,
					$duration ? $duration : 'podróż',
					$price ? sprintf( ', od %s za osobę', $price ) : ''
				);
				if ( $route ) {
					$out[] = 'Trasa: ' . $route . '.';
				}
			}

			$lead = self::lead( $d, 320 );
			if ( $lead ) {
				$out[] = $lead;
			}

			$out[] = $dates;
			$out   = array_merge( $out, self::customisable( 'gbp', $lang ) );
			$out[] = ( 'en' === $lang ? 'Itinerary, dates and pricing: ' : 'Program, terminy i wycena: ' ) . $url;

			return self::cap( implode( "\n\n", $out ), 1500 );
		}

		if ( 'konkret' === $variant ) {
			if ( 'en' === $lang ) {
				$head = array_filter( array(
					$title,
					$duration,
					$price ? 'from ' . $price . ' / p.p.' : '',
				) );
			} else {
				$head = array_filter( array(
					$title,
					$duration,
					$price ? 'od ' . $price . ' / os.' : '',
				) );
			}

			$out   = array();
			$out[] = implode( ' · ', $head );
			$out[] = '';

			if ( $route ) {
				$out[] = '📍 ' . $route;
			}
			if ( $duration ) {
				$out[] = '🗓 ' . $duration;
			}
			if ( ! empty( $d['flights'] ) ) {
				$out[] = 'en' === $lang
					? '✈️ Flights included (' . count( $d['flights'] ) . ')'
					: '✈️ Przeloty w cenie (' . count( $d['flights'] ) . ')';
			}
			if ( ! empty( $d['hotels'] ) ) {
				$out[] = 'en' === $lang
					? '🏨 Hotels: ' . count( $d['hotels'] )
					: '🏨 Hotele: ' . count( $d['hotels'] );
			}

			$out[] = '';
			$out[] = $dates;
			$out[] = '';
			$out   = array_merge( $out, self::customisable( 'konkret', $lang ) );
			$out[] = '';
			$out[] = 'en' === $lang
				? 'Design this trip your way and send an enquiry 👇'
				: 'Ułóż tę podróż po swojemu i wyślij zapytanie 👇';
			$out[] = $url;
			$out[] = '';
			$out[] = implode( ' ', self::hashtags( $d, $lang ) );

			return self::cap( implode( "\n", $out ), 2200 );
		}

		// inspiracja / inspiration
		$out   = array();
		$out[] = self::hook( $d, $lang );
		$out[] = '';

		$lead = self::lead( $d, 300 );
		if ( $lead ) {
			$out[] = $lead;
			$out[] = '';
		}

		if ( $route ) {
			$out[] = '📍 ' . $route;
		}
		if ( $duration ) {
			$out[] = '🗓 ' . $duration;
		}
		if ( $price ) {
			$out[] = 'en' === $lang
				? '💶 from ' . $price . ' per person'
				: '💶 od ' . $price . ' za osobę';
		}

		$out[] = '';
		$out[] = $dates;
		$out[] = '';
		$out   = array_merge( $out, self::customisable( 'inspiracja', $lang ) );
		$out[] = '';
		$out[] = 'en' === $lang
			? 'See the full itinerary and send an enquiry 👇'
			: 'Zobacz cały program i wyślij zapytanie 👇';
		$out[] = $url;
		$out[] = '';
		$out[] = implode( ' ', self::hashtags( $d, $lang ) );

		return self::cap( implode( "\n", $out ), 2200 );
	}

	/**
	 * The package's own description, cut to a sentence boundary.
	 *
	 * @param array $d     Payload.
	 * @param int   $chars Budget.
	 * @return string
	 */
	protected static function lead( array $d, $chars ) {
		$text = wp_strip_all_tags( (string) ( $d['description'] ?? '' ), true );
		$text = trim( preg_replace( '/\s+/', ' ', $text ) );

		if ( '' === $text ) {
			return '';
		}

		if ( mb_strlen( $text ) <= $chars ) {
			return $text;
		}

		$cut = mb_substr( $text, 0, $chars );
		$end = max( mb_strrpos( $cut, '. ' ), mb_strrpos( $cut, '! ' ), mb_strrpos( $cut, '? ' ) );

		return $end > 60 ? trim( mb_substr( $cut, 0, $end + 1 ) ) : trim( $cut ) . '…';
	}

	/**
	 * Hard character limit, cut on a word.
	 *
	 * @param string $text  Text.
	 * @param int    $chars Limit.
	 * @return string
	 */
	protected static function cap( $text, $chars ) {
		if ( mb_strlen( $text ) <= $chars ) {
			return $text;
		}

		$cut = mb_substr( $text, 0, $chars - 1 );
		$sp  = mb_strrpos( $cut, ' ' );

		return ( $sp ? mb_substr( $cut, 0, $sp ) : $cut ) . '…';
	}

	/* ===================================================================
	   The pictures
	   =================================================================== */

	/**
	 * A local copy of a photograph, whatever it started as.
	 *
	 * Travel Compositor serves from its own storage, and GD cannot open a URL.
	 * An image the plugin already imported is used where it sits; anything
	 * else is fetched once and kept, because a package with six photographs
	 * would otherwise download all six every time the screen is opened.
	 *
	 * @param string $url Image URL.
	 * @return string Absolute path, or '' if it could not be had.
	 */
	public static function source_path( $url ) {
		if ( ! $url ) {
			return '';
		}

		$attachment = mwp_attachment_id_for_url( $url );

		if ( $attachment ) {
			$local = (string) get_attached_file( $attachment );
			if ( $local && file_exists( $local ) ) {
				return $local;
			}
		}

		$upload = wp_upload_dir();
		$dir    = trailingslashit( $upload['basedir'] ) . self::DIR;
		$path   = trailingslashit( $dir ) . 'src-' . md5( $url ) . '.img';

		if ( file_exists( $path ) ) {
			return $path;
		}

		if ( ! wp_mkdir_p( $dir ) ) {
			return '';
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';

		$tmp = download_url( $url, 20 );

		if ( is_wp_error( $tmp ) ) {
			mwp_log( 'Social source download failed', array( 'url' => $url, 'error' => $tmp->get_error_message() ) );
			return '';
		}

		if ( ! @rename( $tmp, $path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			@copy( $tmp, $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			wp_delete_file( $tmp );
		}

		return file_exists( $path ) ? $path : '';
	}

	/**
	 * Where in a photograph the interesting part is.
	 *
	 * @return array<string,string>
	 */
	public static function focal_points() {
		return array(
			'top'    => __( 'Top', 'multiwander-packages' ),
			'center' => __( 'Middle', 'multiwander-packages' ),
			'bottom' => __( 'Bottom', 'multiwander-packages' ),
		);
	}

	/**
	 * Crop one photograph to one network's frame.
	 *
	 * Cropped rather than letterboxed, and from the centre, because a travel
	 * photograph survives losing its edges and does not survive white bars
	 * down the side of a Reel.
	 *
	 * Results are kept: the same photograph in the same frame is only ever
	 * built once, which matters because a remote Travel Compositor image has
	 * to be downloaded before it can be cropped at all.
	 *
	 * @param string $url    Source image.
	 * @param string $format Key from formats().
	 * @return string URL of the crop, or '' on failure.
	 */
	public static function crop( $url, $format ) {
		$formats = self::formats();

		if ( ! $url || ! isset( $formats[ $format ] ) ) {
			return '';
		}

		$spec   = $formats[ $format ];
		$upload = wp_upload_dir();
		$dir    = trailingslashit( $upload['basedir'] ) . self::DIR;
		// The plugin version is part of the key, so a release that changes how
		// a frame is built can never be masked by a file cached by the last
		// one — which is exactly what happened when the crops came out at the
		// source photograph's size.
		$base = md5( $url . '|' . $format . '|' . MWP_VERSION ) . '.jpg';
		$path   = trailingslashit( $dir ) . $base;
		$link   = trailingslashit( $upload['baseurl'] ) . self::DIR . '/' . $base;

		if ( file_exists( $path ) ) {
			return $link;
		}

		if ( ! wp_mkdir_p( $dir ) ) {
			return '';
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';

		$local   = '';
		$cleanup = false;

		$attachment = mwp_attachment_id_for_url( $url );

		if ( $attachment ) {
			$local = (string) get_attached_file( $attachment );
		}

		if ( ! $local || ! file_exists( $local ) ) {
			$tmp = download_url( $url, 20 );

			if ( is_wp_error( $tmp ) ) {
				mwp_log( 'Social crop download failed', array( 'url' => $url, 'error' => $tmp->get_error_message() ) );
				return '';
			}

			$local   = $tmp;
			$cleanup = true;
		}

		$editor = wp_get_image_editor( $local );

		if ( is_wp_error( $editor ) ) {
			if ( $cleanup ) {
				wp_delete_file( $local );
			}
			return '';
		}

		/*
		 * Cropped by hand rather than with resize( w, h, true ).
		 *
		 * resize() REFUSES TO ENLARGE. Travel Compositor's hero photographs
		 * are around 900px wide, so asking for 1080×1080 returned the original
		 * 908×726 untouched — and every post drawn on top of it was laid out
		 * for a canvas that was not there, with the headline and the price
		 * printed past the bottom edge. crop() does enlarge, so the frame is
		 * always exactly the size the network expects.
		 *
		 * The source rectangle is the largest one of the right shape, taken
		 * from the middle of the photograph.
		 */
		$size = $editor->get_size();
		$sw   = max( 1, (int) ( $size['width'] ?? 1 ) );
		$sh   = max( 1, (int) ( $size['height'] ?? 1 ) );

		$want = $spec['w'] / $spec['h'];
		$have = $sw / $sh;

		if ( $have > $want ) {
			$ch = $sh;
			$cw = (int) round( $sh * $want );
		} else {
			$cw = $sw;
			$ch = (int) round( $sw / $want );
		}

		$editor->crop(
			(int) round( ( $sw - $cw ) / 2 ),
			(int) round( ( $sh - $ch ) / 2 ),
			$cw,
			$ch,
			(int) $spec['w'],
			(int) $spec['h']
		);

		$editor->set_quality( 86 );
		$saved = $editor->save( $path, 'image/jpeg' );

		if ( $cleanup ) {
			wp_delete_file( $local );
		}

		return is_wp_error( $saved ) ? '' : $link;
	}

	/**
	 * Every photograph worth offering for this package.
	 *
	 * @param int   $post_id Package page (Polish).
	 * @param array $d       Payload.
	 * @param int   $max     How many.
	 * @return string[] Source URLs, hero first.
	 */
	public static function photos( $post_id, array $d, $max = 5 ) {
		$urls = array();

		$hero = MWP_Frontend::hero_url( $post_id, $d );
		if ( $hero ) {
			$urls[] = $hero;
		}

		foreach ( (array) ( $d['gallery'] ?? array() ) as $url ) {
			$urls[] = $url;
		}

		return array_slice( array_values( array_unique( array_filter( $urls ) ) ), 0, $max );
	}
}
