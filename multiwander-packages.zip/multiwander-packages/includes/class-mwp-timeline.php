<?php
/**
 * Builds the chronological trip plan for a package page.
 *
 * Travel Compositor returns each element type in its own bucket — hotels,
 * transports, tickets, closedTours, destinations — each carrying a day number.
 * Its own brochure then presents them as one date-ordered stream of cards, and
 * that is what a traveller actually reads. This class flattens the buckets
 * back into that stream so the WordPress page and the booking engine tell the
 * story in the same order.
 *
 * Built at render time from the stored payload rather than at sync time, so
 * pages synced with an earlier version pick it up without a re-sync.
 *
 * @package multiwander-packages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MWP_Timeline {

	/**
	 * Sort weight within a single day: you fly, you arrive somewhere, you
	 * check in, then you do things.
	 */
	const ORDER = array(
		'transport' => 0,
		'flight'    => 0,
		'place'     => 1,
		'hotel'     => 2,
		'tour'      => 3,
		'activity'  => 4,
	);

	/**
	 * Build the ordered list of trip elements.
	 *
	 * The order is the package's own order — by day, then by what happens first
	 * within a day — and is never overridden. A holiday package is sold as a
	 * sequence; showing it in any other order would misrepresent the trip.
	 *
	 * @param array  $d    Normalised package payload.
	 * @param string $lang Site language slug.
	 * @return array<int,array>
	 */
	public static function build( array $d, $lang = 'pl' ) {
		$en = ( 'en' === $lang );
		$t  = function ( $pl, $english ) use ( $en ) {
			return $en ? $english : $pl;
		};

		$items = array();

		// --- Flights -------------------------------------------------
		// Rendered as connector cards, the same shape as every other leg of the
		// journey below, so the trip reads as one continuous sequence of stays
		// and the travel between them.
		foreach ( $d['flights'] as $f ) {
			$items[] = self::transport_item(
				array(
					'day'       => $f['day'],
					'mode'      => 'flight',
					'carrier'   => $f['airline'],
					'from'      => $f['from'],
					'to'        => $f['to'],
					'dep_time'  => $f['departure_time'],
					'arr_time'  => $f['arrival_time'],
					'duration'  => $f['duration'],
					'baggage'   => $f['baggage'],
					'segments'  => $f['segments'],
				),
				$t
			);
		}

		// --- Ground transport (trains, buses, ferries) ---------------
		if ( ! empty( $d['transports'] ) ) {
			foreach ( $d['transports'] as $tr ) {
				$items[] = self::transport_item( $tr, $t );
			}
		}

		// --- Destinations --------------------------------------------
		foreach ( $d['destinations'] as $dest ) {
			$nights = max( 0, (int) $dest['to_day'] - (int) $dest['from_day'] );

			$meta = array();
			if ( $dest['country'] ) {
				$meta[] = $dest['country'];
			}
			if ( $nights > 0 ) {
				$meta[] = sprintf(
					$t( '%d nocy', '%d nights' ),
					$nights
				);
			}

			$items[] = array(
				'day'    => max( 1, (int) $dest['from_day'] ),
				'kind'   => 'place',
				'title'  => $dest['name'],
				'badge'  => $t( 'Pobyt od', 'Stay from' ),
				'lead'   => '',
				'meta'   => $meta,
				'body'   => $dest['description'],
				'images' => array_slice( $dest['images'], 0, 3 ),
			);
		}

		// --- Hotels ---------------------------------------------------
		foreach ( $d['hotels'] as $h ) {
			$meta = array_filter( array(
				$h['destination'],
				$h['room_type'],
				$h['meal_plan'],
			) );

			$items[] = array(
				'day'    => max( 1, (int) $h['day'] ),
				'kind'   => 'hotel',
				'title'  => $h['name'],
				'badge'  => $h['nights']
					? sprintf( $t( '%d nocy', '%d nights' ), $h['nights'] )
					: $t( 'Zakwaterowanie', 'Accommodation' ),
				'lead'   => '',
				'meta'   => $meta,
				'stars'  => $h['stars'],
				'score'  => $h['score'],
				'images' => array_slice( $h['images'], 0, 3 ),
			);
		}

		// --- Guided tours ---------------------------------------------
		foreach ( $d['tours'] as $tour ) {
			$meta = array();
			if ( $tour['day_to'] && $tour['day_to'] > $tour['day_from'] ) {
				$meta[] = sprintf(
					$t( 'dni %1$d–%2$d', 'days %1$d–%2$d' ),
					$tour['day_from'],
					$tour['day_to']
				);
			}

			$items[] = array(
				'day'    => max( 1, (int) $tour['day_from'] ),
				'kind'   => 'tour',
				'title'  => $tour['name'],
				'badge'  => $t( 'Wycieczka', 'Guided tour' ),
				'lead'   => '',
				'meta'   => $meta,
				'body'   => $tour['description'],
				'images' => array_slice( $tour['images'], 0, 3 ),
			);
		}

		// --- Experiences ----------------------------------------------
		foreach ( $d['activities'] as $a ) {
			$items[] = array(
				'day'    => max( 1, (int) $a['day'] ),
				'kind'   => 'activity',
				'title'  => $a['name'],
				'badge'  => $t( 'Atrakcja', 'Experience' ),
				'lead'   => '',
				'meta'   => array_filter( array( $a['duration'], $a['meeting_point'] ) ),
				'body'   => $a['description'],
				'images' => array_slice( $a['images'], 0, 3 ),
			);
		}

		// Stable ordering: by day, then by what happens first within it, then
		// by the order the API listed them so equal items never jump around
		// between page loads.
		foreach ( $items as $i => $item ) {
			$items[ $i ]['_seq'] = $i;
			$items[ $i ] += array(
				'body'  => '',
				'stars' => 0,
				'score' => null,
				'lead'  => '',
			);
		}

		usort( $items, function ( $a, $b ) {
			if ( $a['day'] !== $b['day'] ) {
				return $a['day'] <=> $b['day'];
			}
			$ra = isset( self::ORDER[ $a['kind'] ] ) ? self::ORDER[ $a['kind'] ] : 9;
			$rb = isset( self::ORDER[ $b['kind'] ] ) ? self::ORDER[ $b['kind'] ] : 9;
			if ( $ra !== $rb ) {
				return $ra <=> $rb;
			}
			return $a['_seq'] <=> $b['_seq'];
		} );

		// Turn day numbers into real dates when a departure is known — the
		// booking engine shows dates, so match it rather than showing "day 5"
		// next to its "05 paź".
		$start = self::start_timestamp( $d );

		foreach ( $items as $i => $item ) {
			$items[ $i ]['date'] = $start
				? $start + ( $item['day'] - 1 ) * DAY_IN_SECONDS
				: 0;
		}

		return $items;
	}

	/**
	 * Build one transport leg (flight, train, bus or ferry) in the shared shape
	 * the timeline renders as a connector card.
	 *
	 * Accepts both the flight payload and the ground-transport payload, which
	 * carry slightly different keys, and normalises them to one structure.
	 *
	 * @param array    $tr Raw transport data.
	 * @param callable $t  PL/EN string picker.
	 * @return array
	 */
	protected static function transport_item( array $tr, $t ) {
		$mode = isset( $tr['mode'] ) ? $tr['mode'] : 'transport';

		$from = isset( $tr['from'] ) ? trim( (string) $tr['from'] ) : '';
		$to   = isset( $tr['to'] ) ? trim( (string) $tr['to'] ) : '';

		$dep_time = isset( $tr['dep_time'] ) ? (string) $tr['dep_time'] : '';
		$arr_time = isset( $tr['arr_time'] ) ? (string) $tr['arr_time'] : '';
		$duration = isset( $tr['duration'] ) ? (string) $tr['duration'] : '';
		$baggage  = isset( $tr['baggage'] ) ? (string) $tr['baggage'] : '';
		$carrier  = isset( $tr['carrier'] ) ? (string) $tr['carrier'] : '';
		$segments = isset( $tr['segments'] ) ? max( 1, (int) $tr['segments'] ) : 1;

		// What to call this leg, by mode.
		$labels = array(
			'flight' => $t( 'Przelot', 'Flight' ),
			'train'  => $t( 'Pociąg', 'Train' ),
			'bus'    => $t( 'Autobus', 'Bus' ),
			'ferry'  => $t( 'Prom', 'Ferry' ),
		);
		$badge = isset( $labels[ $mode ] ) ? $labels[ $mode ] : $t( 'Transport', 'Transport' );

		// Title by mode. A flight keeps its familiar "Flight WAW → NRT" shape;
		// everything else reads "Transport from A to B", as the booking engine
		// phrases it. With only one end known, the mode label stands alone
		// rather than leaving a dangling arrow.
		if ( '' !== $from && '' !== $to ) {
			$title = ( 'flight' === $mode )
				? sprintf( $t( 'Przelot %1$s → %2$s', 'Flight %1$s → %2$s' ), $from, $to )
				: sprintf( $t( 'Transport z %1$s do %2$s', 'Transport from %1$s to %2$s' ), $from, $to );
		} elseif ( '' !== $to ) {
			$title = sprintf( $t( 'Transport do %s', 'Transport to %s' ), $to );
		} else {
			$title = $badge;
		}

		// "Direct" or the number of changes.
		if ( $segments > 1 ) {
			$stops_label = sprintf(
				$t( '%d przesiadka', '%d stop' ),
				$segments - 1
			);
		} else {
			$stops_label = $t( 'Bezpośrednio', 'Direct' );
		}

		return array(
			'day'         => max( 1, (int) $tr['day'] ),
			'kind'        => 'transport',
			'mode'        => $mode,
			'title'       => $title,
			'badge'       => $badge,
			'carrier'     => $carrier,
			'from_label'  => $from,
			'to_label'    => $to,
			'from_time'   => $dep_time,
			'to_time'     => $arr_time,
			'duration'    => $duration,
			'baggage'     => $baggage,
			'stops_label' => $stops_label,
			'images'      => array(),
		);
	}

	/**
	 * The trip's first day as a timestamp, when one can be known.
	 *
	 * @param array $d Payload.
	 * @return int 0 when the package has no fixed departure.
	 */
	protected static function start_timestamp( array $d ) {
		$first = isset( $d['departures']['first'] ) ? $d['departures']['first'] : '';
		if ( ! $first ) {
			return 0;
		}
		$ts = strtotime( $first );
		return $ts ? $ts : 0;
	}
}
